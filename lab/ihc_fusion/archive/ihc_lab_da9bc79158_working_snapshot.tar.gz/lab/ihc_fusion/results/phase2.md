# Phase 2: Golden and official baseline frozen

43 GPU tests passed on H100 (results/phase2_pytest.txt), across FP32/BF16/FP16,
N=0,1,2,3,5,7,17,33,257, D=128,257,1024,1025,3072,4096,7168,8192;
random, zero, tiny, large, cancellation and saturated gates; offset storage views.
Preallocated official kernel path is bitwise equal to original official wrappers.

Files: reference/torch_post_pre.py, baselines/official.py, tests/{cases,test_post_pre}.py,
package markers, results logs/reports. No fused implementation exists at freeze.
Frozen file hashes (including numerical acceptance rules) are in frozen_sha256.json.
Golden and baseline must not change during fused development.

Direct importing of the source module failed because this checkout lacks compiled
vLLM extensions. The baseline validates the complete original file SHA256 against
both its pinned value and git show at the pinned commit. It compiles selected
original AST definitions without modification, skipping runtime-only imports and
the dispatch predicate. This calls the original JITFunctions; no fallback is used.
Source and code-object paths are recorded in phase2_correctness.json.

Initial result: 42 pass, one FP32 large-input baseline-vs-Golden failure (max
absolute difference 3.05176e-5 near cancellation). Before implementing the fused
kernel, replaced an unconditional absolute-only floor by an explicit additional
8*FP32_epsilon*sum(abs(residual_channels)) cancellation budget. Kept elementwise
relative bounds, relative-L2 <=2e-6 for FP32 output/gates, <=dtype epsilon for
low-precision output, and bitwise Residual equality. No tolerance was changed to
accommodate any fused result. Initial failure log is retained.

Worst baseline-vs-Golden max_abs across this suite: {'output': 0.015625, 'residual': 0.0, 'post_gates': 3.874301910400391e-06}.
Full per-case max_abs, relative L2 and RMS absolute errors are in JSON.

No performance measurements yet; no unresolved Phase 2 correctness issues.
Scope audit: git diff --name-only empty; all new files inside lab/ihc_fusion,
except the pre-existing ihc_idea.md. No out-of-scope edits required.
