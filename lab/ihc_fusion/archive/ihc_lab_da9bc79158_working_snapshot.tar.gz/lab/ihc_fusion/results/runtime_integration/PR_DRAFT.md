## Overview

Add an opt-in, HY4 NVIDIA-only fusion of Attention Post and the same layer's MLP Pre. Enable with `hf_overrides={"enable_ihc_post_pre_fusion": true}` and `enforce_eager=True`; the default path is unchanged.

## Claims

- Reuse the validated Single Triton computation for BF16, D=6144, C=4 on H100 80GB HBM3. Fuse only verified pure-prefill metadata with 512≤N≤8192; otherwise retain the original Post/Pre boundary.
- Preserve rounded residuals, gate ownership, and the final MLP Post. No scheduler, public HC API, other model, or frozen Lab changes.
- Real three-layer TP1 slice: measured model Forward medians 38.798→37.962 ms at N4096 and 78.635→76.991 ms at N8192. These are slice measurements, not full-model TTFT claims.

## Validation

- `lab/ihc_fusion/results/.venv/bin/python -m pytest tests/models/test_hyv4_ihc_fusion.py lab/ihc_fusion/tests -q -p no:cacheprovider`: **135 passed**, 14 upstream deprecation warnings. Tests exercise routing boundaries, unsupported dtypes/layouts/metadata, frozen accuracy limits, and updated-input CUDA Graph replay.
- Ruff check / format --check on the three changed source/test files and `git diff --check`: passed.
- Existing real MXFP8 HY4 three-layer slice, BF16 activations, TP1, eager: default-off initialization passed; N512/1024 each invoked fusion three times during prefill and produced the same two generated tokens as baseline. Six same-input real boundary comparisons passed frozen tolerances, with bitwise-identical residuals.
- Model-level numerical equivalence is **not yet established**. Original A/A runs themselves differ; A/B layer/logit errors and A/A controls are reported without relaxing tolerances. No full-model quality evaluation was performed.
- Performance: 5 warmups per arm/shape, 9 alternating A/B rounds, CUDA Events, no profiler; full distributions, per-layer times, kernel microbenchmarks and reproduction commands: [validation report](REPORT.md). N128/256 fallbacks show timing noise; small measured gains are not treated as conclusive across configurations.

## Details

Production imports no Lab code. The frozen C=4 Triton function was promoted unchanged; retaining the Lab copy preserves historical experiment reproducibility. Runtime checks CPU metadata only. Compiled/automatic CUDA Graph, speculative, batch-invariant, mixed or unknown batches safely retain the original path.

Three source/test files, +347/-5 lines. Test-only bootstrap used existing installed vLLM binary dependencies with checkout Python code because this checkout lacks compiled extensions; a matching-build validation remains necessary. Local slice validation is not automatically covered by CI.

Duplicate-work status: no issue number was supplied, `gh` is unavailable, and GitHub connector searches for open `ihc`, `HY4`, and `PostPre` PRs could not complete authentication. **No claim of non-duplication is made; complete these checks before submission.** AI assistance was used. A human must review every changed line and rerun validation before submitting; this draft is not a request to merge or enable by default.

---

<details>
<summary> Pull Request Checklist </summary>

- [x] I used vLLM's `/pr-checklist` skill. (Mandatory for agents, optional for humans).
- [x] AI assistance was used during the creation of this PR.

- [x] **Design Fit:** Minimizes impact on core components, reuses existing functionality, and justifies added complexity.
- [ ] **Testing and Validation:** Validates the change and ensures any added tests are meaningful and reliable, with CI coverage or documented CI resource constraints and validation performed outside CI. (Kernel/routing validation complete; strict model numerical validation and matching-build rerun pending.)
- [x] **Code Quality and Style:** Keeps code and comments clear and concise, and updates relevant documentation and examples.
- [ ] **Pull Request Contents:** Includes a brief summary and relevant links, supports claims with evidence, explains root causes and implementation trade-offs, and follows the contributing guide. (Duplicate-work checks and human review pending.)
</details>

**BEFORE SUBMITTING, PLEASE READ <https://docs.vllm.ai/en/latest/contributing>**
