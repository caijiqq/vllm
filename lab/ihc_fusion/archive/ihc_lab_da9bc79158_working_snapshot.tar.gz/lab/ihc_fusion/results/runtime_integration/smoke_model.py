import os
os.environ['VLLM_ENABLE_V1_MULTIPROCESSING'] = '0'
os.environ['VLLM_USE_BREAKABLE_CUDAGRAPH'] = '0'
from vllm import LLM, SamplingParams
llm = LLM(model='/data/chenhao/Hy4-preview-FP8-3-layers',
          tensor_parallel_size=1, enforce_eager=True, max_model_len=8192,
          max_num_batched_tokens=8192, gpu_memory_utilization=0.65,
          enable_prefix_caching=False, max_num_seqs=4,
          trust_remote_code=True, distributed_executor_backend='uni',
          hf_overrides={'enable_ihc_post_pre_fusion':True})
print('SLICE_MODEL_LOADED', flush=True)
outputs = llm.generate([{'prompt_token_ids': [100]*512}], SamplingParams(temperature=0,max_tokens=2))
print('SLICE_OUTPUT',outputs[0].outputs[0].token_ids,flush=True)
