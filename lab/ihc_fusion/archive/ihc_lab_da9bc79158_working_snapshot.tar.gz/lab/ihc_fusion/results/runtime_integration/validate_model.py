"""Original/Fused A/B on one unchanged, real three-layer HY4 checkpoint."""
import json
import os
import statistics
import time
from pathlib import Path
from types import MethodType

os.environ['VLLM_ENABLE_V1_MULTIPROCESSING']='0'
os.environ['VLLM_USE_BREAKABLE_CUDAGRAPH']='0'
import torch
from vllm import LLM, SamplingParams
from vllm.models.hy_v4.nvidia import model as hy4
from lab.ihc_fusion.tests.cases import check_outputs,metrics

HERE=Path(__file__).parent
llm=LLM(model='/data/chenhao/Hy4-preview-FP8-3-layers',tensor_parallel_size=1,
        enforce_eager=True,max_model_len=8448,max_num_batched_tokens=8192,
        gpu_memory_utilization=.65,enable_prefix_caching=False,max_num_seqs=4,
        trust_remote_code=True,distributed_executor_backend='uni',
        hf_overrides={'enable_ihc_post_pre_fusion':True})
model=llm.apply_model(lambda m:m)[0]
layers=list(model.model.layers)
assert len(layers)==3 and all(l._ihc_fusion_enabled for l in layers)
print('REAL_MODEL_READY',flush=True)

def mode(enabled):
    for layer in layers:layer._ihc_fusion_enabled=enabled

def prompt(n):return {'prompt_token_ids':[100+i%197 for i in range(n)]}

def generate(n,tokens=1):
    return llm.generate([prompt(n)],SamplingParams(temperature=0,max_tokens=tokens,seed=7),use_tqdm=False)[0]

# Capture local boundary inputs/results for correctness only; remove before timing.
correctness={}
real_kernel=hy4.triton_ihc_post_pre
fused_calls=[]
def counted_kernel(*args):
    fused_calls.append(args[0].shape[0])
    return real_kernel(*args)
hy4.triton_ihc_post_pre=counted_kernel
for n in (512,1024):
    mode(False);generate(n)
    snapshots={}; handles=[]; originals=[]
    for index,layer in enumerate(layers):
        original=layer._post_attention_ihc
        originals.append(original)
        def boundary(self,x,residual,post,*,index=index,original=original):
            result=original(x,residual,post)
            if x.shape[0]==n:
                snapshots.setdefault(index,{})['boundary']=tuple(t.detach().clone() for t in result)
                snapshots[index]['input']=tuple(t.detach().clone() for t in (x,residual,post))
            return result
        layer._post_attention_ihc=MethodType(boundary,layer)
        def hook(module,args,result,index=index):
            if result[0].shape[0]==n:
                snapshots.setdefault(index,{})['layer']=result[0].detach().clone()
        handles.append(layer.register_forward_hook(hook))
    logits=[]; original_logits=model.compute_logits
    def compute_logits(self,hidden):
        result=original_logits(hidden);logits.append(result.detach().clone());return result
    model.compute_logits=MethodType(compute_logits,model)
    baseline=generate(n,2); saved=snapshots; snapshots={}; base_logits=logits; logits=[]
    repeated=generate(n,2)
    aa_layers={i:metrics(snapshots[i]['layer'],saved[i]['layer']) for i in range(3)}
    aa_inputs={i:[metrics(a,b) for a,b in zip(snapshots[i]['input'],saved[i]['input'])] for i in range(3)}
    aa_logits=[metrics(a,b) for a,b in zip(logits,base_logits)]
    snapshots={};logits=[];fused_calls.clear()
    mode(True); optimized=generate(n,2)
    runtime_calls=list(fused_calls)
    assert runtime_calls == [n]*3, runtime_calls
    row=dict(original_tokens=baseline.outputs[0].token_ids,fused_tokens=optimized.outputs[0].token_ids,layers={})
    row['runtime_fused_calls']=runtime_calls
    row['baseline_repeat_layers']=aa_layers
    row['baseline_repeat_boundary_inputs']=aa_inputs
    row['baseline_repeat_tokens']=repeated.outputs[0].token_ids
    row['baseline_repeat_logits']=aa_logits
    assert row['original_tokens']==row['fused_tokens']
    for i,layer in enumerate(layers):
        # Same actual Attention output/residual/gates: isolates the fused boundary.
        inp=saved[i]['input']; old=saved[i]['boundary'];pre=layer.hc_mlp_layer.hc_pre
        out=hy4.triton_ihc_post_pre(*inp,pre.hc_fn.weight,pre.hc_scale,pre.hc_base,
                                  pre.magnitude,pre.hc_eps,pre.layernorm_epsilon)
        error=check_outputs(out,(old[0],old[2],old[1]))
        layer_error=metrics(snapshots[i]['layer'],saved[i]['layer'])
        row['layers'][i]=dict(boundary=error,layer_output=layer_error,
            cosine=torch.nn.functional.cosine_similarity(snapshots[i]['layer'].double().flatten(),saved[i]['layer'].double().flatten(),dim=0).item())
    row['logits']=[metrics(a,b) for a,b in zip(logits,base_logits)]
    correctness[n]=row
    for layer,original,handle in zip(layers,originals,handles):
        layer._post_attention_ihc=original;handle.remove()
    model.compute_logits=original_logits
    print('CORRECT',n,row,flush=True)
    (HERE/'model_correctness_hf.json').write_text(json.dumps(correctness,indent=2))
    del saved,snapshots,logits,base_logits

hy4.triton_ihc_post_pre=real_kernel

# Event hooks measure the real eager model and each DecoderLayer. No profiler.
starts={}; pending=[]; handles=[]
def pre_hook(module,args,kwargs):
    e=torch.cuda.Event(enable_timing=True);e.record();starts[id(module)]=e

def post_hook(module,args,kwargs,result):
    e=torch.cuda.Event(enable_timing=True);e.record()
    pending.append((id(module),starts[id(module)],e))
for module in [model,*layers]:
    handles.extend([module.register_forward_pre_hook(pre_hook,with_kwargs=True),
                    module.register_forward_hook(post_hook,with_kwargs=True)])
rows=[]
for n in (128,256,512,1024,4096,8192):
    for enabled in (False,True):
        mode(enabled)
        for _ in range(5):generate(n)
    row=dict(n=n,original=[],fused=[])
    for round_index in range(9):
        for enabled in ((False,True) if round_index%2==0 else (True,False)):
            mode(enabled);pending.clear();torch.cuda.synchronize();start=time.perf_counter()
            result=generate(n)
            torch.cuda.synchronize();wall=(time.perf_counter()-start)*1000
            per_module={}
            for key,a,b in pending:per_module.setdefault(key,[]).append(a.elapsed_time(b)*1000)
            measurement=dict(wall_ms=wall,forward_us=sum(per_module[id(model)]),
                layers_us=[sum(per_module[id(layer)]) for layer in layers])
            if result.metrics is not None:
                measurement['ttft_ms']=(result.metrics.first_token_time-result.metrics.arrival_time)*1000
            row['fused' if enabled else 'original'].append(measurement)
    rows.append(row)
    print('PERF',n,{k:statistics.median(v['forward_us'] for v in row[k]) for k in ('original','fused')},flush=True)
    (HERE/'model_performance_hf.json').write_text(json.dumps(dict(
        checkpoint='/data/chenhao/Hy4-preview-FP8-3-layers',layers=3,tp=1,gpu=torch.cuda.get_device_name(),
        graph=False,cache='warm model; prefix caching disabled; separate fresh request each call',
        timing='CUDA events in model/layer hooks, 5 warmups/arm/shape and 9 alternating rounds; no profiler',rows=rows),indent=2))
for handle in handles:handle.remove()
print('MODEL_AB_COMPLETE',flush=True)
