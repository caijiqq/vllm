"""Real slice iHC weights, synthetic boundary activations; not a layer E2E."""
import json
import statistics
import time
from pathlib import Path
from types import SimpleNamespace

import torch
from flashinfer.testing import bench_gpu_time_with_cudagraph
from safetensors import safe_open
from transformers import PretrainedConfig

from lab.ihc_fusion.baselines.official import official_post_pre
from lab.ihc_fusion.reference.torch_post_pre import torch_post_pre
from lab.ihc_fusion.tests.cases import check_outputs, make_case
from tests.models.test_hyv4_ihc_fusion import context
from vllm.config import VllmConfig, set_current_vllm_config
from vllm.distributed import init_distributed_environment, initialize_model_parallel
from vllm.forward_context import override_forward_context
from vllm.models.hy_v4.nvidia.hc import HYV4HCLayer
from vllm.models.hy_v4.nvidia.model import HYV4DecoderLayer
from vllm.models.hy_v4.nvidia.triton_ihc_post_pre import triton_ihc_post_pre

HERE=Path(__file__).parent
SLICE=Path('/data/chenhao/Hy4-preview-FP8-3-layers')
torch.backends.cuda.matmul.allow_tf32=False
config=PretrainedConfig(**json.loads((SLICE/'config.json').read_text()))
with set_current_vllm_config(VllmConfig()):
    init_distributed_environment(world_size=1, rank=0,
        distributed_init_method='file://'+str(HERE.resolve()/'boundary_dist'),local_rank=0)
    initialize_model_parallel(1,1)
    layer=HYV4DecoderLayer.__new__(HYV4DecoderLayer)
    torch.nn.Module.__init__(layer)
    layer.hc_attn_layer=HYV4HCLayer(config,0).cuda()
    layer.hc_mlp_layer=HYV4HCLayer(config,0).cuda()
layer.self_attn=SimpleNamespace(mla_attn=SimpleNamespace(layer_name='attn'))
layer._ihc_fusion_enabled=True
weights=[]
with safe_open(SLICE/'model.safetensors',framework='pt',device='cpu') as sf:
    for boundary in ('hc_attn_layer','hc_mlp_layer'):
        pre=getattr(layer,boundary).hc_pre
        for key,target in [('hc_fn',pre.hc_fn.weight),('hc_scale',pre.hc_scale),('hc_base',pre.hc_base)]:
            name='model.layers.0.'+boundary+'.hc_pre.'+key
            tensor=sf.get_tensor(name)
            assert tensor.shape==target.shape and tensor.dtype==target.dtype
            with torch.no_grad():target.copy_(tensor)
            weights.append(dict(key=name,shape=list(tensor.shape),dtype=str(tensor.dtype)))
pre=layer.hc_mlp_layer.hc_pre
rows=[]
for n in (128,256,512,768,1024,4096,8192):
    x,residual=make_case(n,6144,torch.bfloat16)[:2]
    _,previous=layer.hc_attn_layer.hc_pre(residual)
    args=(x,residual,previous,pre.hc_fn.weight,pre.hc_scale,pre.hc_base,
          pre.magnitude,pre.hc_eps,pre.layernorm_epsilon)
    def original():
        updated=layer.hc_attn_layer.post(x,residual,previous)
        output,post,updated=layer.hc_mlp_layer.pre(updated)
        return output,updated,post
    def fused():return triton_ihc_post_pre(*args)
    def routed():
        output,post,updated=layer._post_attention_ihc(x,residual,previous)
        return output,updated,post
    functions=dict(original=original,fused=fused,routed=routed)
    golden,baseline=torch_post_pre(*args),official_post_pre(*args)
    row=dict(n=n,d=6144,dtype='bfloat16',errors={},graph_us={},eager_wall_us={})
    with torch.inference_mode(),override_forward_context(context(n)):
        for name,fn in functions.items():
            actual=fn()
            row['errors'][name]=dict(official=check_outputs(actual,baseline),golden=check_outputs(actual,golden),
                cosine=torch.nn.functional.cosine_similarity(actual[0].double().flatten(),baseline[0].double().flatten(),dim=0).item())
            for _ in range(30):fn()
        for round_index in range(3):
            order=list(functions)
            if round_index%2:order.reverse()
            for name in order:
                fn=functions[name]
                samples=bench_gpu_time_with_cudagraph(fn,cold_l2_cache=False,
                    num_iters_within_graph=32,dry_run_time_ms=25,repeat_time_ms=100)
                row['graph_us'].setdefault(name,[]).append(statistics.median(samples)*1000)
                torch.cuda.synchronize();start=time.perf_counter()
                for _ in range(30):fn()
                torch.cuda.synchronize()
                row['eager_wall_us'].setdefault(name,[]).append((time.perf_counter()-start)*1e6/30)
        # Profiling follows all timers and is not included in reported latency.
        row['launches']={}
        for name,fn in functions.items():
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CUDA]) as p:
                fn();torch.cuda.synchronize()
            row['launches'][name]=[e.name for e in p.events() if e.device_type==torch.autograd.DeviceType.CUDA]
        assert len(row['launches']['routed'])==(1 if n>=512 else 3)
    rows.append(row)
    print(n,{k:round(statistics.median(v),3) for k,v in row['graph_us'].items()},flush=True)
    (HERE/'real_weight_boundary.json').write_text(json.dumps(dict(
        slice=str(SLICE),validation_scope='real iHC weights; synthetic attention output/residual; boundary only',
        gpu=torch.cuda.get_device_name(),weights=weights,cache='hot graph; fixed layer weights',
        eager_timing='host wall including allocation, route and GPU completion; 30 calls',rows=rows),indent=2))
    del args,x,residual,previous,golden,baseline,actual
    torch.cuda.empty_cache()
torch.distributed.destroy_process_group()
