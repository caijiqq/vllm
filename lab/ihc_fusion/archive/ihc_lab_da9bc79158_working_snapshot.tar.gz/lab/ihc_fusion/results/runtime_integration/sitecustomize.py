"""Use installed binary extensions with this source tree; no package edits."""
import importlib.util
import runpy
import sys
from pathlib import Path

import torch
import vllm

installed = Path('/usr/local/lib/python3.12/dist-packages/vllm')
vllm.__path__.append(str(installed))
for name in ('_vllm_fa2_C', '_vllm_fa3_C'):
    path = installed / 'vllm_flash_attn' / (name + '.abi3.so')
    qualified = 'vllm.vllm_flash_attn.' + name
    spec = importlib.util.spec_from_file_location(qualified, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[qualified] = module
    spec.loader.exec_module(module)
# This checkout omits the packaged FlashMLA Python interface as well.
import vllm.third_party.flashmla
vllm.third_party.flashmla.__path__.append(str(installed / 'third_party/flashmla'))
import vllm.third_party
vllm.third_party.__path__.append(str(installed / 'third_party'))
