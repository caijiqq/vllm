# HY4 同层 PostPre Runtime 集成验证

2026-10-21；分支 `exp/hy4-ihc-lab`，HEAD `078c5c6fa01258079ea508d526535b4a7cd15429`。

已完成默认关闭的 HY4 专属接入、135 项测试与真实三层权重切片 A/B。融合边界精度通过原有标准；三层模型的严格数值验收尚未闭合，不建议默认开启或宣称全量 HY4 收益。

## 1. 最小实现与调用边界

源码路径相对仓库根：

| 文件 | 改动 | 原因 |
|---|---:|---|
| `vllm/models/hy_v4/nvidia/model.py` | +81 / -5 | 初始化开关、纯 Prefill 元信息判断、同层边界替换 |
| `vllm/models/hy_v4/nvidia/triton_ihc_post_pre.py` | +111 | 独立生产 Kernel 与唯一薄入口 |
| `tests/models/test_hyv4_ihc_fusion.py` | +155 | 27 项边界、精度、回退、Graph Replay 测试 |

合计三个源码/测试文件，+347/-5；另有本目录复现脚本与实验记录。`runtime.patch` 只包含这三个文件，不包含用户原有 diff。冻结 Lab 与生产实现同时保留是为了维持历史实验可复现；生产代码不依赖 Lab。迁移的 C=4 Triton 函数 AST 与冻结函数完全相同，没有重新调参。

`HYV4DecoderLayer._forward_ihc`（model.py:264 附近）的原顺序：

```
Attention Pre → Input RMSNorm → Attention
→ Attention Post(x, residual, attention_gates)
→ MLP prepare_input → MLP Pre(updated, mlp_weights)
→ Post-Attention RMSNorm → MLP → MLP Post → 后续层/HCHead
```

新顺序仅把中间 Attention Post + MLP Pre 换为一次 `_post_attention_ihc`；适格时调用 Single，否则执行原来的三个 Python 调用。`hc.py:328` 的 prepare_input 对已是 `[N,4,D]` 的 residual 为 no-op。Kernel 返回 `(output, updated_residual, mlp_post_gates)`，边界适配为旧 Pre 的 `(output, mlp_post_gates, updated_residual)`；MLP Post、最终 HCHead、跨层状态均不变。

输入 x `[N,6144]` BF16、residual `[N,4,6144]` BF16、Attention gates `[N,4]` FP32；MLP W `[8,24576]`、scale `[2]`、base `[8]` 为 FP32。Post 乘加禁用 FMA，先写回 BF16 舍入值，再转 FP32 做投影/平方和；使用原 RMS epsilon、hc epsilon、magnitude。Grid `[N]`、4 warps，与 Lab 大 N 配置相同。单 Kernel 的分块归约树与官方不同，不要求 reduced output 或 gates 逐位一致，Residual 必须逐位一致。

## 2. 开关、路由与使用限制

```python
LLM(..., enforce_eager=True,
    hf_overrides={"enable_ihc_post_pre_fusion": True})
```

使用已有 hf_overrides，不增加公共环境变量/参数注册表。布尔值默认 False，初始化时读取一次。实际无 override 的三层模型初始化为 `[False,False,False]`，生成检查通过（`default_off.txt`）。

适格条件：启用 iHC、已测 H100 80GB HBM3、D=6144/C=4、BF16 contiguous 输入、FP32 gates/参数、同设备、512≤N≤8192；N 来自当前 x.shape[0]。只接受本层 MLACommonMetadata 明确标为纯 Prefill 的批次（num_prefills>0、num_decodes=0、num_decode_tokens=0、num_actual_tokens=N）。混合/未知/padded/ubatch、其他 dtype/shape/layout/设备均回退；不以 N 代替阶段判断。没有 tensor.item、GPU 同步、路由 Kernel 或每次环境变量读取。

初版仅允许 enforce_eager，关闭 speculative 与 batch-invariant 场景。torch.compile/自动 CUDA Graph 路径保持原实现，避免把动态阶段判断固化到图中。底层融合 Kernel 的独立 capture/replay 已验证，包括输入更新；这不等于 Runtime 自动 Graph 集成已完成。上限 8192 是本轮真实切片性能验证范围。维持用户初始 512 阈值：256 的热缓存收益不能推翻历史冷缓存/过渡区结果，不扩大阈值搜索。

## 3. 精度与回归

- 最终 `pytest_complete.txt`：**135 passed，14 项上游 DeprecationWarning，无失败**；原 Lab 108 项 + 新增 27 项。
- L1：N=64/128/256/511/512/513/768/1024/4096，BF16 D=6144 C=4，对独立 Golden 和官方三阶段执行冻结 check_outputs；Graph 更新输入后 replay 也通过。随机输入最大 output abs=0.03125、relative L2=2.04e-5，最小 cosine=0.99999999979；Residual 全部 exact；gate 最大 abs=3.58e-7。原有逐元素抵消误差预算及 L2 判据未变。
- 路由包含 511/512/513、8192/8193、关闭、FP16/FP32 回退、非6144、非连续、混合/Decode/未知 metadata、padding、Graph、ubatch。spy 断言实际选择，避免仅测到回退。冻结 Lab 的 FP32/BF16/FP16 回归全部通过；生产新路径只开放 BF16。
- L2：用原 Loader 完整加载已有 `/data/chenhao/Hy4-preview-FP8-3-layers`，实际配置 3 层、D=6144、C=4、64 heads、16 experts、ModelOpt MXFP8 权重、BF16激活、TP=1。并非根据目录名假设 TP16 可加载；没有下载或改权重/Loader。
- N=512/1024 的真实模型运行各触发 3 次融合，后续 Decode 未融合。捕获每层真实 Attention output/residual/gates，固定相同输入重算融合边界，六个比较均通过冻结标准。output 最大 abs=0.0009765625，relative L2≤2.971e-5；gate最大 abs=2.384e-7，relative L2≤2.995e-7；Residual exact。
- 完整三层生成两 token 均相同：N512 `[114664,99979]`，N1024 `[232,31767]`。但这只是短序列 smoke。

| N | 三层输出 A/B relative L2（逐层） | 原路径 A/A relative L2（逐层） | A/B logits relative L2（两步） |
|---:|---|---|---|
| 512 | 0.005992 / 0.006996 / 0.010007 | 0.006175 / 0.007065 / 0.012219 | 0.008007 / 0.007318 |
| 1024 | 0.001123 / 0.003774 / 0.007588 | 0.001219 / 0.004282 / 0.005367 | 0.005182 / 0.008619 |

模型输出 A/B cosine 最低 0.9999499。原路径 N512 第一层融合边界之前的 Attention output 已出现 A/A relative L2=0.003838，而对应 residual/gates exact；N1024 第一层边界输入 A/A exact、层输出出现差异。这证明模型比较受融合边界外的重复运行差异影响，但不能证明全部 A/B 差异都来自该因素。没有对模型另设宽松阈值或把上述数值宣称为精度通过。严格模型精度验收仍需可重复的同层输入/Attention 状态与 MoE 执行对照；本轮未改这些公共/非目标算子。

## 4. 性能证据

设备 H100 80GB HBM3，Torch 2.13.0+cu129、Triton 3.7.1、CUDA12.9、driver575.57.08。完整软件/导入路径见 `environment.json`。

### 边界算子

真实第0层 HC 参数，合成 Attention output/residual；不是完整 Layer Forward。热缓存 CUDA Graph；每路径30次warmup，25ms graph warmup，3轮×100ms，32次调用/graph，报告各轮中位数的中位数。计入整个 Post+Pre 或 Single；GPU计时不计 Python 分配/判断。独立 eager wall 记录包含它们，详见原始 JSON。Profiler 在计时之后独立运行，Original=3、适格 Routed=1 个 Kernel，无额外路由 Kernel。

| N | Original μs | Single μs | Routed μs | Original / Single |
|---:|---:|---:|---:|---:|
| 128 | 21.866 | 19.875 | 21.848 | 1.100× |
| 256 | 40.344 | 25.586 | 40.375 | 1.577× |
| 512 | 80.895 | 69.823 | 69.767 | 1.159× |
| 768 | 120.477 | 82.968 | 83.029 | 1.452× |
| 1024 | 161.422 | 119.088 | 119.117 | 1.355× |
| 4096 | 651.690 | 438.294 | 438.435 | 1.487× |
| 8192 | 1300.265 | 854.051 | 852.646 | 1.522× |

128/256 的 Routed 实际回退。512以上 eager 路由相对直接 Single 额外约1–5 μs，未抵消测得的边界收益。此热缓存结果不代表所有层间缓存；本轮未重跑冷缓存全表，也未覆盖历史结果。

### 实际三层模型 Forward

相同模型实例/权重/输入，TP1、enforce_eager、prefix caching off、max_num_batched_tokens8192、max_model_len8448；每次新请求、生成1 token。每个Shape每路径5次warmup，9轮交替A/B。CUDA Events挂在真实 model/layer forward两端，包含 eager launch间隙；无Profiler，无编译时间。中位值及样本min–max如下（非置信区间）：

| N | Original μs | Enabled μs | 比值 | Original 范围 μs | Enabled 范围 μs |
|---:|---:|---:|---:|---:|---:|
| 128 | 9163.264 | 9700.416 | 0.945× | 8954–10569 | 8954–10348 |
| 256 | 9729.856 | 9370.560 | 1.038× | 9092–9984 | 9129–9552 |
| 512 | 9776.288 | 9601.856 | 1.018× | 9348–10261 | 9194–9929 |
| 1024 | 11105.728 | 10991.616 | 1.010× | 11026–11350 | 10881–11324 |
| 4096 | 38797.760 | 37962.143 | 1.022× | 38731–39092 | 37819–38348 |
| 8192 | 78634.590 | 76990.562 | 1.021× | 77858–79258 | 76186–78784 |

128/256 没有融合，偏离1的比值体现噪声/漂移，不能算作性能收益或确定回归。512/1024 的幅度与部分测量波动重叠；4096 两组样本范围分离，8192范围有重叠。因此仅报告切片实测中位值，不承诺普遍1–2%模型收益。

逐层中位时间及请求wall如下；各层中位数之和不必等于 model 中位时间。

| N | Layer 0 Original/Enabled μs | Layer 1 Original/Enabled μs | Layer 2 Original/Enabled μs | Request wall Original/Enabled ms |
|---:|---:|---:|---:|---:|
| 128 | 2447.0/2469.6 | 3446.0/3612.5 | 2723.9/2911.7 | 12.479/13.115 |
| 256 | 2728.7/2674.5 | 3466.6/3366.6 | 2897.8/2850.6 | 13.243/12.890 |
| 512 | 2961.0/2821.2 | 3606.7/3504.7 | 2902.8/2832.5 | 13.203/13.086 |
| 1024 | 4073.8/4024.8 | 3304.5/3254.0 | 3157.8/3110.8 | 15.435/15.384 |
| 4096 | 11784.5/11514.2 | 12862.3/12620.9 | 12414.4/12134.7 | 46.948/46.081 |
| 8192 | 23216.3/22657.7 | 26276.6/25840.6 | 25622.7/25218.8 | 90.349/88.098 |

请求 wall 包含引擎、采样和Python成本，不标为 TTFT：此次结果对象未提供独立 TTFT metrics。未测在线服务 Prefill吞吐；没有将三层切片外推为完整78层模型、TP16或生产TTFT。

## 5. 复现与环境

当前源码树缺少构建扩展及部分随wheel发布的 FlashMLA/DeepGEMM接口，实验通过本目录 `sitecustomize.py` 将已安装 vLLM 0.32.0+cu129 的对应包路径/二进制加入当前进程。模型/HC/Kernels仍从本 checkout 导入（`environment.json`）；没有修改安装包、公共 Loader 或源码路径。此混合源码/预编译环境是本次验证限制，正式发布需匹配构建环境再验。

```bash
export PYTHONPATH="$PWD/lab/ihc_fusion/results/runtime_integration:$PWD"
export PYTHONDONTWRITEBYTECODE=1
export TRITON_CACHE_DIR="$PWD/lab/ihc_fusion/results/.cache/triton"
export VLLM_CACHE_ROOT="$PWD/lab/ihc_fusion/results/.cache/vllm"
CUDA_VISIBLE_DEVICES=2 lab/ihc_fusion/results/.venv/bin/python -m pytest tests/models/test_hyv4_ihc_fusion.py lab/ihc_fusion/tests -q -p no:cacheprovider
# 下列记录脚本会写本目录同名JSON；复现实验须先换新输出位置，保留本次记录。
CUDA_VISIBLE_DEVICES=2 lab/ihc_fusion/results/.venv/bin/python lab/ihc_fusion/results/runtime_integration/validate_boundary.py
CUDA_VISIBLE_DEVICES=3 lab/ihc_fusion/results/.venv/bin/python lab/ihc_fusion/results/runtime_integration/validate_model.py
RUFF_CACHE_DIR="$PWD/lab/ihc_fusion/results/.cache/ruff" lab/ihc_fusion/results/.venv/bin/ruff check vllm/models/hy_v4/nvidia/model.py vllm/models/hy_v4/nvidia/triton_ihc_post_pre.py tests/models/test_hyv4_ihc_fusion.py
```

上述 Ruff check、三个文件 format --check、git diff --check 均通过。新测试使用现有 dist_init 和冻结Lab误差工具；需要CUDA及仓库测试依赖（本次venv补装tblib3.2.2供根conftest使用）。没有改CI公共配置，真实切片验证目前为本机手动覆盖。

## 6. 范围审计、PR准备与遗留事项

`scope_audit.json` 核对119个已有Lab文件的SHA256全部不变；开始时用户的 tracked diff与未跟踪Lab文件原样保留。官方Pre/Post哈希仍为 `9765c65453dd2d1b9828e82790ece36a304c7c8f6f54229b146cbfdbd5e9094a`。没有修改公共模块、其他模型、Lab冻结代码或历史数据；没有新增公共API、提交、推送或创建PR。

已执行 pr-checklist 自审，设计范围与代码质量检查通过。提交前还需人工逐行审查和复跑；模型精度/自动Graph覆盖不足如上，不能将135个算子/路由测试替代模型质量评测。`gh` 不可用；GitHub连接器的开放PR检索（ihc、HY4、PostPre）因认证不可用未取得结果，且没有提供关联issue号，重复工作检查未完成，不能宣称无重复PR。

下一步最有价值的是在匹配构建、受控可重复的模型执行环境下关闭模型数值验收缺口，随后验证完整模型质量。暂不继续Kernel调参、不扩大Dispatch。默认编译/自动Graph模式仍回退，需要单独设计阶段元信息处理与验证后才能覆盖该部署模式。当前改动适合独立审查的实验性接入，尚不足以默认开启生产优化。
