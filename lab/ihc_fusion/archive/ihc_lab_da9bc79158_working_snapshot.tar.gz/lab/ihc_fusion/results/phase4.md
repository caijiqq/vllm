# Phase 4: expanded correctness accepted

53 GPU tests passed on H100, including FP32/BF16/FP16 N=4096,D=7168 and N=1024,D=3072;
non-power-of-two hidden sizes; C=1,3,4; offset views; zero, tiny, large, cancellation,
saturated inputs. Test output: phase4_pytest.txt. Case metrics: phase4_correctness.json.
Worst errors by dtype: phase4_summary.json. Residual is bitwise equal throughout.

A real torch.profiler CUDA trace observed exactly one _fused_post_pre launch
versus the three original official kernels (phase4_launches.json). Preallocated
fused outputs match the same frozen comparison rules. Golden, baseline, tolerance
hashes verified unchanged. No arbitrary tolerance relaxation during implementation.

Changed: tests/test_post_pre.py and results/phase4_* artifacts. No performance
measurements yet. No unresolved correctness blocker. All tracked diffs empty;
all new files are inside Lab except the pre-existing ihc_idea.md. No scope expansion.

Environment has no cupti-python. Phase 5 will explicitly report FlashInfer CUDA
Graph + CUDA Event timing with rotating buffers for cold L2, rather than claim CUPTI.
Official baseline configs stay fixed as requested, not tuned away from upstream.
