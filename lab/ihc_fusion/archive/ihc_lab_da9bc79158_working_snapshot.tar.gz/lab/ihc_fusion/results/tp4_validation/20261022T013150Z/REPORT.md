# HY4 iHC TP4 验证：功能已运行，数值对照阻塞性能结论

结论选择 **D：TP4 数值验证条件未闭合，不能判断约10%的性能假设**。

四个H100上的权重加载和三种模式推理均成功，没有修改公共Runtime或模型配置适配权重。N512的Original重复执行已经出现明显A/A差异；Intra/Cross也未通过沿用的链路逐元素诊断检查。因此实验在N512后停止，未运行N8192正式Benchmark或GPU Activity Profiling。不能给出TP4耗时占比、speedup、延迟下降比例或置信区间。

## 已确认的功能与结构

- 分支：`exp/hy4-ihc-lab`；HEAD：`223ebbf62d906e8bb3a5c017d8ae9c3fcbd98868`。同层与跨层Runtime均已提交；原有未提交改动只有Benchmark文件的修改，另有未跟踪实验产物。
- checkpoint：`/data/chenhao/Hy4-preview-FP8-3-layers`，与历史验证脚本使用的路径一致。实际读取config及safetensors header，确认3个DecoderLayer、16 Routed Experts、top-k8、D6144、C4、ModelOpt MXFP8；第一层Dense，后两层MoE。权重文件约6.50GiB，packed专家权重为F8_E4M3，group32 scale为U8；HC投影为FP32 `[8,24576]`。配置SHA256与实际Tensor布局保存在raw/，没有保存权重值。
- 固定物理GPU **1、2、3、5**。启动前均17MiB、0%利用率，无计算进程；互联NV18。8张卡并非未经检查就默认选择0–3。结束后所选卡均恢复17MiB、0%，4个Worker正常退出。
- Docker环境；Python3.12.3、Torch2.13.0+cu129、Triton3.7.1、已装vLLM0.32.0+cu129、Humming0.1.17、FlashInfer0.7.0.post1。复用既有sitecustomize将checkout Python与已有二进制扩展配合，不安装依赖。
- 标准LLM：TP4/PP1、mp executor、Eager、max_model_len8448、max_num_batched_tokens8192、gpu_memory_utilization0.65、max_num_seqs4、prefix cache关闭。框架默认通信/JIT初始化照常进行，未调参；初始化不计时。
- 四个Worker均完成加载，每rank模型占约2.38GiB。日志选择`HummingMxfp8LinearKernel`及`HUMMING` MXFP8 MoE indexed GEMM，短Prompt和N512三种模式均执行完成。未发生权重shape、MXFP8加载或分布式初始化错误。
- 初始化hf_overrides同时开启同层与跨层。通过现有`LLM.apply_model`在**所有Worker**上切换模式，每次检查返回rank恰为0/1/2/3、world_size4以及三个层的开关。没有仅修改rank0，没有替换公共类或全局算子。

初始Cross开关在每rank均为：层0 `(intra=True,defer=True)`、层1同样、层2 `(True,False)`。Original全部False；Intra各层intra=True、defer=False。完整状态见`raw/initial_workers.json`、`raw/smoke.json`。

|运行时观测（每rank相同）|实际结果|解释|
|---|---|---|
|Attention local heads|16|64个heads按TP4分片|
|q_b_proj output partition|4096|全局16384的四分之一|
|kv_b_proj output partition|7168|全局28672的四分之一|
|o_proj input partition|4096|全局16384的四分之一|
|Dense gate_up output partition|9216|2×18432/4|
|Dense down input partition|4608|18432/4|
|fused_qkv_a_proj|input6144/output2624、tp_size1|明确复制；不能假设整个Attention四等分|
|iHC Pre input，N512|`[512,4,6144]` BF16|四rank上均实际观察到完整Residual|
|iHC projection weight|`[8,24576]` FP32|四rank均完整|
|Cross pending Residual，N512|每rank两次`[512,4,6144]`|层间状态保持完整维度|

MoE源码按intermediate2048/TP4=512分片，满足MXFP8 group32；Humming并行配置检查接受TP。`HYV4MoEFused.ep_size=4`是其所引用group大小，**不能仅凭此字段断言启用了Expert Parallel或每rank只有4专家**。本轮未对RoutedExperts最终packed对象和通信时间线进一步取证，不能量化EP/ETP行为与性能。

## 数值结果与停止原因

固定Prompt token `100 + i % 197`，Sampling temperature0、seed7、max_tokens1；每次采样前所有Worker torch.manual_seed7。N64三种模式均成功、生成Token一致；N64走原始回退路径。

N512先Original预热5次，然后A、A重复、Intra、Cross。观察顶层模型Forward的完整BF16输出`[512,6144]`（HCHead/最终norm之后、Logits之前），保存指标而不保存激活值。四个rank得到相同的以下统计值；这是每rank统计一致，未单独执行跨rank逐位Tensor比较。

|相对第一次Original|max_abs|relative L2|Cosine|逐元素超限数/总数|生成Token|
|---|---:|---:|---:|---:|---:|
|Original A/A|0.281250|0.01277091|0.99991845|1,081,016 / 3,145,728（34.4%）|114664|
|Intra A/B|0.2890625|0.01238919|0.99992325|1,071,062 / 3,145,728（34.0%）|114664|
|Cross A/B|0.2197265625|0.01210026|0.99992679|1,087,096 / 3,145,728（34.6%）|114664|

全部输出有限，生成Token相同。检查使用现有`test_cross_layer_pending_chain`的`rtol=2*BF16.eps=0.015625, atol=2e-5`，未放宽阈值。**该规则原本用于合成链路，本轮用于模型输出的保守诊断门槛，不是既已建立的完整模型正式精度标准。** 此结果证明当前A/A不能提供稳定的逐元素数值对照；不能据此宣布TP4融合引入了新Bug，也不能因为A/B与A/A同量级就宣布通过。

历史TP1也已有A/A波动：`results/cross_layer_integration/model_correctness.json`在N512中首次已记录的非零差异位于Attention0输出（rel_L2约0.003883），最终层输出约0.008158。它与本轮最终norm后输出不是同一观测点，不能直接相减或作为容差。TP4本轮未保存逐层激活，因此**最早差异出现在哪个TP4算子仍未知**，不能归因给iHC、NCCL或Humming。

本轮N512各rank观察到原始HC Pre模块调用数为Original6、Intra3、Cross1，Cross另有两次pending状态；与预期路由一致。但没有继续采集GPU Trace，**不能把模块调用减少直接写成已由GPU Trace验证的3/5次Fused命中**。首层Pre有调用证据；末层Post通过源码与正常输出结构间接支持，未独立计数。

已按用户的正确性停止条件终止后续正式性能阶段，未运行N8192比较，未尝试改阈值、改Kernel或公共Runtime。现有161 passed / 1 failed及模型严格A/A、A/B未闭合状态不变。

## TP1/TP4对比与假设判断

|指标|TP1历史实测，N8192|TP4本轮|
|---|---:|---|
|GPU数量|1|4，已实际加载/执行|
|checkpoint|同一路径三层MXFP8|配置与Tensor布局已核实|
|iHC原始GPU活动占比|约10.6%|未测|
|五个可融合边界占比|约8.8%|未测|
|Original Forward|78.185ms|未测|
|Intra Forward|76.972ms|未测|
|Cross Forward|76.234ms|未测|
|Original/Cross|约1.026×，配对中位数约1.030×|不可判断|
|Intra/Cross|约1.010×|不可判断|
|Fusion命中数量|每次Forward5，由Trace确认|GPU Trace未采集；仅N512模块观测符合路由|
|延迟下降比例、P10/P90、配对方差|见历史报告|未测，不以初始化/生成日志推算|

**Q1：iHC耗时占比是否被TP4放大？尚不能回答。** 实际确认了N512下iHC完整维度复制与部分Linear分片，支持结构性假设的一部分；缺少N8192耗时归因与通信/重叠证据，不能把结构事实转换成占比结论。

**Q2：是否接近10%？结论D。** 1.10×意味着约9.09% latency reduction，10% latency reduction对应约1.111×；两者本轮均没有实测。没有生成Kernel Activity、模型Forward或generate墙钟性能数据，更未测全量模型E2E。

下一步最小必要工作是另行授权后，在Original模式定位TP4 A/A最早差异阶段（逐层Attention/MLP输入输出，控制请求/KV状态），先建立可靠的数值比较。当前不能指定需要修改哪个公共模块，也没有理由进行公共修复。若数值条件随后可用，才启动9轮交替Original/Intra/Cross，使用每rank事件并取MAX、单独采集四卡Trace；本轮未提前编写未使用的性能框架。

## 复现与文件

从repo根目录，选择新的results子目录以免覆盖：

```bash
export HY4_TP4_RUN="$PWD/lab/ihc_fusion/results/tp4_validation/<new-run>"
export HY4_TP4_CHECKPOINT=/data/chenhao/Hy4-preview-FP8-3-layers
mkdir -p "$HY4_TP4_RUN/raw"
bash lab/ihc_fusion/benchmarks/tp4_validation/run.sh \
  lab/ihc_fusion/benchmarks/tp4_validation/inspect_environment.py \
  > "$HY4_TP4_RUN/raw/environment.log" 2>&1
bash lab/ihc_fusion/benchmarks/tp4_validation/run.sh \
  lab/ihc_fusion/benchmarks/tp4_validation/validate.py \
  > "$HY4_TP4_RUN/raw/validation.log" 2>&1
```

本轮实际子目录为`20261022T013150Z`。再次运行前必须重新确认GPU1/2/3/5空闲。run.sh固定这四张卡、复用已有Python环境，并将Triton/CUDA/vLLM/Inductor/FlashInfer缓存放入该次results目录。未更改全局环境/时钟/功耗/权限。首次通信模块JIT约耗时一分钟，属于标准初始化，不能当作性能测量。

新增实验脚本仅四个：

- `benchmarks/tp4_validation/run.sh`：隔离环境与固定GPU。
- `benchmarks/tp4_validation/inspect_environment.py`：初始Git/文件哈希、实际checkpoint布局、GPU环境。
- `benchmarks/tp4_validation/workers.py`：现有apply_model API回调、逐rank开关检查及实例hook观察。
- `benchmarks/tp4_validation/validate.py`：标准TP4初始化、三模式Smoke与数值门槛。

主要原始文件：`raw/environment.json`、`checkpoint_layout.json`、`packed_expert_layout.json`、`initial_workers.json`、`smoke.json`、`correctness_512.json`、`STOP.json`、`validation.log`。完整新增文件清单见`raw/artifact_manifest.json`（含隔离编译缓存）；完整范围核对见`raw/scope_audit.json`。报告和实验日志均在本次results目录。

最终核对：8137个已有文件/symlink全部一致；原始Git diff逐字节一致，HEAD未变，暂存区为空。`git diff --check`与新增Python脚本语法检查通过。未执行git add/commit/push/stash/reset/clean，未改公共源码、现有实验数据或其他用户文件。
