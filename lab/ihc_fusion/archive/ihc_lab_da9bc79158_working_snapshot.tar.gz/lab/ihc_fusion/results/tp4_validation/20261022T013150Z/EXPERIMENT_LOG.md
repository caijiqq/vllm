# TP4 experiment log

2026-10-22T01:33:32.888090+00:00 E00: branch/HEAD/diff snapshot and checkpoint layout verified. Selected physical GPUs1,2,3,5: each17MiB,0%, no compute processes; all connectedNV18. Runtime changes committed; only existing benchmark diff remains. Config3layers/16experts/top8/D6144/C4/ModelOptMXFP8. Shape arithmetic permitsTP4; actual backend compatibility remains to be tested. No package installation or source modification.

2026-10-22T01:35:10.612027+00:00 E01 start: standard LLM initialization TP4/PP1/mp/eager with existing checkpoint, both fusion flags initialized True; all-worker RPC will verify and switch modes. No global class or operator replacement.

2026-10-22T01:37:42.994668+00:00 E01 loaded: four distinct TP ranks returned, initialization flags agree. Runtime partitions saved in initial_workers.json.

Read-only source evidence before timing: attention.py:316 divides64heads byTP4→16; q_b_proj/kv_b_proj column-parallel and o_proj row-parallel at394–423. fused_qkv_a_proj explicitlydisable_tp=True at372–380; Indexer.wq_b and wk_weights_proj replicated at157–173. DenseI18432→4608/rank; MoEI2048→512/rank, divisiblebyMXFP8group32. modelopt.py:1289–1298 and2297–2301 enforcegroupalignment; fused_humming_moe.py:417 accepts parallelconfig. HummingMxfp8LinearKernel.can_implement returnsTrue. These are source eligibility facts, not proof of successful forward or quartered Attention/MLP runtime. ExpertpackedFP8 shapes recorded separately; exact checkpointconfig andabsolute path in checkpoint_layout.json.

2026-10-22T01:37:24Z initialization still compiling: observed nvrtc_compile subprocesses owned by experiment workers; shared-memory RPC60s warning is consistent with ongoing compilation, not yet classified as a hang. All new CUDA/Triton caches remain under this run directory.

2026-10-22T01:38:40.891640+00:00 E02 short N64 inference completed in three modes; tokens match. This N falls back to original; it does not prove fusion execution.

2026-10-22T01:38:41.244239+00:00 E03 N512: all-rank final hidden comparison and A/A recorded; existing-chain diagnostic rule pass=False. Strict full-model acceptance is not inferred.

2026-10-22T01:42:13.287476+00:00 E04 stop and analysis: initialization1run, fourTP workers all loaded; N64 three-mode tokens identical. N512 all outputs finite and tokens identical, but OriginalA/A relL2=0.01277091/max_abs0.28125 already fails the existing chain diagnostic rule. Intra/Cross relL2≈0.01239/0.01210, not automatically accepted against this noisy baseline. FourWorker states verified using all returned ranks. N8192 timing and all-rankGPU trace not started. Executor reports all4workers exited gracefully. ExistingTP1 already had A/A differences, so no claim of newly introducedTP4/fusionbug. Final classificationD, numerical comparison not closed.

2026-10-22T01:43:04.776071+00:00 E05 final scope audit: 8137 prior files/symlinks unchanged, original tracked diff identical, HEAD unchanged, no staged files, no new file outside two allowlisted directories. git diff --check and audit-script AST parse passed. No public source/kernel/Golden/Baseline modified. GPU state and complete new-file manifest saved.
