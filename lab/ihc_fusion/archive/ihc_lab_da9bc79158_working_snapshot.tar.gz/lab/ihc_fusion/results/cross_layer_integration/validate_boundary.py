"""Real layer-0 MLP weights/gates and layer-1 Attention Pre; synthetic activations."""
import json
import statistics
from pathlib import Path
from types import SimpleNamespace

import torch
from flashinfer.testing import bench_gpu_time_with_cudagraph
from safetensors import safe_open
from transformers import PretrainedConfig
from vllm.config import VllmConfig, set_current_vllm_config
from vllm.distributed import init_distributed_environment, initialize_model_parallel
from vllm.forward_context import override_forward_context
from vllm.models.hy_v4.nvidia.hc import HYV4HCLayer
from vllm.models.hy_v4.nvidia.model import HYV4DecoderLayer
from vllm.models.hy_v4.nvidia.triton_ihc_post_pre import triton_ihc_post_pre
from lab.ihc_fusion.baselines.official import official_post_pre
from lab.ihc_fusion.reference.torch_post_pre import torch_post_pre
from lab.ihc_fusion.tests.cases import check_outputs, make_case
from tests.models.test_hyv4_ihc_fusion import context

HERE=Path(__file__).parent
SLICE=Path('/data/chenhao/Hy4-preview-FP8-3-layers')
config=PretrainedConfig(**json.loads((SLICE/'config.json').read_text()))
with set_current_vllm_config(VllmConfig()):
    init_distributed_environment(world_size=1, rank=0,
        distributed_init_method='file://'+str(HERE.resolve()/'dist'),local_rank=0)
    initialize_model_parallel(1,1)
    layer=HYV4DecoderLayer.__new__(HYV4DecoderLayer)
    torch.nn.Module.__init__(layer)
    layer.hc_attn_layer=HYV4HCLayer(config,1).cuda()
    layer.hc_mlp_layer=HYV4HCLayer(config,0).cuda()
layer.self_attn=SimpleNamespace(mla_attn=SimpleNamespace(layer_name='attn'))
layer._ihc_fusion_enabled=True
with safe_open(SLICE/'model.safetensors',framework='pt',device='cpu') as sf:
    for index,sub in [(0,'hc_mlp_layer'),(1,'hc_attn_layer')]:
        pre=getattr(layer,sub).hc_pre
        for key,target in [('hc_fn',pre.hc_fn.weight),('hc_scale',pre.hc_scale),('hc_base',pre.hc_base)]:
            with torch.no_grad():target.copy_(sf.get_tensor(f'model.layers.{index}.{sub}.hc_pre.{key}'))
pre=layer.hc_attn_layer.hc_pre
rows=[]
with torch.inference_mode():
    for n in (128,256,512,1024,4096,8192):
        x,residual=make_case(n,6144,torch.bfloat16)[:2]
        _,previous=layer.hc_mlp_layer.hc_pre(residual)
        args=(x,residual,previous,pre.hc_fn.weight,pre.hc_scale,pre.hc_base,
              pre.magnitude,pre.hc_eps,pre.layernorm_epsilon)
        def original():
            updated=layer.hc_mlp_layer.post(x,residual,previous)
            output,post,updated=layer.hc_attn_layer.pre(updated)
            return output,updated,post
        def fused():return triton_ihc_post_pre(*args)
        def routed():
            output,post,updated=layer._ihc_post_pre(x,residual,previous,pre_attention=True)
            return output,updated,post
        row=dict(n=n,errors={},graph_us={})
        with override_forward_context(context(n)):
            baseline,golden=official_post_pre(*args),torch_post_pre(*args)
            for name,fn in [('original',original),('fused',fused),('routed',routed)]:
                actual=fn()
                row['errors'][name]=dict(official=check_outputs(actual,baseline),golden=check_outputs(actual,golden),
                    cosine=torch.nn.functional.cosine_similarity(actual[0].double().flatten(),baseline[0].double().flatten(),dim=0).item())
                for _ in range(30):fn()
            for repeat in range(3):
                functions=[('original',original),('fused',fused),('routed',routed)]
                if repeat%2:functions.reverse()
                for name,fn in functions:
                    samples=bench_gpu_time_with_cudagraph(fn,cold_l2_cache=False,
                        num_iters_within_graph=32,dry_run_time_ms=25,repeat_time_ms=100)
                    row['graph_us'].setdefault(name,[]).append(statistics.median(samples)*1000)
        rows.append(row)
        (HERE/'boundary.json').write_text(json.dumps(dict(gpu=torch.cuda.get_device_name(),dtype='bfloat16',
            d=6144,c=4,previous='layer0 MLP',next='layer1 Attention',cache='hot CUDA Graph',rows=rows),indent=2))
        print('BOUNDARY',n,row['graph_us'],flush=True)
