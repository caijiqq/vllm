"""Compare the committed intra path against new intra/cross with identical tensors."""
import ast
import json
import subprocess
from pathlib import Path
from types import MethodType

import torch
from transformers import PretrainedConfig
from vllm.config import VllmConfig, set_current_vllm_config
from vllm.distributed import init_distributed_environment, initialize_model_parallel
from vllm.forward_context import override_forward_context
from vllm.models.hy_v4.nvidia import model as hy4
from vllm.models.hy_v4.nvidia.hc import HYV4HCLayer
from lab.ihc_fusion.tests.cases import make_case, metrics
from tests.models.test_hyv4_ihc_fusion import context, _TestAttention

HERE=Path(__file__).parent
source=subprocess.check_output(['git','show','ad3e62549:vllm/models/hy_v4/nvidia/model.py'],text=True)
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='HYV4DecoderLayer')
functions=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('_post_attention_ihc','_forward_ihc')]
namespace=dict(vars(hy4))
exec(compile(ast.Module(body=functions,type_ignores=[]),'<committed HY4 methods>','exec'),namespace)
torch.manual_seed(7)
config=PretrainedConfig(enable_ihc=True,hidden_size=6144,hc_mult=4,hc_magnitude=2.,hc_eps=1e-6,rms_norm_eps=1e-5)
layers=[]
with set_current_vllm_config(VllmConfig()):
    init_distributed_environment(world_size=1,rank=0,distributed_init_method='file://'+str(HERE.resolve()/'diag_dist'),local_rank=0)
    initialize_model_parallel(1,1)
    for i in range(3):
        layer=hy4.HYV4DecoderLayer.__new__(hy4.HYV4DecoderLayer)
        torch.nn.Module.__init__(layer)
        layer.enable_ihc=True
        layer.hc_attn_layer=HYV4HCLayer(config,i).cuda()
        layer.hc_mlp_layer=HYV4HCLayer(config,i).cuda()
        layer.self_attn=_TestAttention(f'attn{i}')
        layer.input_layernorm=torch.nn.Identity()
        layer.post_attention_layernorm=torch.nn.Identity()
        layer.mlp=torch.nn.SiLU()
        layer._post_attention_ihc=MethodType(namespace['_post_attention_ihc'],layer)
        with torch.no_grad():
            for j,hc in enumerate((layer.hc_attn_layer,layer.hc_mlp_layer)):
                hc.hc_pre.hc_fn.weight.normal_(std=.002*(1+i+j))
                hc.hc_pre.hc_base.fill_(.1*(i+j))
        layers.append(layer)
n=8192
x=make_case(n,6144,torch.bfloat16)[1]
positions=torch.arange(n,device='cuda')
ctx=context(n)
ctx.attn_metadata={f'attn{i}':next(iter(ctx.attn_metadata.values())) for i in range(3)}
outputs={}
with torch.inference_mode(),override_forward_context(ctx):
    for mode in ('original','committed_intra','new_intra','cross'):
        hidden,pending=x,None
        for i,layer in enumerate(layers):
            layer._ihc_fusion_enabled=mode!='original'
            layer._ihc_defer_post=mode=='cross' and i<2
            if mode in ('original','committed_intra'):
                hidden,pending=namespace['_forward_ihc'](layer,positions,hidden)
            else:
                hidden,pending=layer(positions,hidden,pending)
        assert pending is None
        outputs[mode]=hidden
    report={}
    for name,actual in outputs.items():
        expected=outputs['original']
        error=(actual.float()-expected.float()).abs()
        mismatch=error>2e-5+2*torch.finfo(torch.bfloat16).eps*expected.float().abs()
        report[name]=dict(metrics=metrics(actual,expected),pointwise_mismatches=int(mismatch.sum()),
            cosine=torch.nn.functional.cosine_similarity(actual.double().flatten(),expected.double().flatten(),dim=0).item())
    report['new_intra_bitwise_equals_committed']=torch.equal(outputs['new_intra'],outputs['committed_intra'])
    assert report['new_intra_bitwise_equals_committed']
(HERE/'chain_diagnosis.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
