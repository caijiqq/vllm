## Summary

- Reuse the existing HY4 Single PostPre kernel across local DecoderLayers by carrying pending MLP residual/gates to the next Attention Pre.
- Share the existing eager-only shape/metadata routing; flush Post at each local PP stage end and before HCHead. Cross-layer fusion is separately opt-in through HY4 HF overrides.
- Only HY4 NVIDIA model code and its dedicated fusion tests change; no kernel algorithm, public runtime, or frozen Lab changes.

## Tests

- Real TP1 three-layer H100 slice confirms 3 intra-layer + 2 cross-layer fusions, correct first/last boundaries, and zero fusions at unsupported N128/256.
- All real same-input boundaries pass frozen Golden/official checks. Original/Intra/Cross generate identical two-token results at N512/1024.
- Full regression has one **unresolved** N8192 synthetic-chain pointwise failure; committed Intra and new Intra reproduce it identically. Model A/A also differs before fusion; strict whole-model accuracy is not established. See REPORT.md and pytest_final.txt.
- Ruff / format / diff checks pass. Nine paired eager rounds measure model Forward 38.949→38.181→37.824 ms at N4096 and 78.360→76.959→76.122 ms at N8192 (Original→Intra→Cross); not full-model TTFT claims.
- PP execution, automatic graphs/compile and H200 E2E remain unvalidated. AI assistance was used; human review, duplicate-work checks and the numerical validation gap must be resolved before publication. No PR created.
