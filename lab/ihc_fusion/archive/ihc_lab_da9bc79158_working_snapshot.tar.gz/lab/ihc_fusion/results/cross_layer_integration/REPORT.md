# HY4 跨层 PostPre：最小 Runtime 实现与验证

起点：`exp/hy4-ihc-lab`，Commit `ad3e62549ad5948df493dd4f8b0506cf236bb960`（同层融合基线已提交）。本轮不提交代码。

结论：已实现默认关闭的跨层融合，真实三层切片确认 3 次同层+2 次跨层调用，各独立边界通过冻结精度标准；实际模型有小幅额外收益。严格整体数值验收尚未完成，新增合成链路检查仍有1项失败，不宣称全部测试通过或可默认开启。

## 调用链、接口与范围

原始每层：Attention Pre → norm → Attention → Attention Post → MLP Pre → norm → MLP → MLP Post。

新路径：第0层原始 Attention Pre → Attention →同层 Fused → MLP →携带 `(residual, mlp_post_gates)` 与单流 MLP 输出；第1/2层先以本层 Attention Pre 参数融合前层 MLP Post，再执行 Attention、同层融合与 MLP。最后一层执行完整 MLP Post，HCHead 接收物化后的 `[N,4,6144]`。

生产修改仅 `vllm/models/hy_v4/nvidia/model.py`：+51/-25行。原路由判断提取为 `_can_fuse_ihc`，同层/跨层共同调用 `_ihc_post_pre`；没有第二套 Selector。HY4 专属 forward 的 residual 槽仅在内部携带两 Tensor 元组，没有公共 PendingState 类、模块或 API。下一层不适格时，先补做 Post，再做原始 Pre。Post 无层参数，前层 gates 保留其归属；Pre 权重来自消费者层。无原地输入修改、CPU/GPU 同步或新增 Kernel。

Kernel `triton_ihc_post_pre.py` 原样复用：函数输入是上一子块 x/residual/post_gate + 下一子块 W/scale/base/epsilon/magnitude，不绑定子块类型或层号。BF16 Post 舍入、FP32归约、禁用FMA、Grid/warps全部保留。原独立 Golden、Baseline、官方Pre/Post均未改。

新跨层开关通过已有 HF overrides：

```python
hf_overrides={
    "enable_ihc_post_pre_fusion": True,
    "enable_ihc_cross_layer_fusion": True,
}
# 必须 enforce_eager=True；仅同层时省略 cross 开关；完全关闭时省略两个开关。
```

原 H100/BF16/D6144/C4/contiguous/FP32参数/512≤N≤8192、严格纯Prefill metadata 条件不变。混合、Decode、未知、padding、ubatch、编译/自动Graph、其他Shape/dtype继续回退。CPU配置开关只在初始化读取。

PP：HYV4Model 初始化仅对本地 `[start_layer,end_layer-1)` 打开延迟 Post，Stage 尾层永远关闭；下一Stage首层输入不携带 pending，走原始 Attention Pre。发送仍只有物化 residual 的 flatten；HCHead之前同样已flush。真实验证为TP1/PP1，尚未实际跑分布式PP；不跨PP Stage融合。

## 精度与 Trace

测试文件 `tests/models/test_hyv4_ihc_fusion.py`：+128/-3行。扩展同一套边界测试覆盖 Attention Pre 消费者；新增不同权重的三层状态链路与 pending 消费时下一层关闭/混合/Graph回退测试。没有替换实际融合输出或更改冻结容差。

- 真实三层权重 `/data/chenhao/Hy4-preview-FP8-3-layers`，TP1、PP1、D6144/C4、BF16激活、ModelOpt MXFP8主体；无重新下载或改 Loader。源码与已安装预编译依赖混合环境沿用上一轮 `sitecustomize.py`，版本 Torch2.13.0+cu129、Triton3.7.1、CUDA12.9、H10080GB。
- L1：真实第0层MLP HC权重产生Post gates，真实第1层Attention Pre权重，N128/256/512/1024/4096/8192；对官方与独立Golden的冻结 check_outputs 全部通过，Residual逐位一致，误差及cosine逐项见 boundary.json。该实验激活为合成输入，不冒充模型E2E。
- L2：实际N512/1024模型Prefill，Original的 Pre/Post 各6次；Intra Only各3次；Intra+Cross各1次。额外融合次序严格为 `(layer0,MLP Pre),(layer1,Attention Pre),(layer1,MLP Pre),(layer2,Attention Pre),(layer2,MLP Pre)`。首层Pre和末层Post未遗漏；N128/256的Cross开关运行仍各6次Pre/Post、零融合。Trace记录在 model_correctness.json / fallback_trace.json。
- 实际模型每个融合调用均用完全相同输入对官方重算，通过原check_outputs；未通过改变下游输入掩盖误差。N512/1024每个Prefill后生成2 token，Original、Intra、Cross结果相同。
- 模型逐层比较时，仅在测试hook中用官方Post物化pending，保持与原始层输出的数学位置一致；计时时移除全部这些hook、clone和精度计算。

| N | 原始A/A逐层 relative L2 | Intra/Original逐层 relative L2 | Cross/Original逐层 relative L2 |
|---:|---|---|---|
|512|0.006230/0.006905/0.008158|0.006191/0.006482/0.009043|0.006168/0.007439/0.009374|
|1024|0.000895/0.003497/0.007604|0.001313/0.004275/0.007861|0.001274/0.003929/0.007494|

A/A在相同权重、输入、seed及预热条件下仍非零：N512第0层原Pre/输入norm exact，最早差异在 Attention output（L2=0.003883）；N1024直到第0层post-attention norm仍exact，最早差异在MLP output（L2=0.000699）。Cross logits L2分别为0.007814/0.007661、0.005572/0.009011；A/A logits也非零。上述差异不能归为融合错误，也不能据此宣布A/B通过；未继续修改Attention/MLP或公共执行环境。

### 保留的失败与定位

初版未固定权重初始化seed时，新增完整合成链路逐元素比较在N4096/8192失败；固定seed=7后，最终仍有N8192失败。失败发生在 Intra Only 的比较，尚未涉及新增Cross的断言。该完整链路逐元素检查采用 `rtol=2*BF16 eps, atol=2e-5`，不包含冻结单边界工具的逐项抵消预算，不能直接将它解释为某个Kernel的错误。

保留失败，没有提高容差、xfail或替换输出。`diagnose_chain.py` 从已提交基线提取原方法，以相同权重和输入重跑：新 Intra 输出与已提交 Intra **逐位相同**；两者对Original均有1个逐元素超限点（共201326592元素）。两者 relative L2=5.1201e-6，Cross=5.1242e-6，cosine约0.999999999987。该证据确认不是本轮改变了同层数值结果，但完整链路/模型精度判据仍需关闭。原冻结单边界判据持续通过。

最终Pytest：**161 passed / 1 failed**（14个上游DeprecationWarning），见 pytest_final.txt；原135项回归通过，新增状态与边界验证除上述链路检查外通过。Ruff check/format与git diff --check通过。自动审批曾拒绝一种测试隔离提案（将官方值传给下游），该提案未执行；最终测试和诊断都保留实际融合输出。

## 性能（精度问题未关闭，作为探索数据保留）

不调Kernel。目标跨层边界的完整 Original Post+Pre、Single和实际路由路径：CUDA Events+热缓存CUDA Graph，30次warmup、25ms graph warmup，3轮×100ms，每graph32次调用，中位数的中位数。128/256 Routed回退；不是eager模型耗时。

| N | Original μs | Fused μs | Routed μs | Original/Fused |
|---:|---:|---:|---:|---:|
| 128 | 21.719 | 19.772 | 21.704 | 1.098× |
| 256 | 40.245 | 24.924 | 40.225 | 1.615× |
| 512 | 80.745 | 69.408 | 69.399 | 1.163× |
| 1024 | 160.966 | 119.204 | 119.223 | 1.350× |
| 4096 | 650.818 | 436.878 | 436.465 | 1.490× |
| 8192 | 1300.127 | 848.834 | 848.812 | 1.532× |

真实切片模型三路：同一模型/权重/输入，eager、prefix cache关闭、max batch tokens8192、每请求1 token。每Shape每模式5次warmup，9轮轮换顺序，CUDA Event hook，无Profiler。表为整个实际模型Forward（含embedding/HCHead/norm）中位值：

| N | Original ms | Intra Only ms | Intra+Cross ms | Cross/Original 加速 | Cross/Intra 加速 | 配对 Cross 胜出 |
|---:|---:|---:|---:|---:|---:|---:|
| 128 | 10.377 | 10.276 | 10.333 | 1.004× | 0.994× | 6/9 |
| 256 | 10.332 | 10.367 | 10.313 | 1.002× | 1.005× | 5/9 |
| 512 | 10.355 | 9.984 | 9.877 | 1.048× | 1.011× | 9/9 |
| 1024 | 11.278 | 11.205 | 11.055 | 1.020× | 1.014× | 6/9 |
| 4096 | 38.949 | 38.181 | 37.824 | 1.030× | 1.009× | 8/9 |
| 8192 | 78.360 | 76.959 | 76.122 | 1.029× | 1.011× | 8/9 |

以下另报每次请求三个DecoderLayer event时长之和的中位数；不要将单层的计时边界当作跨层语义一致的输出。配对范围取同轮 Intra/Cross 模型Forward比值，非置信区间：

| N | 三层 Decoder Original / Intra / Cross ms | Intra/Cross 配对比值范围 |
|---:|---|---|
| 128 | 9.788 / 9.710 / 9.751 | 0.9311–1.1152× |
| 256 | 9.743 / 9.783 / 9.728 | 0.7708–1.0391× |
| 512 | 9.964 / 9.588 / 9.483 | 1.0062–1.0766× |
| 1024 | 10.703 / 10.617 / 10.474 | 0.9304–1.0286× |
| 4096 | 37.201 / 36.441 / 36.064 | 0.9981–1.0210× |
| 8192 | 75.066 / 73.653 / 72.818 | 0.9899–1.0303× |

原始九轮数据、每层event、模型Forward与请求wall均在 model_performance.json；派生摘要 comparison.csv。128/256均不融合，比值漂移只代表噪声。1024额外收益很小且配对区间跨1；4096/8192分别8/9配对胜出，仍有噪声，不承诺所有运行都受益。没有将算子Graph加速换算为eager模型收益，也没有测/外推全量模型TTFT、吞吐或H200。

## 复现、审计与下一步

```bash
export PYTHONPATH="$PWD/lab/ihc_fusion/results/runtime_integration:$PWD"
export PYTHONDONTWRITEBYTECODE=1
export TRITON_CACHE_DIR="$PWD/lab/ihc_fusion/results/.cache/triton"
export VLLM_CACHE_ROOT="$PWD/lab/ihc_fusion/results/.cache/vllm"
CUDA_VISIBLE_DEVICES=2 lab/ihc_fusion/results/.venv/bin/python -m pytest tests/models/test_hyv4_ihc_fusion.py lab/ihc_fusion/tests -q -p no:cacheprovider
# 记录脚本会写本目录同名结果，复现前应改为新的输出位置。
CUDA_VISIBLE_DEVICES=2 lab/ihc_fusion/results/.venv/bin/python lab/ihc_fusion/results/cross_layer_integration/validate_boundary.py
CUDA_VISIBLE_DEVICES=3 lab/ihc_fusion/results/.venv/bin/python lab/ihc_fusion/results/cross_layer_integration/validate_model.py
CUDA_VISIBLE_DEVICES=2 lab/ihc_fusion/results/.venv/bin/python lab/ihc_fusion/results/cross_layer_integration/diagnose_chain.py
```

生产增量净26行；测试增量净125行。仅上述两个已有源码/测试文件与本任务结果目录发生变化。160个预存Lab/Kernel文件哈希不变，原有bench_decode_two_stage.py diff原样保留。无公共模块、其他架构/模型、公共API修改，无暂存/Commit/Push/PR。

待完成：完整链路误差验收与可重复的模型A/A、匹配源码构建的模型质量验证、真实PP运行；自动Graph/compile与H200 E2E本轮未扩展。当前Cross默认关闭，适合代码审查和进一步受控验证，未达到可默认启用的全部验收条件。
