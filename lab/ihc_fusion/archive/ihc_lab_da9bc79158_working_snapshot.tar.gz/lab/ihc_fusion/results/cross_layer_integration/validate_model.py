"""Controlled three-mode validation on the existing TP1 three-layer slice."""
import json
import os
import statistics
import time
from pathlib import Path

os.environ['VLLM_ENABLE_V1_MULTIPROCESSING'] = '0'
os.environ['VLLM_USE_BREAKABLE_CUDAGRAPH'] = '0'
import torch
from vllm import LLM, SamplingParams
from vllm.models.hy_v4.nvidia import model as hy4
from vllm.models.hy_v4.nvidia.triton_ihc import triton_ihc_post
from lab.ihc_fusion.baselines.official import official_post_pre
from lab.ihc_fusion.tests.cases import check_outputs, metrics

HERE = Path(__file__).parent
MODES = ('original', 'intra', 'cross')
llm = LLM(model='/data/chenhao/Hy4-preview-FP8-3-layers', tensor_parallel_size=1,
          enforce_eager=True, max_model_len=8448, max_num_batched_tokens=8192,
          gpu_memory_utilization=.65, enable_prefix_caching=False, max_num_seqs=4,
          trust_remote_code=True, distributed_executor_backend='uni',
          hf_overrides={'enable_ihc_post_pre_fusion': True,
                        'enable_ihc_cross_layer_fusion': True})
model = llm.apply_model(lambda m: m)[0]
layers = list(model.model.layers)
assert len(layers) == 3
assert all(l._ihc_fusion_enabled for l in layers)
assert [l._ihc_defer_post for l in layers] == [True, True, False]


def mode(name):
    for i, layer in enumerate(layers):
        layer._ihc_fusion_enabled = name != 'original'
        layer._ihc_defer_post = name == 'cross' and i < len(layers) - 1


def generate(n, tokens=1):
    torch.manual_seed(7)
    return llm.generate([{'prompt_token_ids': [100 + i % 197 for i in range(n)]}],
                        SamplingParams(temperature=0, max_tokens=tokens, seed=7),
                        use_tqdm=False)[0]


# Correctness hooks are removed before timing.
snapshot, trace, boundary_errors, logits = {}, [], [], []
handles = []
real_kernel = hy4.triton_ihc_post_pre
weight_names = {}
for i, layer in enumerate(layers):
    for sub, hc in [('attention', layer.hc_attn_layer), ('mlp', layer.hc_mlp_layer)]:
        weight_names[hc.hc_pre.hc_fn.weight.data_ptr()] = (i, sub)


def counted_kernel(*args):
    result = real_kernel(*args)
    label = weight_names[args[3].data_ptr()]
    trace.append(('fused', *label, args[0].shape[0]))
    boundary_errors.append(dict(layer=label[0], pre=label[1], n=args[0].shape[0],
                                errors=check_outputs(result, official_post_pre(*args))))
    return result


hy4.triton_ihc_post_pre = counted_kernel
active_n = 0


def stage_hook(name):
    def hook(module, args, kwargs, result):
        value = result[0] if isinstance(result, tuple) else result
        if not isinstance(value, torch.Tensor) or value.shape[0] != active_n:
            return
        if name.startswith('layer') and result[1] is not None:
            # Materialize only for comparison; no production state is changed.
            residual, gates = result[1]
            value = triton_ihc_post(value, residual, gates)
        snapshot[name] = value.detach().clone()
        if isinstance(result, tuple) and len(result) == 2 and name.startswith('pre'):
            snapshot[name + '.gates'] = result[1].detach().clone()
    return hook


def count_hook(kind, i, sub):
    def hook(module, args, result):
        if args[0].shape[0] == active_n:
            trace.append((kind, i, sub, active_n))
    return hook


for i, layer in enumerate(layers):
    for name, module in [('pre', layer.hc_attn_layer.hc_pre),
                         ('norm_in', layer.input_layernorm), ('attention', layer.self_attn),
                         ('norm_mlp', layer.post_attention_layernorm), ('mlp', layer.mlp),
                         ('layer', layer)]:
        handles.append(module.register_forward_hook(stage_hook(f'{name}.{i}'), with_kwargs=True))
    for sub, hc in [('attention', layer.hc_attn_layer), ('mlp', layer.hc_mlp_layer)]:
        handles.append(hc.hc_pre.register_forward_hook(count_hook('pre', i, sub)))
        handles.append(hc.hc_post.register_forward_hook(count_hook('post', i, sub)))
original_logits = model.compute_logits


def compute_logits(hidden):
    result = original_logits(hidden)
    logits.append(result.detach().clone())
    return result


model.compute_logits = compute_logits
correctness = {}
for n in (512, 1024):
    active_n = 0
    mode('original')
    for _ in range(8):
        generate(n)
    runs = {}
    for name, selected in [('a', 'original'), ('aa', 'original'), ('intra', 'intra'), ('cross', 'cross')]:
        mode(selected)
        active_n = n
        snapshot, trace, boundary_errors, logits = {}, [], [], []
        output = generate(n, 2)
        expected_fused = 0 if selected == 'original' else 3 if selected == 'intra' else 5
        assert sum(t[0] == 'fused' for t in trace) == expected_fused
        assert sum(t[0] == 'pre' for t in trace) == 6 - expected_fused
        assert sum(t[0] == 'post' for t in trace) == 6 - expected_fused
        if selected == 'cross':
            assert [(t[1], t[2]) for t in trace if t[0] == 'fused'] == [(0,'mlp'),(1,'attention'),(1,'mlp'),(2,'attention'),(2,'mlp')]
        runs[name] = dict(snapshot=snapshot, logits=logits,
                          tokens=output.outputs[0].token_ids, trace=trace,
                          boundary_errors=boundary_errors)
    row = {}
    for name in ('aa', 'intra', 'cross'):
        a, b = runs['a'], runs[name]
        row[name] = dict(tokens=b['tokens'], reference_tokens=a['tokens'], trace=b['trace'],
                         boundary_errors=b['boundary_errors'],
                         stages={k: metrics(b['snapshot'][k], a['snapshot'][k])
                                 for k in a['snapshot'] if k in b['snapshot']},
                         logits=[metrics(x,y) for x,y in zip(b['logits'], a['logits'])],
                         layer_cosine={str(i): torch.nn.functional.cosine_similarity(
                             b['snapshot'][f'layer.{i}'].double().flatten(),
                             a['snapshot'][f'layer.{i}'].double().flatten(),dim=0).item()
                             for i in range(3)})
        assert b['tokens'] == a['tokens']
    correctness[n] = row
    (HERE/'model_correctness.json').write_text(json.dumps(correctness, indent=2))
    print('CORRECTNESS_RECORDED', n, flush=True)
    del runs

# Verify unsupported N materializes all boundaries even when cross is enabled.
route_trace = {}
for n in (128, 256):
    active_n = n
    mode('cross')
    trace, boundary_errors, snapshot, logits = [], [], {}, []
    generate(n)
    assert sum(t[0] == 'fused' for t in trace) == 0
    assert sum(t[0] == 'pre' for t in trace) == 6
    assert sum(t[0] == 'post' for t in trace) == 6
    route_trace[n] = trace
(HERE/'fallback_trace.json').write_text(json.dumps(route_trace, indent=2))
for handle in handles:
    handle.remove()
model.compute_logits = original_logits
hy4.triton_ihc_post_pre = real_kernel
snapshot, logits = {}, []
print('CORRECTNESS_COMPLETE', flush=True)

# Same eager timing method as the previous stage: event hooks, no profiler.
starts, pending, handles = {}, [], []


def before(module, args, kwargs):
    event = torch.cuda.Event(enable_timing=True)
    event.record()
    starts[id(module)] = event


def after(module, args, kwargs, result):
    event = torch.cuda.Event(enable_timing=True)
    event.record()
    pending.append((id(module), starts[id(module)], event))


for module in [model, *layers]:
    handles += [module.register_forward_pre_hook(before, with_kwargs=True),
                module.register_forward_hook(after, with_kwargs=True)]
rows = []
for n in (128, 256, 512, 1024, 4096, 8192):
    for name in MODES:
        mode(name)
        for _ in range(5):
            generate(n)
    row = dict(n=n, **{name: [] for name in MODES})
    for repeat in range(9):
        order = MODES[repeat % 3:] + MODES[:repeat % 3]
        if repeat % 2:
            order = order[::-1]
        for name in order:
            mode(name)
            pending.clear()
            torch.cuda.synchronize()
            start = time.perf_counter()
            generate(n)
            torch.cuda.synchronize()
            times = {key: a.elapsed_time(b)*1000 for key,a,b in pending}
            row[name].append(dict(forward_us=times[id(model)],
                                  layers_us=[times[id(layer)] for layer in layers],
                                  wall_ms=(time.perf_counter()-start)*1000))
    rows.append(row)
    (HERE/'model_performance.json').write_text(json.dumps(dict(
        gpu=torch.cuda.get_device_name(), tp=1, layers=3, graph=False,
        torch=torch.__version__, checkpoint='/data/chenhao/Hy4-preview-FP8-3-layers',
        warmups=5, rounds=9, cache='warm model, prefix caching disabled',
        timer='CUDA events in actual eager model/layer hooks, no profiler', rows=rows), indent=2))
    print('PERFORMANCE', n, {k: statistics.median(x['forward_us'] for x in row[k]) for k in MODES}, flush=True)
for handle in handles:
    handle.remove()
print('COMPLETE', flush=True)
