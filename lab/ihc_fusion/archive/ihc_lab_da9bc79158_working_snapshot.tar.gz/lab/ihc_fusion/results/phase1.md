# Phase 1: source audit

Branch: exp/hy4-ihc-lab. Source commit: 5df63a7203cdb9328d824a27b682e77c7b9928be.
Initial status: only pre-existing untracked ihc_idea.md. No tracked changes.

Sources: ihc_idea.md; vllm/models/hy_v4/nvidia/{triton_ihc,hc,model}.py;
vllm/model_executor/layers/hpc/hpc_ihc.py. Only lab/ihc_fusion is writable.

## Contract

Previous sub-block owns x [N,D], residual [N,C,D], previous_post [N,C].
Next sub-block owns weight [2C,C*D], scale [2], base [2C], magnitude,
hc_eps and norm_eps. Parameters and gates are FP32. Activations share dtype.
Weight is row-major: first C rows pre, final C rows post, channel-major input.

1. updated = cast_dtype(residual.float() + previous_post[...,None]*x[:,None,:].float()).
   Multiplication and addition are separate FP32 operations (FP fusion disabled).
   This cast is observable and MUST precede the next Pre, even in a fused kernel.
2. z = flatten(updated).float(); K=C*D.
3. inv_rms = rsqrt(sum(z*z)/K + norm_eps).
4. mix = (weight @ z) * inv_rms. Official code reduces 1024-element
   contiguous chunks, then sequentially accumulates their FP32 partials.
5. pre = sigmoid(mix[:C]*scale[0] + base[:C]) + hc_eps.
6. next_post = magnitude*sigmoid(mix[C:]*scale[1] + base[C:]) + hc_eps.
7. next_x = cast_dtype(sum_c(pre[c]*updated[c].float())), with FP32
   channel accumulation in increasing channel order.

Returns (next_x [N,D], updated [N,C,D], next_post [N,C] FP32).
updated is a required next residual output, not removable temporary storage.
There is no affine RMSNorm weight and no decoder input_layernorm here.
The previous gates are not recomputed using the next sub-block parameters.

## Corrections to the idea note

Official Triton Pre launches two kernels, so the Post+Pre baseline launches three.
Post output is [N,C,D], not [N,D]. Magnitude applies only to next Post sigmoid;
epsilon is added afterwards. Official dispatch supports BF16/FP16; direct kernel
functions can additionally be tested with FP32, labelled as a Lab extension.

## Minimal implementation

One token per CTA, keep rounded Post vector on chip, reproduce 1024-element
projection partial reductions, then compute gates and sequential channel reduce.
One launch; no global intermediate partial array; materialize required residual.
No cross-CTA synchronization or runtime integration. Inspect register pressure,
spills, and decode parallelism after correctness. Tune only small launch knobs.

Files: reference/torch_post_pre.py; baselines/official.py;
kernels/fused_post_pre.py; tests/test_post_pre.py;
benchmarks/bench_post_pre.py; results reports and machine-readable artifacts.
Environment/cache artifacts will also stay under results (ignored locally).

No algorithm/hardware blocker: H100 80GB HBM3 is available; device 3 was idle.
No repo-root .venv: create an isolated results/.venv with uv, reusing installed
packages read-only. Do not install git hooks or editable vLLM: both would write
outside the whitelist. Baseline must load the exact in-tree source and attest
its commit/hash, bypassing model dispatch without substituting kernel bodies.

Phase exit: source review complete; no numerical tests or timings yet.
No out-of-scope changes required. No branch switch, commit, or git config edits.
