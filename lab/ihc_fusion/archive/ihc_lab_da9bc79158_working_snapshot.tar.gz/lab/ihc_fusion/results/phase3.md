# Phase 3: first single-launch implementation

Changed: kernels/fused_post_pre.py; results/phase3_correctness.json,
phase3_pytest.txt and this report. Frozen Golden, baseline and tolerances unchanged.

43 GPU tests passed (32.90s including first JIT compilation). One token per CTA;
rounded Post residual stays in registers through projection and output reduction.
No calls to existing kernels, no partial global scratch and no global reload of
updated residual. Original source kernels remain untouched. 1024-element partial
reductions and sequential split/channel accumulation are explicit; FP fusion off.

Worst max_abs: {'fused_vs_golden': {'output': 0.03125, 'residual': 0.0, 'post_gates': 2.4437904357910156e-06}, 'fused_vs_official': {'output': 0.03125, 'residual': 0.0, 'post_gates': 1.4901161193847656e-06}}. Full per-case metrics are in JSON.
No timing or tuning yet. Phase 4 will add large prefill, channel/mask boundaries,
preallocated output checks, and observed GPU launch counts.

Scope audit: git diff --name-only empty; all added files inside Lab, apart from
pre-existing ihc_idea.md. No out-of-scope changes required. No open correctness issue.
