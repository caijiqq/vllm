# HY4 iHC Fused PostPre — H100 实验报告

完成五阶段 Lab 开发。最终 kernel 为真实单次 launch；独立 Golden 与官方 Baseline 已冻结；
53 项正确性测试通过，36 组正式性能测量完成。Prefill 有收益，小 Token Decode 仍退化。
未接入 Runtime，未修改 DecoderLayer、官方 Pre/Post、公共 API 或分支。

## 环境与测量边界

- 分支：`exp/hy4-ihc-lab`；vLLM commit：`5df63a7203cdb9328d824a27b682e77c7b9928be`。
- GPU：NVIDIA H100 80GB HBM3，物理 GPU 3，SM90，80 GB。
- PyTorch：2.13.0+cu129；Triton：3.7.1；CUDA：12.9；FlashInfer：0.7.0.post1。
- Driver 575.57.08。GPU UUID、时钟、温度、占用及测量前后快照详见正式 JSON。未调整时钟或其他 GPU 任务。
- CUPTI Python 接口未安装；明确使用 FlashInfer CUDA Graph + CUDA Events。
- 冷 L2 采用旋转缓冲，图内调用数至少覆盖一个完整旋转周期并至少 32 次调用。
  旋转缓冲总容量目标为 5×L2；本设备 L2=50 MiB。大输入按 FlashInfer 阈值省略旋转。
- 各 arm 在计时前编译、校验和预热 30 次；图另预热约 25 ms。
  每 round 目标计时 100 ms，共 3 rounds，交替先后顺序；报告各 round 中位数的中位数。
  原始 replay 数、p10/p90、每图调用数、rotation 数均保留。
- 两条路径采用同样输入、FP32 权重/参数及独立预分配输出。排除分配、编译、随机数和拷贝。
- Baseline 是三个原始官方 kernel，固定原始配置（Post 4、Pre stage1 8、stage2 4 warps）。
  按要求未调优或修改官方配置。预分配路径与官方函数包装已逐位对齐。
- Optimized 非空输入仅一个 kernel；四通道 N≤128 使用 16 warps，其余 4 warps。
- FP32 是对底层函数的 Lab 直接调用扩展；官方 runtime 支持判断仅允许 BF16/FP16。

复现命令、输入输出契约和来源加载方式见 [README](../README.md)。
正式记录：[JSON](h100_benchmark.json)、[CSV](h100_benchmark.csv)、[stdout](h100_benchmark.txt)。

## 正确性

命令及配置见 README；最终输出为 `53 passed in 10.58s`。
覆盖 FP32/BF16/FP16，N=0…4096，D=1…8192（含 257、1025、3072、7168），
C=1/3/4，随机/零/微小值/大幅值/相消/饱和 gates，非零 storage offset。
上一 Post gates 与下一 Pre 参数独立生成，使用 magnitude=1.7、非默认 epsilon、正负 scale。
profiler 观测到 Fused 1 个 `_fused_post_pre`，Baseline 3 个官方 kernel。
所有 Residual 与 Golden、Baseline 均逐位一致；输出与 gates 不要求逐位一致。

| 对比 | dtype | output max_abs | output relative L2 | gates max_abs | gates relative L2 |
|---|---|---:|---:|---:|---:|
| Golden | float32 | 0.0001220703 | 2.399033e-07 | 3.278255e-06 | 5.205325e-07 |
| Golden | bfloat16 | 0.0625 | 2.841455e-05 | 2.622604e-06 | 4.099935e-07 |
| Golden | float16 | 0.0078125 | 1.5206e-05 | 1.728535e-06 | 3.418769e-07 |
| Official | float32 | 0.0001220703 | 4.596179e-07 | 5.960464e-07 | 1.16306e-07 |
| Official | bfloat16 | 0.03125 | 3.015327e-05 | 1.013279e-06 | 1.707165e-07 |
| Official | float16 | 0.0078125 | 6.367812e-06 | 1.430511e-06 | 2.270517e-07 |

以上各列为所有记录用例的独立最大值，不一定来自同一输入。较大的绝对输出差包括
幅值 ×100 的边界用例，应结合 relative L2 阅读。基于 dtype 的固定误差规则及 FP32
相消预算于 Fused 开发前确定并冻结；之后未放宽。FP32 output/gates relative L2≤2e-6；
低精度 output relative L2≤dtype epsilon；所有 dtype 的 gates 另有 FP32 逐元素约束。
[逐用例误差](final_correctness.json)、[误差摘要](final_error_summary.json)、
[测试日志](final_pytest.txt)、[实际 launch](final_launches.json)。

## 正式性能结果

输入为 x[N,D]、R[N,4,D]、previous_post[N,4]、weight[8,4D]；scale/base FP32。
延迟单位 μs；Speedup=Baseline/Fused，低于 1 表示退化。

| dtype | N | D | warps | Baseline μs | Fused μs | Speedup |
|---|---:|---:|---:|---:|---:|---:|
| float32 | 1 | 4096 | 16 | 9.260 | 13.644 | 0.679× |
| float32 | 8 | 4096 | 16 | 9.835 | 13.755 | 0.715× |
| float32 | 32 | 4096 | 16 | 11.559 | 14.679 | 0.787× |
| float32 | 128 | 4096 | 16 | 23.059 | 17.843 | 1.292× |
| float32 | 1024 | 4096 | 4 | 149.325 | 130.125 | 1.148× |
| float32 | 4096 | 4096 | 4 | 593.205 | 491.659 | 1.207× |
| float32 | 1 | 7168 | 16 | 9.256 | 27.025 | 0.342× |
| float32 | 8 | 7168 | 16 | 9.939 | 26.950 | 0.369× |
| float32 | 32 | 7168 | 16 | 13.930 | 28.265 | 0.493× |
| float32 | 128 | 7168 | 16 | 34.814 | 33.901 | 1.027× |
| float32 | 1024 | 7168 | 4 | 261.384 | 254.416 | 1.027× |
| float32 | 4096 | 7168 | 4 | 1040.705 | 1001.896 | 1.039× |
| bfloat16 | 1 | 4096 | 16 | 8.919 | 13.944 | 0.640× |
| bfloat16 | 8 | 4096 | 16 | 9.340 | 13.828 | 0.675× |
| bfloat16 | 32 | 4096 | 16 | 10.628 | 14.295 | 0.743× |
| bfloat16 | 128 | 4096 | 16 | 19.357 | 15.727 | 1.231× |
| bfloat16 | 1024 | 4096 | 4 | 106.217 | 78.458 | 1.354× |
| bfloat16 | 4096 | 4096 | 4 | 433.473 | 288.216 | 1.504× |
| bfloat16 | 1 | 7168 | 16 | 9.142 | 31.423 | 0.291× |
| bfloat16 | 8 | 7168 | 16 | 9.625 | 29.450 | 0.327× |
| bfloat16 | 32 | 7168 | 16 | 12.700 | 29.250 | 0.434× |
| bfloat16 | 128 | 7168 | 16 | 28.857 | 32.335 | 0.892× |
| bfloat16 | 1024 | 7168 | 4 | 189.511 | 141.446 | 1.340× |
| bfloat16 | 4096 | 7168 | 4 | 762.569 | 523.176 | 1.458× |
| float16 | 1 | 4096 | 16 | 8.912 | 13.160 | 0.677× |
| float16 | 8 | 4096 | 16 | 9.326 | 13.356 | 0.698× |
| float16 | 32 | 4096 | 16 | 10.647 | 13.826 | 0.770× |
| float16 | 128 | 4096 | 16 | 19.357 | 15.224 | 1.271× |
| float16 | 1024 | 4096 | 4 | 106.605 | 76.875 | 1.387× |
| float16 | 4096 | 4096 | 4 | 433.870 | 282.845 | 1.534× |
| float16 | 1 | 7168 | 16 | 9.132 | 30.930 | 0.295× |
| float16 | 8 | 7168 | 16 | 9.619 | 28.969 | 0.332× |
| float16 | 32 | 7168 | 16 | 12.691 | 28.513 | 0.445× |
| float16 | 128 | 7168 | 16 | 28.843 | 31.744 | 0.909× |
| float16 | 1024 | 7168 | 4 | 189.524 | 136.999 | 1.383× |
| float16 | 4096 | 7168 | 4 | 762.491 | 508.081 | 1.501× |

JSON/CSV 另记录边界最少字节数换算的 GB/s。该值按输入/权重读一次、输出写一次计算，
不是实测 HBM 带宽：实际实现会跨 token 重读权重，最终版本也重算 Post 并再次读原始输入。
本算子混合 GEMV、归约、sigmoid 和数据搬运，不用单一 TFLOPS 衡量收益。

## 性能退化与局部优化

1. 初版保留整个 rounded Residual，复现 1024 分块并逐 split 相加，输出使用 gather。
   D=4096 记录到 64 KiB shared、最高 255 registers/thread，部分配置出现 spill。
   BF16 N=1 最好约 25 μs；D=7168 N=1024 最好约 592 μs，明显退化。
   [原始测量](h100_tuning.json)、[源码快照](initial_fused_post_pre.py.txt)。
2. 四通道分别驻留寄存器降低了 shared，但投影中的多次标量归约仍然较慢，
   大 hidden 部分配置仍 spill。[测量](h100_tuning_optimized.json)、
   [快照](channel_fused_post_pre.py.txt)。此版也通过完整 53 项测试。
3. 最终固定 1024 lanes，同时计算 8 个投影；循环跨 chunk 累加后再归约。
   不保留全部 Residual，最终从原始输入重算 rounded Post，避免回读新 Residual。
   该归约树与官方不同，保留 FP32 累加、Post cast、禁用 FMA 和输出通道顺序；
   同样通过全部冻结精度测试。最终正式测量所有编译变体均无 spill。
   [tile 粗调](h100_tuning_tiled.json)、[Token 粗调](h100_tuning_tokens.json)。
4. N=1024/4096 时，BF16/FP16 获得约 1.34–1.53×；小 N 仍显著退化。
   对 N=1，融合只有一个 CTA，而官方 Pre stage1 有 16/28 个独立 split CTAs。
   最终实现还在一个 CTA 内循环加载所有投影权重。低并行度与串行加载很可能解释
   Decode 的主要退化；Token/warp 消融支持该解释，但未用硬件性能计数器分离各项成本。
   不把这个推断写成已测定的 stall 占比。

当前交付证明 kernel 正确性和部分 Prefill 收益，不能宣称通用加速。
不为 Decode 偷换回官方两个算子，也不修改 Runtime 调度。Decode 性能仍是后续问题。

## 生成代码资源

保存正式测量对应的 12 个 PTX 及资源记录，均为 sm90、enable_fp_fusion=False。
[索引](generated_resources.json)。PTX 中无显式 ld.local/st.local；最终 ptxas 资源亦报告 spill_count=0。

| 激活 | D | warps | registers/thread | shared bytes | spill |
|---|---:|---:|---:|---:|---:|
| *bf16 | 4096 | 4 | 168 | 4096 | 0 |
| *bf16 | 4096 | 16 | 70 | 4096 | 0 |
| *bf16 | 7168 | 4 | 167 | 4096 | 0 |
| *bf16 | 7168 | 16 | 64 | 4096 | 0 |
| *fp16 | 4096 | 4 | 168 | 4096 | 0 |
| *fp16 | 4096 | 16 | 68 | 4096 | 0 |
| *fp16 | 7168 | 4 | 167 | 4096 | 0 |
| *fp16 | 7168 | 16 | 64 | 4096 | 0 |
| *fp32 | 4096 | 4 | 139 | 128 | 0 |
| *fp32 | 4096 | 16 | 70 | 4096 | 0 |
| *fp32 | 7168 | 4 | 172 | 128 | 0 |
| *fp32 | 7168 | 16 | 76 | 4096 | 0 |

## 阶段验收与文件范围

- Phase 1：[只读审查](phase1.md)，先确认公式/舍入/参数归属再实施。
- Phase 2：[Golden/Baseline 验收](phase2.md)，43 项通过后冻结。
- Phase 3：[首个单 kernel](phase3.md)，43 项通过。
- Phase 4：[扩展验证](phase4.md)，53 项通过并观测 launch 数。
- Phase 5：每次局部 kernel 修改先全量正确性，再性能；最终 53 项及 36 组通过。
  完整日志与快照保留，不隐藏失败或退化结果。

最终文件：`kernels/fused_post_pre.py`；`reference/torch_post_pre.py`；
`baselines/official.py`；`tests/{cases,test_post_pre}.py`；
`benchmarks/bench_post_pre.py`；各包 `__init__.py`；`README.md`；
`results/` 中阶段记录、JSON/CSV、stdout、PTX、源码快照、冻结与最终哈希。
环境/缓存在 `results/.venv` 和 `results/.cache`，由该目录 `.gitignore` 忽略。

静态检查使用仓库固定 Ruff 0.14.0；check 和 format --check 均通过。
未安装 git hooks（会写出白名单），未安装 editable vLLM，未运行 Runtime/model eval。
本任务无模型或调度变更；验证仅针对算子行为与性能。

最终 scope 审计另见 [scope_audit.json](scope_audit.json)：
分支不变，`git diff --name-only` 为空；新增文件均在 `lab/ihc_fusion/`，
唯一例外是任务开始前已有的未跟踪 `ihc_idea.md`，内容哈希在结束时记录。
没有提交、合并、Git 配置修改或需要越界修改的事项。
