# HY4 iHC H100 性能审计 — 2026-10-21

**结论：约1.5×算子加速与约3%三层Forward加速主要由计算占比解释，没有发现Runtime漏融合。对于“Kernel是否已接近合理上限”，选择 C：证据不足。** 已确认寄存器限制并发、重复Post和旧Residual读取，但没有硬件Counter证明哪个因素占主导，也不能承诺再优化可获得5%–10%模型收益。

当前正确性限制不变：**此前161 passed / 1 failed；N8192合成三层链路超限与严格模型A/A、A/B验收仍未闭合**。本轮性能审计不是生产精度验收；没有修复、放宽阈值或重新宣布通过。

## 关键实测

| N | Original ms | Intra ms | Intra+Cross ms | Original/Cross | Intra/Cross |
|---|---|---|---|---|---|
| 512 | 10.683 | 10.946 | 10.838 | 0.9857× | 1.0100× |
| 1024 | 12.086 | 12.001 | 11.756 | 1.0280× | 1.0208× |
| 4096 | 38.728 | 38.066 | 37.428 | 1.0347× | 1.0170× |
| 8192 | 78.185 | 76.972 | 76.234 | 1.0256× | 1.0097× |

以上是同一模型、TP1、H100 GPU3、Eager、固定三层真实切片的9轮中位数，Profiler不参与计时。N8192配对speedup中位数1.0302×（各组中位数比1.0256×）；完整分位数和每轮数据见[RUNTIME_BREAKDOWN.md](RUNTIME_BREAKDOWN.md)及raw/model_timing.csv。N512本轮有负收益和明显噪声，应保留该结果，不作稳定加速声明。

- N8192算子Eager热态：Original **1308.496µs**，Fused **854.272µs**，**1.532×**；独立Graph热态1310.624→857.520µs，1.528×。冷L2代理、其他N和P10/P90均已保存。
- 真实Trace：Original18个iHC Kernel，Intra12个，Cross8个，其中Fused分别0/3/5次；首Pre、末Post正确保留。没有新增大张量复制、contiguous或同步活动。
- N8192 Original活动归因：Attention+MLP约84.2%，iHC Pre/Post约10.6%；**本轮五个可融合边界仅约8.8%**，HCHead不在融合范围。以此占比获得1.5×局部收益，自然对应约3%模型收益。

## 七个核心判断

1. **实际HBM流量是否下降：未测得，不能确认下降幅度。** 源码消除了对更新Residual的两遍消费和Partial buffer，但仍写必要Residual，同时重读旧Residual、重算Post。粗粒度激活逻辑字节数两条路径同为1728MiB，不能用“单Kernel”替代DRAM证据。
2. **主要瓶颈：大N不是Launch主导；Memory/L2/FP32指令/occupancy之间尚不能唯一归因。** Fused168寄存器/线程限制到3CTA/SM、18.75%资源occupancy上限，实际occupancy和stall未知。
3. **明显低效：有重复Post和第二次旧Residual加载，另有24次串行chunk及每Token重复读768KiB权重。** 但这些可能换取状态规模和数值语义，不能未测量就认定可无代价消除；无register spill、无额外Runtime物化。
4. **1.52×接近上限吗：不能证明。** N8192唯一必要数据的极乐观HBM下界约301µs，按实测大buffer参考带宽约332–412µs；按源码激活请求全部到HBM则约597–741µs。均未包含真实L2/指令依赖，854µs距离这些模型的差值不是可兑现空间。
5. **为什么约3%：五边界占比小，且三层Trace证明全部覆盖。** 同模式模型内五边界Eager节省约2.531ms；纯模型配对差中位数2.309ms，量级相符但不意味着路由开销严格为零。
6. **5%–10%有可信证据吗：没有。** 1.05×仍需每次Fused约355µs额外节省；1.10×所需额外总节省超过现有五Fused的总时间。五个原始边界全部免费也仅约1.096–1.097×的条件上限。
7. **下一轮最值得验证的单个方向：获取N8192的DRAM/L2和warp issue/stall Counter，判断168寄存器与24次串行投影是否限制延迟隐藏。** 先做此最小取证，再决定是否值得围绕投影活跃状态减少寄存器；本轮不改Tile、不改FMA、不改归约树、不开发Kernel。

## 证据导航

- [SOURCE_AUDIT.md](SOURCE_AUDIT.md)：数学、源码位置、Tensor读写台账、Residual生命周期。
- [MEMORY_MODEL.md](MEMORY_MODEL.md)：访存/FLOPs下界和假设；raw/memory_model.csv覆盖四个N。
- [PROFILE_ANALYSIS.md](PROFILE_ANALYSIS.md)：PTX/SASS、资源、计时、缺失Counter及局限。
- [RUNTIME_BREAKDOWN.md](RUNTIME_BREAKDOWN.md)：真实三层调用、互斥耗时归因、配对原始数据与Amdahl。
- [REPRODUCE.md](REPRODUCE.md)、[EXPERIMENT_LOG.md](EXPERIMENT_LOG.md)：完整命令、环境、失败尝试、逐阶段记录。
- raw/保存初始Git状态/差异/哈希、完整CSV、6份模型trace、算子trace、cubin/PTX/SASS。没有保存权重内容；checkpoint通过环境变量指定。

## 范围与精度

本次只在本实验目录新增脚本、记录、原始数据和隔离缓存。Kernel、Runtime、测试、冻结Lab均不修改；初始用户修改与跨层未提交修改由逐文件SHA256复验，结果见raw/scope_audit_final.json。没有暂存、提交、推送、安装软件、改变GPU时钟/权限或清理任何现存缓存。

仅独立算子检查沿用冻结check_outputs：N512/1024/4096/8192均通过；N8192输出max_abs=0.0078125、rel_L2=6.999e-6，Residual逐位一致，Gates max_abs=2.384e-7。这个检查不覆盖现有模型数值未闭合问题。模型计时不等于完整推理、TTFT或H200验证；Graph数字仅为独立算子测试。

最终范围复验：7905个已有普通文件SHA256全部一致，8个已有目录symlink与HEAD一致，原始Git diff逐字节一致；新增文件均在本运行目录。`git diff --check`通过，无暂存文件。完整新增产物（含Git忽略的CSV/日志/隔离缓存）见raw/artifact_manifest.json。GPU3退出后17MiB、0%利用率。
