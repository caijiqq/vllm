# H100 Kernel profiling 与独立计时

## 方法和缺失指标

E03 使用 PyTorch CPU/CUDA activity profiler，N8192，每条路径预热30次，实际 Original3/Fused1 launch；各路径记录3次。E04/E05 在 profiler 完全退出后计时。同一真实 HC 参数、BF16输入、D6144/C4，9轮交替顺序，每轮20次。Graph 是独立算子 capture，模型 Runtime 仍为 Eager。`flush256MiB` 在每次起始 event 前执行，flush 本身不计入 Event 时间；这只是冷 L2 代理，不能保证每个 cache line 都被驱逐。缓存热态也不表示大于 L2 的全部工作集驻留缓存。

Nsight Compute/Systems 未安装或未在已搜索目录找到，不是已证实的权限拒绝。只读驱动参数 RmProfilingAdminOnly=0。已有 CUPTI 库可支持 activity；通过 `_ExperimentalConfig` 请求 `dram__bytes_read.sum`、`dram__bytes_write.sum` 未报错，但 trace 没有任何对应值。不能将“参数被接受”当作 Counter 成功。DRAM/L2 bytes、命中率、SM throughput、实际 achieved occupancy、warp stalls、load/store efficiency 均未知。具体请求和失败证据见 counter_probe.py、raw/counter_probe.json、raw/counter_probe.trace.json。

## 资源与生成代码

| Kernel | Grid | Threads/CTA | Registers/thread | Shared B | Spill | 资源上限 CTA/SM | 资源 occupancy 上限 |
|---|---|---|---|---|---|---|---|
| _ihc_post_kernel | [N,6] | 128 | 32 | 0 | 0 | 16 | 100.00% |
| _ihc_pre_stage1 | [N,24] | 256 | 31 | 128 | 0 | 8 | 100.00% |
| _ihc_pre_stage2 | [N,6] | 128 | 48 | 0 | 0 | 10 | 62.50% |
| _fused_post_pre | [N] | 128 | 168 | 4096 | 0 | 3 | 18.75% |

这些 occupancy 数字来自 CUDA occupancy API 和 profiler 的寄存器资源估算，不是实测活跃 warp 比例。Fused 的上限为3 CTA/SM（12 warps/64）；shared memory 4KiB 不是限制项，寄存器168/thread 是限制项。N8192 有8192 CTA，平均62.1 CTA/SM的总工作量，约20.7轮3-CTA驻留批次；不存在小N那种全卡仅一两个CTA的问题。不能用18.75%直接乘峰值算力或断言降低寄存器一定提速。

Triton metadata spill=0；PTX 无ld.local/st.local，SASS 无LDL/STL。SASS 无FP32 FFMA；有FMUL/FADD，保留非FMA语义。无真正HMMA/HGMMA/IMMA/DMMA/MMA及PTX mma/wgmma指令。初始资源收集正则误把HFMA2.MMA标量指令修饰符计为MMA，原始resources.json保留，修正后的逐操作码统计在resources_analysis.json；不要引用原始sass_tensor_instructions字段作为Tensor Core计数。后向BRA与PTX loop对应24次串行chunk；源码末尾重复Post在生成代码中仍有第二组load/mul/add/round。

N8192 profiler 单Kernel中位数：Post 305.465µs，Pre1 813.360µs，Pre2 183.164µs；合计1301.989µs；Fused 848.942µs。Pre1占原始三阶段约62.5%。Fused耗时接近原Pre1，但这不是其内部投影阶段独立计时：新Kernel的Post、投影、归约、第二次Post没有独立时间戳，不能拆出百分比。

## 完整路径独立计时

| N | 模式 | 缓存 | Original µs | Fused µs | Speedup |
|---|---|---|---|---|---|
| 512 | eager | hot | 89.280 | 73.792 | 1.210× |
| 512 | eager | flush256MiB | 92.256 | 81.248 | 1.135× |
| 512 | graph | hot | 84.832 | 73.760 | 1.150× |
| 512 | graph | flush256MiB | 88.176 | 80.624 | 1.094× |
| 1024 | eager | hot | 169.312 | 123.616 | 1.370× |
| 1024 | eager | flush256MiB | 174.336 | 126.288 | 1.380× |
| 1024 | graph | hot | 166.176 | 124.192 | 1.338× |
| 1024 | graph | flush256MiB | 171.616 | 126.400 | 1.358× |
| 4096 | eager | hot | 661.120 | 443.760 | 1.490× |
| 4096 | eager | flush256MiB | 666.992 | 449.984 | 1.482× |
| 4096 | graph | hot | 658.496 | 442.784 | 1.487× |
| 4096 | graph | flush256MiB | 663.616 | 448.448 | 1.480× |
| 8192 | eager | hot | 1308.496 | 854.272 | 1.532× |
| 8192 | eager | flush256MiB | 1318.832 | 859.456 | 1.534× |
| 8192 | graph | hot | 1310.624 | 857.520 | 1.528× |
| 8192 | graph | flush256MiB | 1316.064 | 860.352 | 1.530× |

所有每次样本在 raw/kernel_timing.csv；P10/P90、min/max和每轮中位数的分布在 raw/kernel_summary.csv。每个单元180次样本；第一条偏慢样本也保留。批次wall字段包含Python/event创建开销，冷态还包含flush，不能把它解释成纯Kernel耗时。

N8192 Eager/Graph热态分别854.272/857.520µs，差值小于0.4%；热/flush差值约0.3–0.6%。因此大N不是以Python Launch为主的瓶颈。冷态差异小不能证明HBM不重要：输入输出工作集本身远超50MiB L2，而权重只有768KiB，单次Kernel内仍可反复热起来。N512受缓存和提交方式影响更大。

## 可以确认与不能确认

- 已确认：单次3→1 launch；必要Residual store保留；Partial buffer消失；旧Residual第二次加载和Post重复计算；24次chunk循环；寄存器限制并发；无spill。
- 未确认：HBM究竟节省多少，L2是否饱和，long-scoreboard/issue stall占比，寄存器限制是否位于关键路径，854µs内部阶段占比。
- Hypothesis：以L2供给权重、FP32投影/串行依赖及低warp并发构成混合瓶颈；不能将其写成已测定的Memory Bound或Compute Bound。
- 下一项最小实验：在有合适Nsight Compute的H100环境，只对同一N8192 Original三Kernel和Fused采集DRAM/L2吞吐、SM/warp issue、实际occupancy及stall。先`ncu --query-metrics`确认版本支持名称，再选择小集合；不需要先改Kernel。当前审计未安装工具、未改变权限/时钟。
