"""Probe existing Kineto CUPTI metric support; no installation or permission changes."""
import json
import os
from pathlib import Path
import torch
from torch.profiler import profile, ProfilerActivity, _ExperimentalConfig
from vllm.models.hy_v4.nvidia.triton_ihc_post_pre import triton_ihc_post_pre
from lab.ihc_fusion.tests.cases import make_case
p=Path(os.environ['AUDIT_RUN'])
metrics=['dram__bytes_read.sum','dram__bytes_write.sum']
args=make_case(8192,6144,torch.bfloat16)
for _ in range(5):triton_ihc_post_pre(*args)
torch.cuda.synchronize()
result={'requested_metrics':metrics,'purpose':'availability probe, not latency measurement'}
try:
    with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA],
        experimental_config=_ExperimentalConfig(profiler_metrics=metrics,profiler_measure_per_kernel=True)) as prof:
        triton_ihc_post_pre(*args)
        torch.cuda.synchronize()
    prof.export_chrome_trace(str(p/'raw/counter_probe.trace.json'))
    result['trace_written']=True
except Exception as e:
    result['error']=repr(e)
(p/'raw/counter_probe.json').write_text(json.dumps(result,indent=2))
print(result,flush=True)
