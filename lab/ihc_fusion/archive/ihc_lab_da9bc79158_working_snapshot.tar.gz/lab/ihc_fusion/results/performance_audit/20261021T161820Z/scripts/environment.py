import ctypes
import datetime
import importlib.metadata
import json
import os
import subprocess
from pathlib import Path
import torch
import triton
from torch.profiler import _ExperimentalConfig
p=Path(os.environ['AUDIT_RUN'])
props=torch.cuda.get_device_properties(0)
cu=ctypes.CDLL('libcuda.so.1');cu.cuInit(0)
attrs={}
for name,code in [('memory_clock_khz',36),('memory_bus_width_bits',37),('sm_count',16),('l2_bytes',38),('max_threads_per_sm',39),('registers_per_sm',82),('shared_bytes_per_sm',81)]:
    value=ctypes.c_int();status=cu.cuDeviceGetAttribute(ctypes.byref(value),code,0)
    attrs[name]=dict(status=status,value=value.value)
d=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),gpu=props.name,
    properties=str(props),attributes=attrs,torch=torch.__version__,triton=triton.__version__,cuda=torch.version.cuda,installed_vllm=importlib.metadata.version('vllm'),
    profiler_config_doc=_ExperimentalConfig.__init__.__doc__,nsight_compute=None,nsight_systems=None,
    nvidia_smi=subprocess.check_output(['nvidia-smi','-i','3','--query-gpu=name,driver_version,memory.total,clocks.sm,clocks.mem,power.limit','--format=csv'],text=True),
    nvdisasm='/usr/local/lib/python3.12/dist-packages/triton/backends/nvidia/bin/nvdisasm',
    spec_source='https://www.nvidia.com/en-eu/data-center/h100/',peak_bandwidth_TBps=3.35,fp32_peak_TFLOPs=67,
    counters_permission='RmProfilingAdminOnly: 0 (read-only observation)',
    build='checkout Python + existing installed vLLM binary extensions via prior sitecustomize; no package edits')
(p/'raw/environment.json').write_text(json.dumps(d,indent=2))
print(json.dumps(d,indent=2))
