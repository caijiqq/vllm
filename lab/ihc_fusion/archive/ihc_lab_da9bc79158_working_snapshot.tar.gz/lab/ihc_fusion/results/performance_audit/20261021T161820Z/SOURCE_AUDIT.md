# E01: source audit (before measurement)

HEAD ad3e62549 with unchanged uncommitted cross-layer work. Line numbers refer to current checkout.

Original production `triton_ihc.py`: Post lines155–196 writes R'=cast_bf16(g_prev*x+R); Pre1 lines30–75 reads R', produces eight FP32 dot-product partials and one square-sum partial per 1024 hidden elements; Pre2 lines78–151 reduces those partials, calculates RMS and gates, reads R' again for the channel reduction. Wrappers lines199–313 launch [N,6], [N,24], [N,6] for D6144/C4. Post/Pre contiguous() are no-ops for audited contiguous tensors.

Fused `triton_ihc_post_pre.py`: lines32–49 perform 24 serial chunks, update/store rounded R', project and accumulate squares in FP32 lanes. Lines50–59 reduce lanes, calculate RMS/gates, store next Post gates. Lines60–71 reload x and original R, RECOMPUTE rounded Post, then reduce channels. No Tensor Core operation in source; FMA explicitly disabled at109. One CTA/token, four warps. Updated residual is returned and needed by subsequent Post, so its global store cannot be eliminated by this fusion boundary alone.

Math: z=fp32(cast_dtype(g_prev*x+R)); inv_rms=rsqrt(sum(z*z)/(4D)+norm_eps); m=W*z; a=sigmoid(m[:4]*inv_rms*scale[0]+base[:4])+hc_eps; b=magnitude*sigmoid(m[4:]*inv_rms*scale[1]+base[4:])+hc_eps; y=cast_dtype(sum_c(a_c*z_c)). Original and fused use the same parameters and rounding boundary, with different FP32 reduction trees. Gates belong to producer Post and consumer Pre respectively. No mHC/Sinkhorn computation.

Runtime `model.py:206–305,354–364,forward loop`: shared CPU metadata predicate; N512–8192, BF16D6144C4/H100/eager. Intra uses MLP Pre parameters; pending cross state is x plus (R,g_prev), consumed by next Attention Pre. It introduces no copy or materialization on the fused branch; stage-tail Post remains. These are source facts; actual production launches and extra ops will be verified with model profiling.

## Tensor ledger: logical elements (not DRAM transactions)

|Tensor|Shape/dtype|Original|Fused|Interpretation|
|---|---|---|---|---|
|x|N,D BF16|read ND|read 4ND in projection loop + ND in final loop|Repeated addresses may hit cache/broadcast; verify generated code|
|old R|N,4,D BF16|read 4ND once|read 4ND twice|Second traversal and repeated Post are confirmed source redundancy|
|updated R'|N,4,D BF16|write 4ND, Pre1 read4ND, Pre2 read4ND|write4ND; not reloaded|Required output remains; two consumer traversals removed|
|previous gates|N,4 FP32|4 scalars per CTA, six CTAs/token|vector broadcast addresses in 24 chunks + four scalar references|Physical request count compiler-dependent, exclude from coarse byte model|
|W|8,4D FP32|read 8*4D per token|same|Unique size 768KiB; per-token requests are 6GiB atN8192, not necessarily HBM|
|scale/base|2 and8 FP32|per Pre2 CTA, six repeats|per token|Tiny; no full normalized tensor|
|partials|N,24,9 FP32|write once, read six times|absent|6.75MiB buffer,47.25MiB logical R/W atN8192|
|next gates|N,4 FP32|write4/token (block0 only)|write4/token|Required output|
|y|N,D BF16|writeND|writeND|Required output|

Critical distinction: ignoring gates/parameters, BOTH implementations issue 1728MiB of logical activation load/store elements atN8192. Fused trades updated-R rereads for old-R and x rereads; their cache locality differs. Neither fewer launches nor this ledger proves actual HBM savings. Partial traffic disappears, repeated RMS/partial reduction across six official Pre2 CTAs disappears, but Fused recomputes Post and has additional lane reduction work.
