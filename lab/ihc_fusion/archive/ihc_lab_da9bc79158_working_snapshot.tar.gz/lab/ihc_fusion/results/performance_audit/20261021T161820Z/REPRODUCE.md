# 复现与证据索引

## 固定条件

- Repo branch `exp/hy4-ihc-lab`；HEAD `ad3e62549ad5948df493dd4f8b0506cf236bb960`。
- **仅checkout HEAD不够**：本轮使用已有未提交跨层Runtime/test diff（raw/initial.diff）及已有bootstrap。initial.status、before_hashes.json记录初始状态。不要为了复现而覆盖他人的工作区。
- GPU3 NVIDIA H100 80GB HBM3、132 SM、50MiB L2，Driver575.57.08、CUDA12.9、PyTorch2.13.0+cu129、Triton3.7.1。Python来自已有 `lab/ihc_fusion/results/.venv/bin/python`。
- 本地checkout Python模块+已安装vLLM0.32.0+cu129二进制扩展，沿用既有 `results/runtime_integration/sitecustomize.py` 引导。生产算子导入 `vllm.models.hy_v4.nvidia.triton_ihc` 和 `triton_ihc_post_pre`，没有把Lab Kernel作为生产实现替代品。
- `HY4_AUDIT_CHECKPOINT` 指向本机已有、兼容TP1的三层FP8切片。只读使用，不保存权重内容、不下载模型。N512/1024/4096/8192、D6144、C4、BF16激活、FP32 HC权重/scale/base/gates，连续布局。
- 使用已有skill kernel-microbenchmark的“先检查正确性、计时与Profiler分离、生成代码取证”流程；用户禁止调参及环境安装的要求优先，本轮没有调参。沿用项目CUDA Event/Graph口径，不更换计时框架。

## 在独立目录复现

从repo根目录运行。先检查GPU3空闲，选择**新的**结果子目录（已有本轮目录不得覆盖）。复制本轮scripts到新目录，仅复制审计脚本，不复制或修改Kernel。下面`${AUDIT}`必须指向新的、已创建scripts/raw目录的审计运行目录。

```bash
git branch --show-current
git rev-parse HEAD
git status --short --untracked-files=all
git diff --stat
git diff --name-only
nvidia-smi -i 3 --query-gpu=name,driver_version,memory.used,utilization.gpu,clocks.sm,clocks.mem,power.limit --format=csv

# 在自己的shell中设置；不在公开报告中写入私有checkpoint绝对路径。
export HY4_AUDIT_CHECKPOINT='<existing-compatible-three-layer-slice>'
AUDIT=lab/ihc_fusion/results/performance_audit/<new-run>
bash "$AUDIT/scripts/run.sh" "$AUDIT/scripts/environment.py" > "$AUDIT/raw/environment.log" 2>&1
bash "$AUDIT/scripts/run.sh" "$AUDIT/scripts/counter_probe.py" > "$AUDIT/raw/counter_probe.log" 2>&1
bash "$AUDIT/scripts/run.sh" "$AUDIT/scripts/kernel_audit.py" > "$AUDIT/raw/kernel_audit.log" 2>&1
bash "$AUDIT/scripts/run.sh" "$AUDIT/scripts/model_audit.py" > "$AUDIT/raw/model_audit.log" 2>&1
PYTHONDONTWRITEBYTECODE=1 lab/ihc_fusion/results/.venv/bin/python "$AUDIT/scripts/analyze.py"
```

本轮实际 `AUDIT=lab/ihc_fusion/results/performance_audit/20261021T161820Z`。前四条Python实验命令均通过run.sh执行；kernel_audit/model_audit完整命令如上，输入checkpoint来自环境变量。CPU分析命令如上。write_reports.py生成本轮报告，含本轮数值叙述，**新机器/新结果需要重新核对文字，不可直接当成新结论**。model_paired.csv是从model_timing.csv按相同n/round直接相减、相除的派生结果，不是另一轮实测。

run.sh固定CUDA_VISIBLE_DEVICES=3；所有新Triton/CUDA/vLLM/Inductor/FlashInfer缓存都放新运行目录下。`PYTHONDONTWRITEBYTECODE=1`避免更改源码目录的pycache。不清理已有缓存，不安装工具，不改时钟。只运行一个GPU实验进程；CPU分析可与它并行。

## 实验与原始结果

|实验|目的与方法|结果与证据|局限/下一步|
|---|---|---|---|
|E00|Git、GPU和工具只读检查；初始逐文件hash|initial.status/diff、before_hashes.json、environment.json|HEAD以外跨层diff也是实验输入|
|E01|原始三Kernel、Fused、Runtime逐行数学/读写审计|SOURCE_AUDIT.md|source请求不是DRAM事务|
|E02|四个N的请求字节/FLOPs/硬件峰值下界|MEMORY_MODEL.md、memory_model.csv|带宽/计算理想模型，不是实际最优时间|
|Counter probe|5次warmup，N8192；_ExperimentalConfig请求两项DRAM指标|counter_probe.json/trace.json|只有activity，没有metric数值；失败能力探测保留|
|E03|30次warmup，每arm3次activity；编译资源/PTX/SASS|kernel_8192.trace.json、resources*.json、四组cubin/ptx/sass|activity duration有Profiler扰动；occupancy是资源上限|
|E04|每N同输入；30warmup，graph20replay；9轮交替×20调用；Eager/Graph×hot/flush256MiB|kernel_timing.csv/metadata.json、kernel_summary.csv|event为完整wrapper/graph执行跨度；大buffer不全驻留缓存|
|E05|现有torch.copy_和add_zero，256/1024MiB；graph；30warmup，9×20replay|bandwidth_reference.json|逻辑R+W吞吐参考，不是Fused实测HBM吞吐|
|E06|三模式真实模型；5warmup，9轮旋转/倒序；四个N|model_timing.csv、model_paired.csv、model_summary.csv|无Profiler，模型Forward而非TTFT；小N有CPU噪声|
|E07|每模式3warmup，N4096/8192各一次CPU+CUDA activity；模块标签关联|六个model_*.trace.json、model_*_activity.csv、model_profile_analysis.json|单条trace用于归因；与纯计时分离|
|E08|真实模型五个边界；3warmup、9轮；原始分段或融合整体event|model_boundary_timing.csv、model_boundary_totals.csv|事件插入数量不同可能扰动流水；不把差值当精确Runtime开销|
|E09|对生成代码统计和理论公式复查|EXPERIMENT_LOG.md、resources_analysis.json|修正派生统计，不改原始测量|
|E10|最终逐文件hash、diff、范围检查|scope_audit_final.json、final.status、final.diff.stat|既有精度失败保持，未重新做模型验收|

## Profiling命令与指标

实际activity通过scripts内 `torch.profiler.profile(activities=[CPU, CUDA])` 调用。Counter probe唯一请求的硬件Metric名称：

```text
dram__bytes_read.sum
dram__bytes_write.sum
```

两者均未返回数值。没有Nsight多pass报告，不使用Profiler墙钟作为Kernel latency。

反汇编实际命令（每个保存的cubin一次）：

```bash
/usr/local/lib/python3.12/dist-packages/triton/backends/nvidia/bin/nvdisasm "$AUDIT/raw/<kernel-hash>.cubin"
```

资源来自Triton compiled kernel `.n_regs/.n_spills/.metadata.shared/.num_warps/.src.constants`；驻留上限来自 `cuOccupancyMaxActiveBlocksPerMultiprocessor`。runtime trace包括grid、block、registers、shared、correlation。没有真实DRAM/L2/SM-active/stall Counter时字段留空；`profiler_metrics.csv`记录不可用原因。

## 原始数据解释

- kernel_timing.csv `event_us`：一整个PostPre路径；Original全部3个Kernel都在事件内。graph重放只捕获算子，不经过Runtime routing。
- `batch_wall_us_per_call`：一个20次批次CPU墙钟均摊，含事件管理；冷态也含flush。不得混为纯GPU耗时。
- model_timing.csv：model forward和各layer event，最后层含Head之前/之后范围以既有hook为准；layer时间不能简单与pending边界归属作数学等价比较，总Forward才是性能目标。
- model_boundary_totals.csv：同一n/round/mode的目标边界event总和；两原始模块间没有插入新的数学操作。
- activity CSV：通过CUDA调用correlation映射到CPU module标签；`inside_forward=False`的采样/Logits等不计入模型分解。类别按最内层Attention/MLP标签，再由特定iHC函数名覆盖，互斥计算。
- 原始trace包括Profiler注入的同步；非Profiler实验不含它们。外部同步在计时event以外。
- 这组脚本是独立审计工具，没有注册新的Runtime函数、修改源码或使用替代Kernel算法。

H200复现应保持同样算法、计时/缓存/shape条件，并记录硬件差异。当前生产route只支持已验证H100，**H200上不能为了测Cross而绕过route或把fallback误称融合**；若H200模型安全回退，先记录事实，仅独立算子可以另行测量，不擅改本轮冻结实现。
