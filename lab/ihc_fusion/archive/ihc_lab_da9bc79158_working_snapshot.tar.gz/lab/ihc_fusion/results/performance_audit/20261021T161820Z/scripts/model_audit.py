"""Audit existing eager three-layer runtime; no source or kernel modifications."""
import csv
import datetime
import json
import os
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(os.environ['AUDIT_RUN'])
RAW = ROOT / 'raw'
checkpoint = os.environ['HY4_AUDIT_CHECKPOINT']
# Keep private checkpoint location out of persisted startup output.
class Redacted:
    def __init__(self, stream): self.stream = stream
    def write(self, text): return self.stream.write(text.replace(checkpoint, '<existing-three-layer-slice>'))
    def flush(self): return self.stream.flush()
    def __getattr__(self, key): return getattr(self.stream, key)
sys.stdout = Redacted(sys.stdout)
sys.stderr = Redacted(sys.stderr)

import torch
from torch.profiler import ProfilerActivity, profile, record_function
from vllm import LLM, SamplingParams
from vllm.models.hy_v4.nvidia import model as hy4

MODES = ('original', 'intra', 'cross')
llm = LLM(model=checkpoint, tensor_parallel_size=1, enforce_eager=True,
          max_model_len=8448, max_num_batched_tokens=8192,
          gpu_memory_utilization=.65, enable_prefix_caching=False, max_num_seqs=4,
          trust_remote_code=True, distributed_executor_backend='uni',
          hf_overrides={'enable_ihc_post_pre_fusion': True,
                        'enable_ihc_cross_layer_fusion': True})
model = llm.apply_model(lambda m: m)[0]
layers = list(model.model.layers)
assert len(layers) == 3
assert all(l._ihc_fusion_enabled for l in layers)
assert [l._ihc_defer_post for l in layers] == [True, True, False]

def mode(name):
    for i, layer in enumerate(layers):
        layer._ihc_fusion_enabled = name != 'original'
        layer._ihc_defer_post = name == 'cross' and i < 2

def generate(n):
    torch.manual_seed(7)
    return llm.generate([{'prompt_token_ids': [100 + i % 197 for i in range(n)]}],
                        SamplingParams(temperature=0, max_tokens=1, seed=7),
                        use_tqdm=False)

def ordered(repeat):
    order = MODES[repeat % 3:] + MODES[:repeat % 3]
    return order[::-1] if repeat % 2 else order

def log(message):
    with (ROOT / 'EXPERIMENT_LOG.md').open('a') as f:
        f.write('\n' + datetime.datetime.now(datetime.timezone.utc).isoformat() + ' ' + message + '\n')

# E06: pure timing, matching prior model/layer event-hook scope. No profiler.
starts, pending, handles = {}, [], []
def before(module, args, kwargs):
    event = torch.cuda.Event(enable_timing=True); event.record()
    starts[id(module)] = event
def after(module, args, kwargs, result):
    event = torch.cuda.Event(enable_timing=True); event.record()
    pending.append((id(module), starts[id(module)], event))
for module in [model, *layers]:
    handles.extend([module.register_forward_pre_hook(before, with_kwargs=True),
                    module.register_forward_hook(after, with_kwargs=True)])
with (RAW / 'model_timing.csv').open('x', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['n','round','order','mode','forward_us','layer0_us','layer1_us','layer2_us','request_wall_ms'])
    writer.writeheader()
    for n in (512, 1024, 4096, 8192):
        for selected in MODES:
            mode(selected)
            for _ in range(5): generate(n)
        values = {key: [] for key in MODES}
        for repeat in range(9):
            for position, selected in enumerate(ordered(repeat)):
                mode(selected); pending.clear(); torch.cuda.synchronize()
                start = time.perf_counter(); generate(n); torch.cuda.synchronize()
                times = {key: a.elapsed_time(b)*1000 for key,a,b in pending}
                assert len(pending) == 4, 'Unexpected chunking/multiple forwards'
                writer.writerow(dict(n=n, round=repeat, order=position, mode=selected,
                    forward_us=times[id(model)],
                    **{f'layer{i}_us': times[id(layer)] for i,layer in enumerate(layers)},
                    request_wall_ms=(time.perf_counter()-start)*1000))
                values[selected].append(times[id(model)]); f.flush()
        print('MODEL_TIMING', n, {k:statistics.median(v) for k,v in values.items()}, flush=True)
        log(f'E06 shape N={n}: 5 warmups/mode, 9 rotated/reversed paired rounds; model_timing.csv. Profiling inactive. TP1 BF16 D6144 C4, actual FP8 three-layer slice, eager, prefix cache disabled.')
for h in handles: h.remove()

# E07: separate actual runtime trace. Tags attribute kernel launches to modules.
profile_handles = []
def tag(module, label):
    stack = []
    def enter(m,a,k):
        ctx = record_function('AUDIT::'+label); ctx.__enter__(); stack.append(ctx)
    def leave(m,a,k,r): stack.pop().__exit__(None,None,None)
    profile_handles.extend([module.register_forward_pre_hook(enter,with_kwargs=True),
                            module.register_forward_hook(leave,with_kwargs=True)])
tag(model,'forward')
for i,layer in enumerate(layers):
    tag(layer.self_attn, f'attention.{i}')
    tag(layer.mlp, f'mlp.{i}')
    tag(layer.input_layernorm, f'norm_in.{i}')
    tag(layer.post_attention_layernorm, f'norm_mlp.{i}')
    for sub,hc in [('attention',layer.hc_attn_layer),('mlp',layer.hc_mlp_layer)]:
        tag(hc.hc_pre, f'pre.{i}.{sub}')
        tag(hc.hc_post, f'post.{i}.{sub}')
tag(model.model.hc_head,'hc_head')
trace_rows=[]
for n in (4096,8192):
    for selected in MODES:
        mode(selected)
        for _ in range(3): generate(n)
        torch.cuda.synchronize()
        with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
            generate(n); torch.cuda.synchronize()
        path = RAW / f'model_{n}_{selected}.trace.json'
        prof.export_chrome_trace(str(path))
        trace_rows.append(dict(n=n,mode=selected,file=path.name))
        print('MODEL_TRACE',n,selected,flush=True)
for h in profile_handles: h.remove()
(RAW/'model_trace_manifest.json').write_text(json.dumps(trace_rows,indent=2))
log('E07 complete: six warmed CPU/CUDA activity traces (N4096/8192 × original/intra/cross); model trace manifest saved. Profiler timings are attribution only, not pure benchmark.')

# E08: matched eager target-boundary timing in model, separate from pure timing.
# Hooks measure original constituent Post/Pre, or exact fused production call.
# This instrumented run has extra events; do not compare its model latency to E06.
records=[]; boundary_handles=[]; boundary_starts={}
def boundary_tag(module,label):
    def enter(m,a,k):
        event=torch.cuda.Event(enable_timing=True);event.record();boundary_starts[label]=event
    def leave(m,a,k,r):
        event=torch.cuda.Event(enable_timing=True);event.record()
        records.append((label,boundary_starts[label],event))
    boundary_handles.extend([module.register_forward_pre_hook(enter,with_kwargs=True),
                             module.register_forward_hook(leave,with_kwargs=True)])
for i,layer in enumerate(layers):
    boundary_tag(layer.hc_attn_layer.hc_post,f'intra.{i}.post')
    boundary_tag(layer.hc_mlp_layer.hc_pre,f'intra.{i}.pre')
    if i < 2: boundary_tag(layer.hc_mlp_layer.hc_post,f'cross.{i+1}.post')
    if i > 0: boundary_tag(layer.hc_attn_layer.hc_pre,f'cross.{i}.pre')
weights={}
for i,layer in enumerate(layers):
    weights[layer.hc_mlp_layer.hc_pre.hc_fn.weight.data_ptr()] = f'intra.{i}.fused'
    weights[layer.hc_attn_layer.hc_pre.hc_fn.weight.data_ptr()] = f'cross.{i}.fused'
real_fused=hy4.triton_ihc_post_pre
def measured_fused(*args):
    a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
    a.record();result=real_fused(*args);b.record()
    records.append((weights[args[3].data_ptr()],a,b));return result
hy4.triton_ihc_post_pre=measured_fused
with (RAW/'model_boundary_timing.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['n','round','mode','boundary','event_us']);writer.writeheader()
    for n in (4096,8192):
        for selected in MODES:
            mode(selected)
            for _ in range(3):generate(n)
        for repeat in range(9):
            for selected in ordered(repeat):
                mode(selected); records.clear(); generate(n); torch.cuda.synchronize()
                assert len(records)=={'original':10,'intra':7,'cross':5}[selected]
                for label,a,b in records:
                    writer.writerow(dict(n=n,round=repeat,mode=selected,boundary=label,event_us=a.elapsed_time(b)*1000))
                f.flush()
        print('BOUNDARIES_TIMED',n,flush=True)
hy4.triton_ihc_post_pre=real_fused
for h in boundary_handles:h.remove()
log('E08 complete: model_boundary_timing.csv contains five target boundaries (original: ten constituent spans; intra: three fused + four original spans; cross: five fused). Eager event timings, 3 warmups/mode, 9 paired rounds, no profiler. Instrumentation overhead is a limitation; pure model timing is E06.')
(RAW/'model_metadata.json').write_text(json.dumps(dict(checkpoint='existing FP8 three-layer slice',tp=1,gpu=torch.cuda.get_device_name(),dtype='BF16 activations',d=6144,c=4,graph=False,warmup=5,rounds=9,seed=7,prompt='100 + index % 197',prefix_cache=False,max_tokens=1,n=[512,1024,4096,8192],correctness='Performance-only audit: existing 161 passed / 1 failed and strict model A/A A/B unresolved; no accuracy certification'),indent=2))
print('MODEL_AUDIT_COMPLETE',flush=True)
