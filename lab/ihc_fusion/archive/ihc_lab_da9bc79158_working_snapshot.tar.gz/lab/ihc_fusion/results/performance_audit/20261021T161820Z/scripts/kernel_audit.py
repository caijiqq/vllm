"""Existing production kernels: unchanged launch configs, timing and profiling separated."""
import csv
import ctypes
import datetime
import json
import os
import re
import statistics
import subprocess
import time
from pathlib import Path
import torch
from safetensors import safe_open
from torch.profiler import profile, ProfilerActivity, record_function
from vllm.models.hy_v4.nvidia import triton_ihc as official
from vllm.models.hy_v4.nvidia import triton_ihc_post_pre as fused_module
from lab.ihc_fusion.tests.cases import make_case, check_outputs

ROOT=Path(os.environ['AUDIT_RUN']); RAW=ROOT/'raw'
checkpoint=Path(os.environ['HY4_AUDIT_CHECKPOINT'])
config=json.loads((checkpoint/'config.json').read_text())
weights={}
with safe_open(checkpoint/'model.safetensors',framework='pt',device='cpu') as sf:
    for sub in ('hc_attn_layer','hc_mlp_layer'):
        weights[sub]=[sf.get_tensor(f'model.layers.0.{sub}.hc_pre.{k}').cuda() for k in ('hc_fn','hc_scale','hc_base')]
scalars=(config['hc_magnitude'],config['hc_eps'],config['rms_norm_eps'])

def make_args(n):
    x,r=make_case(n,6144,torch.bfloat16)[:2]
    _,g=official.triton_ihc_pre(r,*weights['hc_attn_layer'],*scalars)
    return (x,r,g,*weights['hc_mlp_layer'],*scalars)

def original(*a):
    r=official.triton_ihc_post(*a[:3])
    y,g=official.triton_ihc_pre(r,*a[3:])
    return y,r,g

functions={'original':original,'fused':fused_module.triton_ihc_post_pre}
args=make_args(8192)
for fn in functions.values():
    for _ in range(30):fn(*args)
torch.cuda.synchronize()
error=check_outputs(functions['fused'](*args),functions['original'](*args))
(RAW/'kernel_correctness.json').write_text(json.dumps(error,indent=2))
# E03: Kernel-only activity trace, after warmup; never use profiler wall as latency.
with profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA]) as prof:
    for name,fn in functions.items():
        with record_function('AUDIT::'+name):
            for _ in range(3):fn(*args)
    torch.cuda.synchronize()
prof.export_chrome_trace(str(RAW/'kernel_8192.trace.json'))

cu=ctypes.CDLL('libcuda.so.1')
cu.cuOccupancyMaxActiveBlocksPerMultiprocessor.argtypes=[ctypes.POINTER(ctypes.c_int),ctypes.c_void_p,ctypes.c_int,ctypes.c_size_t]
resources=[]
for fn in (official._ihc_post_kernel,official._ihc_pre_stage1,official._ihc_pre_stage2,fused_module._fused_post_pre):
    for cache in fn.device_caches.values():
        for kernel in cache[0].values():
            base=fn.__name__+'_'+kernel.hash[:10]
            ptx=kernel.asm['ptx']
            (RAW/(base+'.ptx')).write_text(ptx)
            (RAW/(base+'.cubin')).write_bytes(kernel.asm['cubin'])
            dis=subprocess.run(['/usr/local/lib/python3.12/dist-packages/triton/backends/nvidia/bin/nvdisasm',str(RAW/(base+'.cubin'))],capture_output=True,text=True)
            (RAW/(base+'.sass')).write_text(dis.stdout+dis.stderr)
            block=32*kernel.metadata.num_warps
            limit=ctypes.c_int()
            status=cu.cuOccupancyMaxActiveBlocksPerMultiprocessor(ctypes.byref(limit),ctypes.c_void_p(kernel.function),block,kernel.metadata.shared)
            r=dict(name=fn.__name__,hash=kernel.hash,registers_per_thread=kernel.n_regs,spill_count=kernel.n_spills,
                   shared_bytes=kernel.metadata.shared,threads_per_cta=block,
                   max_active_ctas_per_sm=limit.value if status==0 else None,occupancy_query_status=status,
                   resource_occupancy_limit=limit.value*block/2048 if status==0 else None,
                   ptx_local_loads=ptx.count('ld.local'),ptx_local_stores=ptx.count('st.local'),
                   sass_local_loads=len(re.findall(r'\bLDL\b',dis.stdout)),sass_local_stores=len(re.findall(r'\bSTL\b',dis.stdout)),
                   sass_tensor_instructions=len(re.findall(r'\b(?:HMMA|HGMMA|IMMA|MMA)\b',dis.stdout)),
                   sass_fp32_fma=len(re.findall(r'\bFFMA\b',dis.stdout)),
                   constants={str(k):str(v) for k,v in kernel.src.constants.items()},
                   artifacts=base)
            resources.append(r)
(RAW/'resources.json').write_text(json.dumps(resources,indent=2))
with (ROOT/'EXPERIMENT_LOG.md').open('a') as f:f.write('\nE03 — '+datetime.datetime.now(datetime.timezone.utc).isoformat()+' kernel activity profile/resource collection complete. Command: HY4_AUDIT_CHECKPOINT=<existing-slice> bash scripts/run.sh scripts/kernel_audit.py (repository-relative full paths in REPRODUCE). N8192 BF16D6144C4, production Original3/Fused1. Actual calls/launches, resource bounds and cubin/PTX/SASS saved; no hardware metric values inferred from source. Profiler phase finished before timing.\n')
print('PROFILE_RESOURCES_COMPLETE',resources,flush=True)

# E04: all timers are outside profiler. Hot/cold-L2, eager/graph on same inputs.
flush=torch.empty(256*1024*1024,dtype=torch.uint8,device='cuda')
rows=[]
with (RAW/'kernel_timing.csv').open('x',newline='') as file:
    fields=['n','mode','cache','implementation','round','sample','event_us','batch_wall_us_per_call']
    writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
    for n in (8192,4096,1024,512):
        args=make_args(n)
        check_outputs(functions['fused'](*args),functions['original'](*args))
        callers={name:(lambda fn=fn:fn(*args)) for name,fn in functions.items()}
        for fn in callers.values():
            for _ in range(30):fn()
        graphs={}
        for name,fn in callers.items():
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):out=fn()
            graphs[name]=(graph,out)
            for _ in range(20):graph.replay()
        torch.cuda.synchronize()
        for execution in ('eager','graph'):
            for cache in ('hot','flush256MiB'):
                for repeat in range(9):
                    order=('original','fused') if repeat%2==0 else ('fused','original')
                    for name in order:
                        fn=callers[name] if execution=='eager' else graphs[name][0].replay
                        events=[]
                        torch.cuda.synchronize();begin=time.perf_counter()
                        for i in range(20):
                            if cache!='hot':flush.zero_()
                            a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
                            a.record();out=fn();b.record();events.append((a,b))
                        torch.cuda.synchronize();wall=(time.perf_counter()-begin)*1e6/20
                        for i,(a,b) in enumerate(events):
                            row=dict(n=n,mode=execution,cache=cache,implementation=name,round=repeat,sample=i,event_us=a.elapsed_time(b)*1000,batch_wall_us_per_call=wall)
                            writer.writerow(row);rows.append(row)
                        file.flush()
        print('TIMED',n,flush=True)
# E05: large working-set bandwidth reference; existing ATen ops, not a new kernel.
copy_rows=[]
for mib in (256,1024):
    src=torch.ones(mib*1024*1024//4,device='cuda');dst=torch.empty_like(src)
    for name,fn in [('copy',lambda:dst.copy_(src)),('add_zero',lambda:torch.add(src,0,out=dst))]:
        for _ in range(30):fn()
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):fn()
        for repeat in range(9):
            a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
            a.record()
            for _ in range(20):graph.replay()
            b.record();b.synchronize();us=a.elapsed_time(b)*1000/20
            copy_rows.append(dict(mib=mib,operation=name,round=repeat,event_us=us,logical_read_write_bytes=2*mib*1024*1024,TBps=2*mib*1024*1024/us/1e6))
(RAW/'bandwidth_reference.json').write_text(json.dumps(copy_rows,indent=2))
(RAW/'kernel_timing_metadata.json').write_text(json.dumps(dict(n=[512,1024,4096,8192],d=6144,c=4,dtype='bfloat16',weights='real slice layer0 Attention/MLP HC parameters; no values saved',warmup=30,graph_warmup=20,rounds=9,calls_per_round=20,cache='fixed inputs hot OR 256MiB zero_ before each timed interval; flush excluded from CUDA-event time',eager='production wrappers incl allocations and Python submission gaps between event marks',graph='same production wrappers captured once; CPU allocation/route absent at replay',clock_control='no clock changes; paired alternating order; GPU3 exclusive at launch'),indent=2))
with (ROOT/'EXPERIMENT_LOG.md').open('a') as f:f.write('\nE04/E05 — '+datetime.datetime.now(datetime.timezone.utc).isoformat()+' independent eager/graph hot/flush timings and large-buffer bandwidth reference complete. Commands as E03. Raw per-call data in kernel_timing.csv; reference in bandwidth_reference.json. Hardware counters absent from counter probe trace despite requested dram__bytes_read.sum/dram__bytes_write.sum; activity tracing works. Source correctness checked only at boundaries, existing chain failure untouched.\n')
print('KERNEL_AUDIT_COMPLETE',flush=True)
