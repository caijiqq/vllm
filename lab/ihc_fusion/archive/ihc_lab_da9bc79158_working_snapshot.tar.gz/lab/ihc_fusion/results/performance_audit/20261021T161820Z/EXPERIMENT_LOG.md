# Experiment log

E00 — 2026-10-21T16:18:20.859493+00:00

Scope audit: HEAD ad3e62549; intra committed, cross-layer changes uncommitted. GPU3 idle (17 MiB, 0%). ncu/nsys/nvdisasm not found on PATH; installation search follows. Snapshot of all existing non-ignored files and tracked diff saved. Existing correctness remains 161 passed / 1 failed, not retested or changed.

E01/E02 — 2026-10-21T16:21Z: source and theoretical audit saved before profiling. Source facts: required residual store retained; old residual reread and repeated Post; partial buffer eliminated. Hypothesis: locality and removal of sixfold epilogue work explain speedup despite similar activation request volume. Counter tools absent in PATH and standard install trees; RmProfilingAdminOnly=0, so no observed permission denial. PyTorch CUPTI metrics support will be probed without installation/system changes.

E03 — 2026-10-21T16:25:08.297014+00:00 kernel activity profile/resource collection complete. Command: HY4_AUDIT_CHECKPOINT=<existing-slice> bash scripts/run.sh scripts/kernel_audit.py (repository-relative full paths in REPRODUCE). N8192 BF16D6144C4, production Original3/Fused1. Actual calls/launches, resource bounds and cubin/PTX/SASS saved; no hardware metric values inferred from source. Profiler phase finished before timing.

E04/E05 — 2026-10-21T16:25:11.995997+00:00 independent eager/graph hot/flush timings and large-buffer bandwidth reference complete. Commands as E03. Raw per-call data in kernel_timing.csv; reference in bandwidth_reference.json. Hardware counters absent from counter probe trace despite requested dram__bytes_read.sum/dram__bytes_write.sum; activity tracing works. Source correctness checked only at boundaries, existing chain failure untouched.

2026-10-21T16:29:34.722130+00:00 E06 shape N=512: 5 warmups/mode, 9 rotated/reversed paired rounds; model_timing.csv. Profiling inactive. TP1 BF16 D6144 C4, actual FP8 three-layer slice, eager, prefix cache disabled.

2026-10-21T16:29:35.441826+00:00 E06 shape N=1024: 5 warmups/mode, 9 rotated/reversed paired rounds; model_timing.csv. Profiling inactive. TP1 BF16 D6144 C4, actual FP8 three-layer slice, eager, prefix cache disabled.

2026-10-21T16:29:37.408818+00:00 E06 shape N=4096: 5 warmups/mode, 9 rotated/reversed paired rounds; model_timing.csv. Profiling inactive. TP1 BF16 D6144 C4, actual FP8 three-layer slice, eager, prefix cache disabled.

2026-10-21T16:29:41.174118+00:00 E06 shape N=8192: 5 warmups/mode, 9 rotated/reversed paired rounds; model_timing.csv. Profiling inactive. TP1 BF16 D6144 C4, actual FP8 three-layer slice, eager, prefix cache disabled.

2026-10-21T16:29:42.949204+00:00 E07 complete: six warmed CPU/CUDA activity traces (N4096/8192 × original/intra/cross); model trace manifest saved. Profiler timings are attribution only, not pure benchmark.

2026-10-21T16:29:47.869305+00:00 E08 complete: model_boundary_timing.csv contains five target boundaries (original: ten constituent spans; intra: three fused + four original spans; cross: five fused). Eager event timings, 3 warmups/mode, 9 paired rounds, no profiler. Instrumentation overhead is a limitation; pure model timing is E06.

E09 — derived-data review: corrected source-byte CSV extra fused x reads from three to four additional traversals; corrected Original coarse FLOPs 20K → 22K/token to include Post (Pre alone is approximately 20K). No measured data changed. Initial SASS regex matched scalar HFMA2.MMA modifiers as tensor instructions; corrected opcode-anchored analysis is resources_analysis.json (all four kernels have zero MMA/Tensor Core instructions). The original collection JSON is retained for traceability.

E09 observations: Eager N8192 1308.496→854.272us; graph hot1310.624→857.520us. Model N8192 medians78.185/76.972/76.234ms, paired Original/Cross median1.0302x. Actual launches0/3/5 Fused verified, no extra HC copies. N512 model median regresses; all samples retained. Counter gap prevents declaring bandwidth-bound, compute-bound or near-optimal. Final report chooses C for kernel ceiling, and identifies five-boundary share≈8.8% as the explanation for model≈3%.

E10 first scope-check attempt: all7905 hashed files unchanged and git diff identical, but assertion falsely classified eight tracked .claude/skills directory symlinks as new (initial is_file hash snapshot excludes directory links). Failure retained in raw/scope_audit.json. Final checker separately verifies readlink contents against HEAD blobs, without modifying links, and writes scope_audit_final.json. This is audit bookkeeping, not a repository change.

E10 — 2026-10-21T16:37:32.117217+00:00 scope audit: 7905 pre-existing nonignored files SHA256-verified; no change/missing file, no new file outside allowed directory; original git diff byte-identical, no staged files. Audit scripts AST parse passed; git diff --check status 0. Evidence raw/scope_audit_final.json and final.status/diff.stat. No production correctness tests rerun; existing 161/1 limitation retained.
