"""Generate audit reports from saved evidence; no GPU work."""
import csv
import json
import statistics as st
from pathlib import Path
R=Path(__file__).resolve().parent.parent; P=R/'raw'
def read(name):return list(csv.DictReader((P/name).open()))
def med(rows,key):return st.median(float(r[key]) for r in rows)
def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in rows)
k=read('kernel_summary.csv');m=read('model_summary.csv');b=read('model_boundary_totals.csv');pairs=read('model_paired.csv')
profiles=json.loads((P/'model_profile_analysis.json').read_text())
res=json.loads((P/'resources_analysis.json').read_text())
ms={(int(r['n']),r['mode']):float(r['median_us']) for r in m}
ks={(int(r['n']),r['mode'],r['cache'],r['implementation']):float(r['median_us']) for r in k}
mtable=table(['N','Original ms','Intra ms','Intra+Cross ms','Original/Cross','Intra/Cross'],[
 [n,*[f'{ms[n,x]/1000:.3f}' for x in ('original','intra','cross')],f'{ms[n,"original"]/ms[n,"cross"]:.4f}×',f'{ms[n,"intra"]/ms[n,"cross"]:.4f}×'] for n in (512,1024,4096,8192)])
ktable=table(['N','模式','缓存','Original µs','Fused µs','Speedup'],[
 [n,mode,cache,f'{ks[n,mode,cache,"original"]:.3f}',f'{ks[n,mode,cache,"fused"]:.3f}',f'{ks[n,mode,cache,"original"]/ks[n,mode,cache,"fused"]:.3f}×'] for n in (512,1024,4096,8192) for mode in ('eager','graph') for cache in ('hot','flush256MiB')])
noise=table(['N','模式','Median ms','P10 ms','P90 ms'],[[r['n'],r['mode'],*[f'{float(r[x])/1000:.3f}' for x in ('median_us','p10_us','p90_us')]] for r in m])
pairedtable=table(['N','Original−Cross 配对中位数 ms','配对差值范围 ms','配对 Speedup 中位数','Intra−Cross 配对中位数 ms','配对差值范围 ms'],[
 [n,f'{med([r for r in pairs if int(r["n"])==n],"saved_original_cross_us")/1000:.3f}',
  '–'.join(f'{fn(float(r["saved_original_cross_us"]) for r in pairs if int(r["n"])==n)/1000:.3f}' for fn in (min,max)),
  f'{med([r for r in pairs if int(r["n"])==n],"speedup_original_cross"):.4f}×',
  f'{med([r for r in pairs if int(r["n"])==n],"saved_intra_cross_us")/1000:.3f}',
  '–'.join(f'{fn(float(r["saved_intra_cross_us"]) for r in pairs if int(r["n"])==n)/1000:.3f}' for fn in (min,max))] for n in (512,1024,4096,8192)])
btable=table(['N','模式','五个目标边界 Eager Event 合计 median ms','min–max ms'],[
 [n,mode,f'{med([r for r in b if int(r["n"])==n and r["mode"]==mode],"target_five_us")/1000:.3f}',
  '–'.join(f'{fn(float(r["target_five_us"]) for r in b if int(r["n"])==n and r["mode"]==mode)/1000:.3f}' for fn in (min,max))] for n in (4096,8192) for mode in ('original','intra','cross')])
pbreak=table(['N','模式','Attention ms','MLP ms','原始 iHC ms','Fused ms','HCHead ms','Other ms','GPU union ms','span−union ms'],[
 [r['n'],r['mode'],*[f'{r["breakdown"].get(key,{}).get("sum_us",0)/1000:.3f}' for key in ('attention','mlp','original_ihc','fused_post_pre','hc_head','other')],f'{r["gpu_activity_union_us"]/1000:.3f}',f'{(r["gpu_span_us"]-r["gpu_activity_union_us"])/1000:.3f}'] for r in profiles])
counts=table(['模式','Post','Pre1','Pre2','Fused','iHC 总 Launch'],[['Original',6,6,6,0,18],['Intra',3,3,3,3,12],['Intra+Cross',1,1,1,5,8]])
resource=table(['Kernel','Grid','Threads/CTA','Registers/thread','Shared B','Spill','资源上限 CTA/SM','资源 occupancy 上限'],[
 [r['name'],{'_ihc_post_kernel':'[N,6]','_ihc_pre_stage1':'[N,24]','_ihc_pre_stage2':'[N,6]','_fused_post_pre':'[N]'}[r['name']],r['threads_per_cta'],r['registers_per_thread'],r['shared_bytes'],r['spill_count'],r['max_active_ctas_per_sm'],f'{r["resource_occupancy_limit"]*100:.2f}%'] for r in res])
O=ms[8192,'original'];C=ms[8192,'cross']; saving=O-C
BO=med([r for r in b if int(r['n'])==8192 and r['mode']=='original'],'target_five_us')
BC=med([r for r in b if int(r['n'])==8192 and r['mode']=='cross'],'target_five_us')
amdahl=table(['目标（相对 Original 的 Speedup）','总计需节省 ms','相对本轮中位数还需节省 ms','若只优化五个现有 Fused，平均每次还需节省 µs'],[
 [f'{s:.2f}×',f'{(O-O/s)/1000:.3f}',f'{(O-O/s-saving)/1000:.3f}',f'{(O-O/s-saving)/5:.1f}'] for s in (1.05,1.10)])

(R/'PROFILE_ANALYSIS.md').write_text('''# H100 Kernel profiling 与独立计时

## 方法和缺失指标

E03 使用 PyTorch CPU/CUDA activity profiler，N8192，每条路径预热30次，实际 Original3/Fused1 launch；各路径记录3次。E04/E05 在 profiler 完全退出后计时。同一真实 HC 参数、BF16输入、D6144/C4，9轮交替顺序，每轮20次。Graph 是独立算子 capture，模型 Runtime 仍为 Eager。`flush256MiB` 在每次起始 event 前执行，flush 本身不计入 Event 时间；这只是冷 L2 代理，不能保证每个 cache line 都被驱逐。缓存热态也不表示大于 L2 的全部工作集驻留缓存。

Nsight Compute/Systems 未安装或未在已搜索目录找到，不是已证实的权限拒绝。只读驱动参数 RmProfilingAdminOnly=0。已有 CUPTI 库可支持 activity；通过 `_ExperimentalConfig` 请求 `dram__bytes_read.sum`、`dram__bytes_write.sum` 未报错，但 trace 没有任何对应值。不能将“参数被接受”当作 Counter 成功。DRAM/L2 bytes、命中率、SM throughput、实际 achieved occupancy、warp stalls、load/store efficiency 均未知。具体请求和失败证据见 counter_probe.py、raw/counter_probe.json、raw/counter_probe.trace.json。

## 资源与生成代码

'''+resource+'''
这些 occupancy 数字来自 CUDA occupancy API 和 profiler 的寄存器资源估算，不是实测活跃 warp 比例。Fused 的上限为3 CTA/SM（12 warps/64）；shared memory 4KiB 不是限制项，寄存器168/thread 是限制项。N8192 有8192 CTA，平均62.1 CTA/SM的总工作量，约20.7轮3-CTA驻留批次；不存在小N那种全卡仅一两个CTA的问题。不能用18.75%直接乘峰值算力或断言降低寄存器一定提速。

Triton metadata spill=0；PTX 无ld.local/st.local，SASS 无LDL/STL。SASS 无FP32 FFMA；有FMUL/FADD，保留非FMA语义。无真正HMMA/HGMMA/IMMA/DMMA/MMA及PTX mma/wgmma指令。初始资源收集正则误把HFMA2.MMA标量指令修饰符计为MMA，原始resources.json保留，修正后的逐操作码统计在resources_analysis.json；不要引用原始sass_tensor_instructions字段作为Tensor Core计数。后向BRA与PTX loop对应24次串行chunk；源码末尾重复Post在生成代码中仍有第二组load/mul/add/round。

N8192 profiler 单Kernel中位数：Post 305.465µs，Pre1 813.360µs，Pre2 183.164µs；合计1301.989µs；Fused 848.942µs。Pre1占原始三阶段约62.5%。Fused耗时接近原Pre1，但这不是其内部投影阶段独立计时：新Kernel的Post、投影、归约、第二次Post没有独立时间戳，不能拆出百分比。

## 完整路径独立计时

'''+ktable+'''
所有每次样本在 raw/kernel_timing.csv；P10/P90、min/max和每轮中位数的分布在 raw/kernel_summary.csv。每个单元180次样本；第一条偏慢样本也保留。批次wall字段包含Python/event创建开销，冷态还包含flush，不能把它解释成纯Kernel耗时。

N8192 Eager/Graph热态分别854.272/857.520µs，差值小于0.4%；热/flush差值约0.3–0.6%。因此大N不是以Python Launch为主的瓶颈。冷态差异小不能证明HBM不重要：输入输出工作集本身远超50MiB L2，而权重只有768KiB，单次Kernel内仍可反复热起来。N512受缓存和提交方式影响更大。

## 可以确认与不能确认

- 已确认：单次3→1 launch；必要Residual store保留；Partial buffer消失；旧Residual第二次加载和Post重复计算；24次chunk循环；寄存器限制并发；无spill。
- 未确认：HBM究竟节省多少，L2是否饱和，long-scoreboard/issue stall占比，寄存器限制是否位于关键路径，854µs内部阶段占比。
- Hypothesis：以L2供给权重、FP32投影/串行依赖及低warp并发构成混合瓶颈；不能将其写成已测定的Memory Bound或Compute Bound。
- 下一项最小实验：在有合适Nsight Compute的H100环境，只对同一N8192 Original三Kernel和Fused采集DRAM/L2吞吐、SM/warp issue、实际occupancy及stall。先`ncu --query-metrics`确认版本支持名称，再选择小集合；不需要先改Kernel。当前审计未安装工具、未改变权限/时钟。
''')

(R/'RUNTIME_BREAKDOWN.md').write_text('''# 三层真实切片 Runtime 审计

真实已存在三层FP8权重，BF16激活，D6144/C4，TP1，GPU3 H100，Eager，单请求纯Prefill，max_tokens=1，prefix cache关闭。固定输入token和seed；固定同一模型实例仅切换既有开关。计时范围与前轮一致：顶层模型Forward及三个DecoderLayer的CUDA Event hook，不含最终Logits、采样和请求调度；request_wall_ms另存但不作TTFT。

## 纯计时（无Profiler）

每Shape每模式5次warmup，9轮交替/倒序配对。没有修改应用时钟，也没有周期性频率采样；因此频率/CPU调度的残余变化未排除。完整每轮值在model_timing.csv，配对值在model_paired.csv。

'''+mtable+'\n'+noise+'\n'+pairedtable+'''
“各组中位数的比值”与“同轮配对比值的中位数”不同，均保留。N8192前者1.0256×、后者1.0302×；Original−Cross每轮都为正，但跨层相对仅同层有一轮负差。N4096 Original−Cross也每轮为正。N512不能证明稳定收益，N1024有高尾噪声；不得仅选最快轮次。历史表的约1.029×与本轮量级一致，但不宣称精确复现每一个百分点。

## 实际执行证据

N4096/N8192各模式各一份已预热activity trace，Profiler与上表计时分离。通过CUDA correlation将Kernel关联到其CPU发起调用，再落入最内层module tag。Kernel函数名和launch数量是真实活动，不只是Python分支计数。

'''+counts+'''
Cross确有5个生产`_fused_post_pre`（3个同层、2个跨层）；保留1个首层Pre1、1个首层Pre2和1个末层Post。没有中途路由回退，没有重复执行已替代的Post/Pre。其余Attention91、MLP31、HCHead15、Other10个GPU活动在三模式间数量一致。Attention/MLP类别包含其模块内部copy/memset；不另行加总它们，避免重复计算。

HC模块内没有aten::clone/contiguous/copy/_to_copy活动；全部forward的cudaMemcpyAsync计数均3，cudaEventRecord均2。N8192 cudaMemsetAsync均12（N4096均9），没有随cross状态增加。Fused wrapper只分配必要输出，pending只携带Tensor引用；源码没有附加物化。可确认不存在新增大张量copy或同步，不能从一次trace证明Python路由成本为零。

## Profiler归因（不是纯计时结果）

'''+pbreak+'''
GPU sum和union差异小于1µs，表中大类按module/kernel名互斥。span−union是最早到最晚forward GPU活动之间无活动覆盖的间隙，包含CPU供给、依赖等，不能全部叫Python路由开销。Forward首Kernel之前/最后之后的开销不在该gap里。CPU forward scope约14–18ms，CUDA API总CPU时间约1.19–1.39ms；它们与GPU大量重叠，不能再加到GPU耗时上。

N8192 Original：Attention34.835ms+MLP30.894ms=65.729ms，占GPU活动总78.046ms的84.2%；iHC Pre/Post8.259ms=10.58%，HCHead3.028ms=3.88%（后者不在本融合范围）。五个可融合边界原始活动合计6.857ms=8.79% GPU活动；Cross五个Fused4.354ms。Profiler下目标边界节省2.502ms，整个活动总和节省2.422ms；其他Kernel差异约−0.080ms，不能简单归于融合副作用。N4096对应五边界3.327→2.214ms，节省1.113ms。

## 同模式边界复验

另一个无Profiler的Eager实验在真实模型内计时五个目标边界。Original按10个Post/Pre模块跨度相加，Intra按3个Fused+4个Post/Pre跨度，Cross按5个Fused。9轮配对，3次warmup。hook/wrapper只调用原实现，额外事件可能扰动流水，因此与纯计时分开保存，不能直接相减当作精确路由开销。

'''+btable+'''
N8192统一Eager下五边界约6.924→4.393ms，节省2.531ms；单独算子Eager热态每次节省0.454ms，乘5为2.271ms；纯Forward中位数差1.950ms，配对差中位数2.309ms。三种估计同量级但不相等。缓存、权重/状态值、顺序、事件插入和模型其他Kernel波动均影响它们。因此历史2.230/2.238ms的接近有解释力，但不是“Runtime零开销”的证明。

## Amdahl：3%、5%、10%

以下5%/10%指speedup 1.05×/1.10×，不是耗时下降5%/10%。以本轮Original中位数78.185ms、Cross76.234ms计算：

'''+amdahl+f'''
若其他耗时完全固定，仅继续优化五个Fused，达到1.05×需要平均约{(O-O/1.05-saving)/5:.1f}µs额外节省，相当于当前模型内平均{BC/5:.1f}µs的约{(O-O/1.05-saving)/BC*100:.0f}%下降。当前数据不能证明这能实现。1.10×还需额外{(O-O/1.10-saving)/1000:.3f}ms，超过五个Fused合计约{BC/1000:.3f}ms；在本轮中位数和固定其他工作的条件下，即使五Kernel免费也不够。

直接用原始五边界的6.857ms GPU活动或6.924ms Eager Event估算其占比约8.8%；把这些边界成本全部归零的理想上限约1.096–1.097×。它是来自不同但接近计时范围的条件估算，不是严格的完整模型硬上限；收益随调度和其他Kernel改变也会变。实测1.5×局部加速对应约3%的模型加速符合该占比，并未发现漏掉融合所造成的大额损失。要可靠追求10%，需要覆盖现有五边界之外，例如Attention、MLP/MoE或另行研究HCHead；本轮没有开发这些功能，也不外推全量HY4 E2E。
''')

(R/'REPORT.md').write_text('''# HY4 iHC H100 性能审计 — 2026-10-21

**结论：约1.5×算子加速与约3%三层Forward加速主要由计算占比解释，没有发现Runtime漏融合。对于“Kernel是否已接近合理上限”，选择 C：证据不足。** 已确认寄存器限制并发、重复Post和旧Residual读取，但没有硬件Counter证明哪个因素占主导，也不能承诺再优化可获得5%–10%模型收益。

当前正确性限制不变：**此前161 passed / 1 failed；N8192合成三层链路超限与严格模型A/A、A/B验收仍未闭合**。本轮性能审计不是生产精度验收；没有修复、放宽阈值或重新宣布通过。

## 关键实测

'''+mtable+'''
以上是同一模型、TP1、H100 GPU3、Eager、固定三层真实切片的9轮中位数，Profiler不参与计时。N8192配对speedup中位数1.0302×（各组中位数比1.0256×）；完整分位数和每轮数据见[RUNTIME_BREAKDOWN.md](RUNTIME_BREAKDOWN.md)及raw/model_timing.csv。N512本轮有负收益和明显噪声，应保留该结果，不作稳定加速声明。

- N8192算子Eager热态：Original **1308.496µs**，Fused **854.272µs**，**1.532×**；独立Graph热态1310.624→857.520µs，1.528×。冷L2代理、其他N和P10/P90均已保存。
- 真实Trace：Original18个iHC Kernel，Intra12个，Cross8个，其中Fused分别0/3/5次；首Pre、末Post正确保留。没有新增大张量复制、contiguous或同步活动。
- N8192 Original活动归因：Attention+MLP约84.2%，iHC Pre/Post约10.6%；**本轮五个可融合边界仅约8.8%**，HCHead不在融合范围。以此占比获得1.5×局部收益，自然对应约3%模型收益。

## 七个核心判断

1. **实际HBM流量是否下降：未测得，不能确认下降幅度。** 源码消除了对更新Residual的两遍消费和Partial buffer，但仍写必要Residual，同时重读旧Residual、重算Post。粗粒度激活逻辑字节数两条路径同为1728MiB，不能用“单Kernel”替代DRAM证据。
2. **主要瓶颈：大N不是Launch主导；Memory/L2/FP32指令/occupancy之间尚不能唯一归因。** Fused168寄存器/线程限制到3CTA/SM、18.75%资源occupancy上限，实际occupancy和stall未知。
3. **明显低效：有重复Post和第二次旧Residual加载，另有24次串行chunk及每Token重复读768KiB权重。** 但这些可能换取状态规模和数值语义，不能未测量就认定可无代价消除；无register spill、无额外Runtime物化。
4. **1.52×接近上限吗：不能证明。** N8192唯一必要数据的极乐观HBM下界约301µs，按实测大buffer参考带宽约332–412µs；按源码激活请求全部到HBM则约597–741µs。均未包含真实L2/指令依赖，854µs距离这些模型的差值不是可兑现空间。
5. **为什么约3%：五边界占比小，且三层Trace证明全部覆盖。** 同模式模型内五边界Eager节省约2.531ms；纯模型配对差中位数2.309ms，量级相符但不意味着路由开销严格为零。
6. **5%–10%有可信证据吗：没有。** 1.05×仍需每次Fused约355µs额外节省；1.10×所需额外总节省超过现有五Fused的总时间。五个原始边界全部免费也仅约1.096–1.097×的条件上限。
7. **下一轮最值得验证的单个方向：获取N8192的DRAM/L2和warp issue/stall Counter，判断168寄存器与24次串行投影是否限制延迟隐藏。** 先做此最小取证，再决定是否值得围绕投影活跃状态减少寄存器；本轮不改Tile、不改FMA、不改归约树、不开发Kernel。

## 证据导航

- [SOURCE_AUDIT.md](SOURCE_AUDIT.md)：数学、源码位置、Tensor读写台账、Residual生命周期。
- [MEMORY_MODEL.md](MEMORY_MODEL.md)：访存/FLOPs下界和假设；raw/memory_model.csv覆盖四个N。
- [PROFILE_ANALYSIS.md](PROFILE_ANALYSIS.md)：PTX/SASS、资源、计时、缺失Counter及局限。
- [RUNTIME_BREAKDOWN.md](RUNTIME_BREAKDOWN.md)：真实三层调用、互斥耗时归因、配对原始数据与Amdahl。
- [REPRODUCE.md](REPRODUCE.md)、[EXPERIMENT_LOG.md](EXPERIMENT_LOG.md)：完整命令、环境、失败尝试、逐阶段记录。
- raw/保存初始Git状态/差异/哈希、完整CSV、6份模型trace、算子trace、cubin/PTX/SASS。没有保存权重内容；checkpoint通过环境变量指定。

## 范围与精度

本次只在本实验目录新增脚本、记录、原始数据和隔离缓存。Kernel、Runtime、测试、冻结Lab均不修改；初始用户修改与跨层未提交修改由逐文件SHA256复验，结果见raw/scope_audit_final.json。没有暂存、提交、推送、安装软件、改变GPU时钟/权限或清理任何现存缓存。

仅独立算子检查沿用冻结check_outputs：N512/1024/4096/8192均通过；N8192输出max_abs=0.0078125、rel_L2=6.999e-6，Residual逐位一致，Gates max_abs=2.384e-7。这个检查不覆盖现有模型数值未闭合问题。模型计时不等于完整推理、TTFT或H200验证；Graph数字仅为独立算子测试。
''')
print('Reports generated')
