"""Verify all pre-existing tracked/untracked nonignored content is unchanged."""
import ast
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path
R=Path(__file__).resolve().parent.parent; repo=Path.cwd(); raw=R/'raw'
old=json.loads((raw/'before_hashes.json').read_text())
changed=[];missing=[]
for name,digest in old.items():
    p=repo/name
    if not p.is_file():missing.append(name)
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=digest:changed.append(name)
files=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).decode().split('\0')
prefix=str(R.relative_to(repo))+'/'
new=[f for f in files if f and f not in old]
outside=[f for f in new if not f.startswith(prefix)]
# Directory symlinks were not included by the initial is_file() hash snapshot.
# Verify their tracked HEAD targets; they are not newly created audit files.
symlinks=[]
for name in outside[:]:
    item=repo/name
    if item.is_symlink():
        blob=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
        if blob.returncode==0 and blob.stdout.decode()==os.readlink(item):
            symlinks.append(name);outside.remove(name)
new=[f for f in new if f not in symlinks]
diff=subprocess.check_output(['git','diff'])
initial=(raw/'initial.diff').read_bytes()
status=subprocess.check_output(['git','status','--short','--untracked-files=all'])
(raw/'final.status').write_bytes(status)
(raw/'final.diff.stat').write_bytes(subprocess.check_output(['git','diff','--stat']))
(raw/'final.diff.names').write_bytes(subprocess.check_output(['git','diff','--name-only']))
check=subprocess.run(['git','diff','--check'],capture_output=True,text=True)
for p in (R/'scripts').glob('*.py'):ast.parse(p.read_text())
result=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    preexisting_files_checked=len(old),unchanged_tracked_directory_symlinks=symlinks,preexisting_changed=changed,preexisting_missing=missing,
    new_outside_allowed_directory=outside,tracked_diff_byte_identical=diff==initial,
    staged_names=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines(),
    git_diff_check_returncode=check.returncode,git_diff_check_output=check.stdout+check.stderr,
    audit_python_syntax='all parsed',new_nonignored_files=new)
(raw/'scope_audit_final.json').write_text(json.dumps(result,indent=2))
assert not changed and not missing and not outside and diff==initial
print({k:v for k,v in result.items() if k!='new_nonignored_files'})
with (R/'EXPERIMENT_LOG.md').open('a') as f:
    f.write('\nE10 — '+result['time']+' scope audit: '+str(len(old))+' pre-existing nonignored files SHA256-verified; no change/missing file, no new file outside allowed directory; original git diff byte-identical, no staged files. Audit scripts AST parse passed; git diff --check status '+str(check.returncode)+'. Evidence raw/scope_audit_final.json and final.status/diff.stat. No production correctness tests rerun; existing 161/1 limitation retained.\n')
