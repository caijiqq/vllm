"""CPU-only derivations from immutable timing/activity outputs."""
import csv
import json
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent; RAW=ROOT/'raw'
def pct(values,q):
    values=sorted(values);pos=(len(values)-1)*q;i=int(pos)
    return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(pos-i)
def stats(values):
    return dict(median=statistics.median(values),p10=pct(values,.1),p90=pct(values,.9),min=min(values),max=max(values),count=len(values))
def write_csv(name,rows):
    if not rows:return
    with (RAW/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def timing(filename,keys,value,output):
    groups=defaultdict(list);rounds=defaultdict(list)
    for r in csv.DictReader((RAW/filename).open()):
        key=tuple(r[k] for k in keys);groups[key].append(float(r[value]))
        rounds[(*key,r['round'])].append(float(r[value]))
    rows=[]
    for key,vals in groups.items():
        row=dict(zip(keys,key));row.update({k+'_us':v for k,v in stats(vals).items() if k!='count'});row['count']=len(vals)
        rs=[statistics.median(v) for k,v in rounds.items() if k[:-1]==key]
        row.update({f'round_median_{k}_us':v for k,v in stats(rs).items() if k!='count'});rows.append(row)
    write_csv(output,rows)
    return rows
kernel=timing('kernel_timing.csv',['n','mode','cache','implementation'],'event_us','kernel_summary.csv')
# Match instructions, not metadata strings or the scalar HFMA2.MMA modifier.
resources=json.loads((RAW/'resources.json').read_text())
for r in resources:
    sass=(RAW/(r['artifacts']+'.sass')).read_text()
    ptx=(RAW/(r['artifacts']+'.ptx')).read_text()
    r['tensor_instruction_count_corrected']=len(re.findall(r'/\*[0-9a-f]+\*/\s+(?:@!?P\d+\s+)?(?:HMMA|HGMMA|IMMA|MMA|DMMA)\.',sass))
    r['ptx_mma_count']=len(re.findall(r'\b(?:mma|wgmma)\.',ptx))
    r['ptx_load_global_static_count']=len(re.findall(r'\bld\.global',ptx))
    r['ptx_store_global_static_count']=len(re.findall(r'\bst\.global',ptx))
    r['sass_backward_branches']=[x.strip() for x in sass.splitlines() if re.search(r'\bBRA\b',x)]
(RAW/'resources_analysis.json').write_text(json.dumps(resources,indent=2))

# Reproducible theoretical source-request model. Not hardware counter values.
memory=[]
for n in (512,1024,4096,8192):
    d=6144;k=4*d
    payload=n*(2*d+2*k+2*k+2*d+2*4*4)+8*k*4+40
    orig=22*k*n;fused=(24*k+9*1023)*n
    memory.append(dict(n=n,residual_bytes=2*n*k,unique_boundary_bytes=payload,
        original_activation_request_bytes=36*n*d,fused_activation_request_bytes=36*n*d,
        weight_request_bytes=n*8*k*4,original_partial_rw_bytes=n*24*9*4*7,
        removed_updated_read_bytes=4*n*k,extra_fused_old_R_and_x_bytes=2*n*k+4*2*n*d,
        original_main_flops=orig,fused_main_flops=fused,
        optimistic_unique_bandwidth_us=payload/3.35e6,
        original_streaming_estimate_us=(36*n*d+n*24*9*4*7+8*k*4)/3.35e6,
        fused_nonFMA_peak_compute_us=fused/33.5e6))
write_csv('memory_model.csv',memory)

# CUPTI activity correlation -> narrowest enclosing CPU module tag.
def trace(path):
    events=json.loads(path.read_text())['traceEvents']
    tags=[e for e in events if e.get('cat')=='user_annotation' and e['name'].startswith('AUDIT::')]
    launches={e['args']['correlation']:e for e in events if e.get('cat') in ('cuda_runtime','cuda_driver') and 'correlation' in e.get('args',{})}
    def enclosing(e):
        if not e:return []
        return sorted([t for t in tags if t['tid']==e['tid'] and t['ts']<=e['ts']<t['ts']+t['dur']],key=lambda x:x['dur'])
    gpu=[]
    for e in events:
        if e.get('cat') not in ('kernel','gpu_memcpy','gpu_memset'):continue
        launch=launches.get(e.get('args',{}).get('correlation'));parents=enclosing(launch)
        label=parents[0]['name'].removeprefix('AUDIT::') if parents else 'outside_forward'
        inside=any(t['name']=='AUDIT::forward' for t in parents)
        name=e['name'];category='other'
        if name=='_fused_post_pre':category='fused_post_pre'
        elif name in ('_ihc_pre_stage1','_ihc_pre_stage2','_ihc_post_kernel'):category='original_ihc'
        elif label.startswith('attention.'):category='attention'
        elif label.startswith('mlp.'):category='mlp'
        elif label=='hc_head':category='hc_head'
        elif e['cat']!='kernel':category='copies_memsets'
        args=e.get('args',{})
        gpu.append(dict(name=name,category=category,module=label,inside_forward=inside,
                        start_us=e['ts'],duration_us=e['dur'],grid=args.get('grid'),block=args.get('block'),
                        registers=args.get('registers per thread'),shared_bytes=args.get('shared memory'),
                        correlation=args.get('correlation')))
    def union(intervals):
        total=0;end=float('-inf')
        for a,b in sorted(intervals):
            total+=max(0,b-max(a,end));end=max(end,b)
        return total
    modelgpu=[g for g in gpu if g['inside_forward']]
    forwardtags=[t for t in tags if t['name']=='AUDIT::forward']
    breakdown={}
    for c in sorted({g['category'] for g in modelgpu}):
        vals=[g['duration_us'] for g in modelgpu if g['category']==c]
        breakdown[c]=dict(count=len(vals),sum_us=sum(vals))
    apis=[e for e in events if e.get('cat') in ('cuda_runtime','cuda_driver') and any(t['name']=='AUDIT::forward' for t in enclosing(e))]
    # CPU ops under HC boundary can expose dtype/copy/synchronization overhead.
    suspicious=[]
    for e in events:
        if e.get('cat')!='cpu_op' or not any(s in e['name'] for s in ('clone','contiguous','copy','_to_copy','synchronize')):continue
        parents=enclosing(e)
        if parents and any(t['name'].startswith(('AUDIT::pre.','AUDIT::post.')) for t in parents):
            suspicious.append(dict(name=e['name'],duration_us=e['dur'],module=parents[0]['name']))
    result=dict(file=path.name,breakdown=breakdown,kernel_counts=dict(Counter(g['name'] for g in modelgpu)),
                gpu_activity_sum_us=sum(g['duration_us'] for g in modelgpu),
                gpu_activity_union_us=union([(g['start_us'],g['start_us']+g['duration_us']) for g in modelgpu]),
                gpu_span_us=max((g['start_us']+g['duration_us'] for g in modelgpu),default=0)-min((g['start_us'] for g in modelgpu),default=0),
                forward_cpu_scope_us=sum(t['dur'] for t in forwardtags),
                cpu_cuda_api_sum_us=sum(e['dur'] for e in apis),cpu_cuda_api_counts=dict(Counter(e['name'] for e in apis)),
                hc_conversion_ops=suspicious)
    return result,gpu
kernel_trace,gpu=trace(RAW/'kernel_8192.trace.json')
write_csv('kernel_profile_activity.csv',gpu)
profile_summary=[]
for name in ('_ihc_post_kernel','_ihc_pre_stage1','_ihc_pre_stage2','_fused_post_pre'):
    vals=[x['duration_us'] for x in gpu if x['name']==name]
    profile_summary.append(dict(kernel=name,**stats(vals)))
write_csv('kernel_profile_summary.csv',profile_summary)
if (RAW/'model_timing.csv').exists():
    timing('model_timing.csv',['n','mode'],'forward_us','model_summary.csv')
if (RAW/'model_trace_manifest.json').exists():
    out=[]
    for r in json.loads((RAW/'model_trace_manifest.json').read_text()):
        summary,gpu=trace(RAW/r['file']);summary.update(n=r['n'],mode=r['mode']);out.append(summary)
        write_csv(f'model_{r["n"]}_{r["mode"]}_activity.csv',gpu)
    (RAW/'model_profile_analysis.json').write_text(json.dumps(out,indent=2))
if (RAW/'model_boundary_timing.csv').exists():
    groups=defaultdict(float)
    for r in csv.DictReader((RAW/'model_boundary_timing.csv').open()):groups[(r['n'],r['mode'],r['round'])]+=float(r['event_us'])
    write_csv('model_boundary_totals.csv',[dict(n=n,mode=m,round=i,target_five_us=t) for (n,m,i),t in groups.items()])
print('Analysis complete')
