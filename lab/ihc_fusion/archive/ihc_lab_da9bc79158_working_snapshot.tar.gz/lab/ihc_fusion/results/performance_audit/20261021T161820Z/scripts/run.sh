#!/usr/bin/env bash
set -euo pipefail
AUDIT_RUN=$(cd "$(dirname "$0")/.." && pwd)
export AUDIT_RUN
export CUDA_VISIBLE_DEVICES=3
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/lab/ihc_fusion/results/runtime_integration:$PWD"
export TRITON_CACHE_DIR="$AUDIT_RUN/cache/triton"
export VLLM_CACHE_ROOT="$AUDIT_RUN/cache/vllm"
export TORCHINDUCTOR_CACHE_DIR="$AUDIT_RUN/cache/inductor"
export CUDA_CACHE_PATH="$AUDIT_RUN/cache/cuda"
export XDG_CACHE_HOME="$AUDIT_RUN/cache/xdg"
export FLASHINFER_WORKSPACE_BASE="$AUDIT_RUN/cache/flashinfer"
export VLLM_ENABLE_V1_MULTIPROCESSING=0
export VLLM_USE_BREAKABLE_CUDAGRAPH=0
exec lab/ihc_fusion/results/.venv/bin/python "$@"
