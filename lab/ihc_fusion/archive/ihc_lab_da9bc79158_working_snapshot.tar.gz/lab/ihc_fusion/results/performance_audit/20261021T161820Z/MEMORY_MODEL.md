# E02: theoretical model (before profiling)

D6144,C4,K24576,S24,H6. H10080GB HBM3 matches SXM specs:3.35TB/s HBM and67TFLOP/s FP32 peak, [NVIDIA source](https://www.nvidia.com/en-eu/data-center/h100/). Actual SM/memory clocks and driver attributes saved in environment.json. Do not infer that sparse BF16 Tensor Core peak applies to this FP32 non-FMA kernel.

AtN8192: x/y96MiB each, old/updated R384MiB each; unique W768KiB. Cold/sustained required payload≈960MiB (plus tiny gates/weights), optimistic bandwidth floor≈301us at3.35TB/s. This assumes every input read once, every necessary output written once, cached weights and no instruction/latency cost. It is not a predicted achievable runtime. Fused's two R traversals and five x traversals can increase physical traffic; N8192 source activation payload1728MiB→~541us if all those requests reach HBM. Weight requests6GiB must be treated separately: with a768KiB shared matrix, substantial L2 reuse is plausible; assuming all hit HBM predicts>2.4ms and is incompatible with historic854us. This incompatibility proves source requests cannot simply be counted as HBM, not a measured cache hit rate.

Original's streaming estimate≈(1728+47.25)MiB plus one W load, ~556us peak-bandwidth time; partial reads can hit cache and tail residual cache reuse can reduce it. This is an implementation traffic scenario, not a strict lower bound. Exact read/write bytes, L2 and stalls require counters.

Approximate FLOPs: Original≈22K/token plus partial/gate overhead. Fused≈24K+9*1023/token (Post twice, dot products, square sum, final lane reductions and channel reduction),~4.91GFLOP atN8192. Counts depend on compiler folding zero additions and exclude special-function cost. Non-FMA peak scalar FP32 issue is at most roughly half the67TFLOP/s FMA headline, giving an optimistic~146us compute floor; actual occupancy, dependencies, memory operations and SFUs can raise it. These floors combine with max(), not sum(), and are not evidence that854us can be reduced to301us.

Fused still runs24 serial chunk iterations/CTA; compute, L2 delivery and instruction/occupancy limits are hypotheses to check. Resource-limit occupancy is only an upper bound, not achieved occupancy. A copy_-based large-buffer bandwidth probe will establish a reference (not the operator's bandwidth).

Numeric formulas forN512/1024/4096/8192 are in raw/memory_model.csv. DRAM counters are not substituted with these byte counts.

## E05实测参考与下界解释

|Existing ATen operation|Buffer MiB|Median TB/s (logical R+W)|
|---|---:|---:|
|copy|256|3.006|
|copy|1024|2.444|
|add_zero|256|2.992|
|add_zero|1024|3.035|

256/1024MiB都超过50MiB L2。大buffer现有ATen操作的逻辑R+W参考范围为2.444–3.035TB/s；copy_与add_zero在1024MiB差别明显，所以不选择最高结果冒充所有算子的可持续上限。没有DRAM Counter，这些仍是逻辑带宽参考，不能直接当成Fused achieved HBM bandwidth。

|N|单份Residual MiB|Original激活请求 MiB|Fused激活请求 MiB|Original partial R/W MiB|唯一必要payload MiB|3.35TB/s乐观下界 µs|
|---|---:|---:|---:|---:|---:|---:|
|512|24.000|108.000|108.000|2.953|60.766|19.020|
|1024|48.000|216.000|216.000|5.906|120.781|37.805|
|4096|192.000|864.000|864.000|23.625|480.875|150.518|
|8192|384.000|1728.000|1728.000|47.250|961.000|300.800|

N8192约1007.7MB唯一必要payload，在2.444–3.035TB/s参考范围得到约332–412µs；1728MiB实现激活请求全部到HBM的假设得到约597–741µs。854.272µs分别是这些值的约2.1–2.6倍、1.15–1.43倍。这两个区间**不是实际Kernel可达到的目标区间**：缓存会减少激活流量，权重/L2/指令开销又会增加时间，不能将“854减下界”的442–522µs直接称为可优化空间。

FLOPs近似来源：Original Post2K + squared-sum约2K + 8路projection约16K + weighted-channel-output约2K =22K/token；各分片树和重复partial归约另有小项。Fused Post执行两遍4K + projection16K + squared-sum2K + channel-output2K + 最后9组1024-lane reductions约9207，合计24K+9207/token。FP32非FMA、SFU、地址计算和load指令的执行成本不在简单FLOPs中。

Source-level streaming arithmetic intensity若计权重请求约4.91GFLOPs/(1.812+6.442)GB≈0.59 FLOP/byte；按唯一必要边界字节则约4.87 FLOP/byte。前者不是DRAM arithmetic intensity，后者也不能忽略L2输送权重的成本。不能用一个未经验证的算术强度判定HBM-bound。

理论launch/阶段依赖：Original依赖三Kernel顺序，Fused只有一个。大N下Eager与Graph耗时接近，launch不是主要项；小N的固定成本不能简单从大N耗时扣除。无spin-wait、跨CTA原子同步，Fused只有CTA内归约/shared/barrier；其精确同步stall成本缺少Counter。

当前瓶颈结论为混合因素Hypothesis。进一步降低寄存器/改变投影状态有代码局部性潜力，但不能在缺少实际stall与L2/DRAM证据时为其给出可信目标延迟。模型级“1.05×需要每次额外355µs”只是目标要求，不是优化承诺。
