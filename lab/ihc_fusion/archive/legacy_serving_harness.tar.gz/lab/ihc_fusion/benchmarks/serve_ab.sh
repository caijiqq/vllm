#!/usr/bin/env bash
set -euo pipefail

HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO=$(cd -- "$HERE/../../.." && pwd)
PYTHON=${VLLM_PYTHON:-$REPO/.venv/bin/python}
CHECK=$HERE/serve_ab_results.py
export PYTHONPATH="$REPO${PYTHONPATH:+:$PYTHONPATH}"

usage() {
  cat <<'EOF'
Usage: MODEL_PATH=/path/to/model bash serve_ab.sh [--help|--dry-run]
Required: MODEL_PATH (directory with config.json and complete weight shards)
Optional: TOKENIZER_PATH (defaults to MODEL_PATH), TP_SIZE=1,
  CUDA_VISIBLE_DEVICES (unset: use visible devices), HOST=127.0.0.1, PORT=8000,
  BENCH_CASES='2048:1:1 8192:256:16' (ISL:OSL:concurrency),
  NUM_PROMPTS=32, REQUEST_RATE=inf, SEED=7, AB_ROUNDS=2,
  RESULT_DIR=lab/ihc_fusion/results/serve_ab_<UTC timestamp>, STARTUP_TIMEOUT=600,
  DTYPE=bfloat16, GPU_MEMORY_UTILIZATION=0.8, WARMUPS=4,
  VLLM_PYTHON=<matching vLLM interpreter>.
Each arm uses eager serving, no MTP, disabled prefix cache and the same random
dataset. Profiles run separately; benchmark results require OFF original and ON
fused kernel launches on every TP rank.
EOF
}

DRY=0
case ${1:-} in
  --help) usage; exit 0 ;;
  --dry-run) DRY=1 ;;
  '') ;;
  *) usage >&2; exit 2 ;;
esac
[[ $# -le 1 ]] || { usage >&2; exit 2; }

: "${MODEL_PATH:?Set MODEL_PATH to a HY4 weight directory}"
[[ -f $MODEL_PATH/config.json ]] || { echo "Missing $MODEL_PATH/config.json" >&2; exit 2; }
TOKENIZER_PATH=${TOKENIZER_PATH:-$MODEL_PATH}
[[ -e $TOKENIZER_PATH ]] || { echo "Missing tokenizer path: $TOKENIZER_PATH" >&2; exit 2; }
TP_SIZE=${TP_SIZE:-1}
HOST=${HOST:-127.0.0.1}
PORT=${PORT:-8000}
BENCH_CASES=${BENCH_CASES:-'2048:1:1 8192:256:16'}
NUM_PROMPTS=${NUM_PROMPTS:-32}
REQUEST_RATE=${REQUEST_RATE:-inf}
SEED=${SEED:-7}
AB_ROUNDS=${AB_ROUNDS:-2}
STARTUP_TIMEOUT=${STARTUP_TIMEOUT:-600}
DTYPE=${DTYPE:-bfloat16}
GPU_MEMORY_UTILIZATION=${GPU_MEMORY_UTILIZATION:-0.8}
WARMUPS=${WARMUPS:-4}
RESULT_DIR=${RESULT_DIR:-$REPO/lab/ihc_fusion/results/serve_ab_$(date -u +%Y%m%dT%H%M%SZ)}
[[ $HOST != *:* && $HOST != */* ]] || { echo 'HOST must be an IPv4 address or hostname' >&2; exit 2; }
for value in TP_SIZE PORT NUM_PROMPTS AB_ROUNDS STARTUP_TIMEOUT; do
  [[ ${!value} =~ ^[1-9][0-9]*$ ]] || { echo "$value must be positive" >&2; exit 2; }
done
[[ $WARMUPS =~ ^[0-9]+$ && $SEED =~ ^[0-9]+$ ]] || { echo 'WARMUPS and SEED must be nonnegative integers' >&2; exit 2; }
[[ $PORT -le 65535 ]] || { echo 'PORT exceeds 65535' >&2; exit 2; }
[[ $REQUEST_RATE == inf || $REQUEST_RATE =~ ^[0-9]+([.][0-9]+)?$ ]] || { echo 'REQUEST_RATE must be positive or inf' >&2; exit 2; }
[[ $REQUEST_RATE == inf || $REQUEST_RATE =~ ^0*([1-9][0-9]*)([.][0-9]+)?$ || $REQUEST_RATE =~ ^0*[.]0*[1-9][0-9]*$ ]] || { echo 'REQUEST_RATE must be positive' >&2; exit 2; }
[[ $GPU_MEMORY_UTILIZATION =~ ^0[.][0-9]*[1-9][0-9]*$ || $GPU_MEMORY_UTILIZATION =~ ^1([.]0+)?$ ]] || { echo 'GPU_MEMORY_UTILIZATION must be in (0,1]' >&2; exit 2; }
if [[ -n ${CUDA_VISIBLE_DEVICES:-} ]]; then
  IFS=, read -r -a devices <<< "$CUDA_VISIBLE_DEVICES"
  [[ ${#devices[@]} -ge $TP_SIZE ]] || { echo 'TP_SIZE exceeds CUDA_VISIBLE_DEVICES count' >&2; exit 2; }
fi
read -r -a cases <<< "$BENCH_CASES"
[[ ${#cases[@]} -gt 0 ]] || { echo 'BENCH_CASES is empty' >&2; exit 2; }
declare -A seen_cases=()
max_len=0
for item in "${cases[@]}"; do
  [[ $item =~ ^([1-9][0-9]*):([1-9][0-9]*):([1-9][0-9]*)$ ]] || { echo "Bad BENCH_CASES item: $item" >&2; exit 2; }
  [[ -z ${seen_cases[$item]:-} ]] || { echo "Duplicate BENCH_CASES item: $item" >&2; exit 2; }
  seen_cases[$item]=1
  isl=${BASH_REMATCH[1]} osl=${BASH_REMATCH[2]}
  (( isl + osl > max_len )) && max_len=$((isl + osl))
  [[ $isl -ge 512 ]] || { echo "Case $item is below fusion's Prefill range" >&2; exit 2; }
done

vllm=("$PYTHON" -m vllm.entrypoints.cli.main)
server_pid=
stop_server() {
  if [[ -n $server_pid ]]; then
    kill -TERM -- "-$server_pid" 2>/dev/null || true
    for ((t=0; t<30; t++)); do
      kill -0 -- "-$server_pid" 2>/dev/null || break
      sleep 1
    done
    kill -KILL -- "-$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
    server_pid=
    for ((t=0; t<30; t++)); do
      port_busy || return 0
      sleep 1
    done
    echo "Port $PORT remained occupied after own server exited" >&2
    return 1
  fi
}
trap 'stop_server' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

port_busy() { (echo > "/dev/tcp/$HOST/$PORT") >/dev/null 2>&1; }
show() { printf '%q ' "${vllm[@]}" "$@"; printf '\n'; }

start_server() {
  local arm=$1 purpose=$2 dir=$3 fused=false pgid
  [[ $arm == on ]] && fused=true
  port_busy && { echo "Port $HOST:$PORT is already occupied" >&2; return 1; }
  local args=(serve "$MODEL_PATH" --served-model-name hy4-ab --host "$HOST" --port "$PORT"
    --tensor-parallel-size "$TP_SIZE" --dtype "$DTYPE" --enforce-eager
    --generation-config vllm --no-enable-prefix-caching --trust-remote-code
    --seed "$SEED" --max-model-len "$max_len" --gpu-memory-utilization "$GPU_MEMORY_UTILIZATION"
    --hf-overrides "{\"enable_ihc_post_pre_fusion\":$fused,\"enable_ihc_cross_layer_fusion\":$fused}")
  if [[ $purpose == profile ]]; then
    args+=(--profiler-config "{\"profiler\":\"torch\",\"torch_profiler_dir\":\"$dir/traces\"}")
  fi
  if (( DRY )); then show "${args[@]}"; return; fi
  mkdir -p "$dir"
  show "${args[@]}" > "$dir/server_command.txt"
  setsid "${vllm[@]}" "${args[@]}" > "$dir/server.log" 2>&1 &
  server_pid=$!
  pgid=$(ps -o pgid= -p "$server_pid" | tr -d ' ')
  if [[ $pgid != "$server_pid" ]]; then
    echo 'Server process group isolation failed' >&2
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
    server_pid=
    return 1
  fi
  for ((t=0; t<STARTUP_TIMEOUT; t++)); do
    if curl --silent --fail --max-time 2 "http://$HOST:$PORT/health" >/dev/null; then return; fi
    kill -0 "$server_pid" 2>/dev/null || { echo "Server exited; see $dir/server.log" >&2; return 1; }
    sleep 1
  done
  echo "Server startup timed out; see $dir/server.log" >&2
  return 1
}

bench_case() {
  local item=$1 purpose=$2 dir=$3
  local isl osl concurrency
  IFS=: read -r isl osl concurrency <<< "$item"
  local count=$NUM_PROMPTS warms=$WARMUPS
  if [[ $purpose == profile ]]; then
    count=$concurrency
    (( count < 4 )) && count=4
    warms=2
  fi
  local args=(bench serve --backend openai --host "$HOST" --port "$PORT"
    --endpoint /v1/completions --model hy4-ab --tokenizer "$TOKENIZER_PATH"
    --trust-remote-code --dataset-name random --random-input-len "$isl"
    --random-output-len "$osl" --random-range-ratio 0
    --max-concurrency "$concurrency" --num-prompts "$count" --num-warmups "$warms"
    --request-rate "$REQUEST_RATE" --seed "$SEED" --temperature 0 --ignore-eos
    --percentile-metrics ttft,tpot,e2el --metric-percentiles 50,95
    --save-result --save-detailed --result-dir "$dir" --result-filename result.json)
  [[ $purpose == profile ]] && args+=(--profile)
  if (( DRY )); then show "${args[@]}"; return; fi
  show "${args[@]}" > "$dir/bench_command.txt"
  "${vllm[@]}" "${args[@]}" > "$dir/bench.log" 2>&1 || { echo "Benchmark failed; see $dir/bench.log" >&2; return 1; }
  "$PYTHON" -S -B "$CHECK" check-result "$dir/result.json" "$count" "$isl" "$osl"
}

if (( DRY )); then
  echo "Dry run: model=$MODEL_PATH, tokenizer=$TOKENIZER_PATH, TP=$TP_SIZE, cases=$BENCH_CASES"
  for item in "${cases[@]}"; do
    for arm in off on; do
      dir=$RESULT_DIR/profile_${arm}/case_$item
      start_server "$arm" profile "$dir"
      bench_case "$item" profile "$dir"
    done
  done
  for ((round=1; round<=AB_ROUNDS; round++)); do
    arms=(off on)
    (( round % 2 == 0 )) && arms=(on off)
    for arm in "${arms[@]}"; do
      start_server "$arm" perf "$RESULT_DIR/round_${round}_${arm}"
      for item in "${cases[@]}"; do
        bench_case "$item" perf "$RESULT_DIR/round_${round}_${arm}/case_$item"
      done
    done
  done
  exit 0
fi

[[ -x $PYTHON ]] || { echo "Missing executable VLLM_PYTHON: $PYTHON" >&2; exit 2; }
"$PYTHON" -S -B "$CHECK" check-model "$MODEL_PATH"
command -v curl >/dev/null && command -v setsid >/dev/null && command -v nvidia-smi >/dev/null || { echo 'Need curl, setsid and nvidia-smi' >&2; exit 2; }
# A busy visible GPU invalidates performance comparisons; do not disturb its process.
if [[ -n ${CUDA_VISIBLE_DEVICES:-} ]]; then
  gpu_uuids=$(nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=uuid --format=csv,noheader)
else
  gpu_uuids=$(nvidia-smi --query-gpu=uuid --format=csv,noheader)
fi
busy_uuids=$(nvidia-smi --query-compute-apps=gpu_uuid --format=csv,noheader)
while IFS= read -r uuid; do
  [[ -n $uuid ]] || continue
  if [[ $busy_uuids == *"$uuid"* ]]; then
    echo "GPU $uuid has an existing compute process; use --dry-run" >&2
    exit 2
  fi
done <<< "$gpu_uuids"
[[ ! -e $RESULT_DIR ]] || { echo "RESULT_DIR already exists: $RESULT_DIR" >&2; exit 2; }
mkdir -p "$RESULT_DIR"
"${vllm[@]}" serve --help=all > "$RESULT_DIR/serve_help.txt" 2>&1 || { echo "vLLM serve CLI failed; see $RESULT_DIR/serve_help.txt" >&2; exit 2; }
"${vllm[@]}" bench serve --help=all > "$RESULT_DIR/bench_help.txt" 2>&1 || { echo "vLLM bench serve CLI failed; see $RESULT_DIR/bench_help.txt" >&2; exit 2; }
for option in --hf-overrides --profiler-config; do
  grep -Fq -- "$option" "$RESULT_DIR/serve_help.txt" || { echo "Serve CLI lacks $option" >&2; exit 2; }
done
for option in --profile --save-detailed --random-range-ratio; do
  grep -Fq -- "$option" "$RESULT_DIR/bench_help.txt" || { echo "Bench CLI lacks $option" >&2; exit 2; }
done
"$PYTHON" -B "$CHECK" metadata "$RESULT_DIR" "$MODEL_PATH" "$TOKENIZER_PATH" "$TP_SIZE" "$DTYPE" "$BENCH_CASES" "$NUM_PROMPTS" "$REQUEST_RATE" "$SEED" "$AB_ROUNDS" "$GPU_MEMORY_UTILIZATION" "$HOST" "$PORT"
for item in "${cases[@]}"; do
  for arm in off on; do
    dir=$RESULT_DIR/profile_${arm}/case_$item
    start_server "$arm" profile "$dir"
    bench_case "$item" profile "$dir"
    stop_server
    "$PYTHON" -S -B "$CHECK" check-profile "$dir" "$arm" "$TP_SIZE"
  done
done
for ((round=1; round<=AB_ROUNDS; round++)); do
  arms=(off on)
  (( round % 2 == 0 )) && arms=(on off)
  for arm in "${arms[@]}"; do
    dir=$RESULT_DIR/round_${round}_${arm}
    start_server "$arm" perf "$dir"
    for item in "${cases[@]}"; do
      mkdir "$dir/case_$item"
      bench_case "$item" perf "$dir/case_$item"
    done
    stop_server
  done
done
"$PYTHON" -S -B "$CHECK" summarize "$RESULT_DIR" "$AB_ROUNDS" "${cases[@]}"
