"""Check official Serving JSON and profile traces; summarize paired A/B runs."""

import gzip
import importlib.metadata
import json
import math
import os
import re
import statistics
import subprocess
import sys
from pathlib import Path

METRICS = (
    ("request_throughput", "req/s", True),
    ("output_throughput", "output tok/s", True),
    ("total_token_throughput", "total tok/s", True),
    ("mean_ttft_ms", "mean TTFT ms", False),
    ("p50_ttft_ms", "P50 TTFT ms", False),
    ("p95_ttft_ms", "P95 TTFT ms", False),
    ("mean_tpot_ms", "mean TPOT ms", False),
    ("p50_tpot_ms", "P50 TPOT ms", False),
    ("p95_tpot_ms", "P95 TPOT ms", False),
    ("mean_e2el_ms", "mean E2E ms", False),
    ("p50_e2el_ms", "P50 E2E ms", False),
    ("p95_e2el_ms", "P95 E2E ms", False),
)


def result(path, count, isl, osl):
    data = json.loads(path.read_text())
    required = ("completed", "failed", "input_lens", "output_lens", "errors")
    for key in required:
        if key not in data:
            raise ValueError(f"{path}: official result missing {key}")
    if (
        data["completed"] != count
        or data["failed"] != 0
        or len(data["errors"]) != count
        or any(data["errors"])
    ):
        raise ValueError(f"{path}: incomplete or failed requests")
    if len(data["input_lens"]) != count or set(data["input_lens"]) != {isl}:
        raise ValueError(f"{path}: input lengths differ from requested ISL={isl}")
    if len(data["output_lens"]) != count or set(data["output_lens"]) != {osl}:
        raise ValueError(f"{path}: output lengths differ from requested OSL={osl}")
    for key, _, _ in METRICS:
        if osl == 1 and "tpot" in key:
            continue
        value = data.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{path}: official result missing/nonfinite {key}")
    return data


def profile(directory, arm, tp):
    traces = list((directory / "traces").rglob("*.pt.trace.json*"))
    if not traces:
        raise ValueError(f"{directory}: no worker profiler traces")
    launches = {}
    for rank in range(tp):
        tag = re.compile(rf"(?:^|_)tp{rank}(?:_|\.)|(?:^|_)rank{rank}(?:_|\.)")
        matched = [path for path in traces if tag.search(path.name)]
        if len(matched) != 1:
            raise ValueError(f"{directory}: rank {rank} has {len(matched)} traces")
        path = matched[0]
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt") as stream:
            events = json.load(stream)["traceEvents"]
        kernel_names = [
            event.get("name", "") for event in events if event.get("cat") == "kernel"
        ]
        fused = sum("_fused_post_pre" in name for name in kernel_names)
        original = sum("_ihc_pre_stage1" in name for name in kernel_names)
        if (arm == "on" and fused < 1) or (arm == "off" and (fused or original < 1)):
            raise ValueError(
                f"{path}: invalid {arm} launch evidence: fused={fused}, pre={original}"
            )
        launches[str(rank)] = {
            "trace": str(path),
            "fused": fused,
            "original_pre": original,
        }
    (directory / "launches.json").write_text(json.dumps(launches, indent=2))
    return launches


def summarize(root, rounds, cases):
    config = json.loads((root / "metadata.json").read_text())
    lines = [
        "# Serving A/B (paired rounds)",
        "",
        "Profiler: OFF original and ON fused launches confirmed per case and TP rank.",
        "",
        "| Case | Metric | OFF mean | ON mean | Improvement |",
        "|---|---|---:|---:|---:|",
    ]
    summary = {}
    for case in cases:
        isl, osl, _ = map(int, case.split(":"))
        off_hits = json.loads(
            (root / f"profile_off/case_{case}/launches.json").read_text()
        )
        on_hits = json.loads(
            (root / f"profile_on/case_{case}/launches.json").read_text()
        )
        if not all(
            row["fused"] == 0 and row["original_pre"] > 0 for row in off_hits.values()
        ):
            raise ValueError(f"{case}: OFF original launch evidence missing")
        if not all(row["fused"] > 0 for row in on_hits.values()):
            raise ValueError(f"{case}: ON fused launch evidence missing")
        paired = []
        for round_id in range(1, rounds + 1):
            row = {}
            for arm in ("off", "on"):
                path = root / f"round_{round_id}_{arm}" / f"case_{case}" / "result.json"
                row[arm] = result(path, config["num_prompts"], isl, osl)
            paired.append(row)
        summary[case] = {"launches": {"off": off_hits, "on": on_hits}}
        for key, label, higher_better in METRICS:
            if osl == 1 and "tpot" in key:
                lines.append(f"| {case} | {label} | N/A | N/A | N/A |")
                continue
            off = statistics.mean(row["off"][key] for row in paired)
            on = statistics.mean(row["on"][key] for row in paired)
            if off <= 0:
                raise ValueError(
                    f"{case}: cannot compute improvement from OFF {key}={off}"
                )
            change = statistics.mean(
                (row["on"][key] / row["off"][key] - 1)
                if higher_better
                else (1 - row["on"][key] / row["off"][key])
                for row in paired
            )
            summary[case][key] = {
                "off_mean": off,
                "on_mean": on,
                "improvement_pct": change * 100,
            }
            lines.append(f"| {case} | {label} | {off:.3f} | {on:.3f} | {change:+.2%} |")
        off_count = paired[0]["off"]["completed"]
        on_count = paired[0]["on"]["completed"]
        lines.append(
            f"| {case} | successful / failed | {off_count} / 0 | {on_count} / 0 | — |"
        )
    (root / "comparison.json").write_text(json.dumps(summary, indent=2))
    (root / "comparison.md").write_text("\n".join(lines) + "\n")
    print(root / "comparison.md")


def main(argv):
    action, *args = argv
    if action == "check-model":
        model = Path(args[0])
        config = json.loads((model / "config.json").read_text())
        if (
            config.get("model_type") != "hy_v4"
            or not config.get("enable_ihc")
            or config.get("hidden_size") != 6144
            or config.get("hc_mult") != 4
        ):
            raise ValueError("Model lacks the HYV4 iHC D6144/C4 fusion contract")
        indexes = list(model.glob("*.safetensors.index.json"))
        if indexes:
            referenced = set().union(
                *(
                    set(json.loads(i.read_text())["weight_map"].values())
                    for i in indexes
                )
            )
            missing = sorted(
                name for name in referenced if not (model / name).is_file()
            )
            if missing:
                raise ValueError(
                    f"Missing {len(missing)} indexed shards, e.g. {missing[:3]}"
                )
        elif not list(model.glob("*.safetensors")):
            raise ValueError("No safetensors weights found")
        if config.get("num_hidden_layers", 0) <= 3:
            raise ValueError("Serving A/B requires a full HY4 model, not a test slice")
    elif action == "check-result":
        result(Path(args[0]), *map(int, args[1:]))
    elif action == "check-profile":
        profile(Path(args[0]), args[1], int(args[2]))
    elif action == "metadata":
        (
            root,
            model,
            tokenizer,
            tp,
            dtype,
            cases,
            prompts,
            rate,
            seed,
            rounds,
            gpu_mem,
            host,
            port,
        ) = args
        repo = Path(__file__).resolve().parents[3]
        data = {
            "model": model,
            "tokenizer": tokenizer,
            "tp_size": int(tp),
            "dtype": dtype,
            "cases": cases,
            "num_prompts": int(prompts),
            "request_rate": rate,
            "seed": int(seed),
            "ab_rounds": int(rounds),
            "gpu_memory_utilization": gpu_mem,
            "host": host,
            "port": int(port),
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "serving": "eager; prefix cache disabled; generation config=vllm; no MTP",
            "git_commit": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=repo, text=True
            ).strip(),
            "vllm_version": importlib.metadata.version("vllm"),
            "devices": subprocess.check_output(
                ["nvidia-smi", "--query-gpu=index,uuid,name", "--format=csv,noheader"],
                text=True,
            )
            .strip()
            .splitlines(),
        }
        (Path(root) / "metadata.json").write_text(json.dumps(data, indent=2))
    elif action == "summarize":
        summarize(Path(args[0]), int(args[1]), args[2:])
    else:
        raise ValueError(f"Unknown action: {action}")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except (ValueError, FileNotFoundError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)
